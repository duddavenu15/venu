import { provideHttpClient, withInterceptorsFromDi, withXhr } from '@angular/common/http';
import { ApplicationConfig, importProvidersFrom, provideZoneChangeDetection } from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';
import { BrowserModule } from '@angular/platform-browser';
import { provideRouter, withComponentInputBinding, withRouterConfig } from '@angular/router';
import { appProviders } from '@app/app.providers';
import { appRoutes } from '@app/app.routes';
import { ErrorHandlerModule } from '@app/shared/errors';
import { environment } from '@env/environment';
import { provideAuth } from 'angular-auth-oidc-client';
import { provideUserIdleConfig } from 'angular-user-idle';

export const appConfig: ApplicationConfig = {
  providers: [
    // Http Client
    provideHttpClient(withXhr(), withInterceptorsFromDi()),
    provideAuth({
      config: environment.authConfig,
    }),
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(appRoutes, withComponentInputBinding(), withRouterConfig({ paramsInheritanceStrategy: 'always' })),
    provideUserIdleConfig({
      idle: environment.idleTimeoutSettings.inactivityTimeBeforeShowingCountdownInSeconds,
      timeout: environment.idleTimeoutSettings.countdownTimeInSeconds,
      ping: environment.idleTimeoutSettings.pingEventTimeInSeconds,
    }),
    ...appProviders,

    importProvidersFrom(BrowserModule, ErrorHandlerModule, MatDialogModule),
  ],
};
