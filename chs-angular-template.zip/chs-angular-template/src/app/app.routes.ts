import { Routes } from '@angular/router';
import { NotFoundComponent } from '@app/shared/components';
import { IsAuthenticatedGuard } from '@app/shared/guards';
import { startsWith } from '@chs/angular-native-federation';
import { HomeComponent } from './home/home.component';
import { LayoutComponent } from './layout/layout.component';
import { LogoutComponent } from './logout/logout.component';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';

export const appRoutes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    canActivate: [IsAuthenticatedGuard],
    children: [
      {
        path: '',
        component: HomeComponent,
      },
      {
        path: 'weather-forecast',
        loadComponent: () =>
          import('@app/weather-forecast/weather-forecast.component').then((comp) => comp.WeatherForecastComponent),
      },
      {
        path: 'reactive-forms-example',
        loadComponent: () =>
          import('@app/reactive-forms-example/reactive-forms-example.component').then(
            (comp) => comp.ReactiveFormsExampleComponent
          ),
      },
      {
        path: 'weather-forecast-remote',
        loadComponent: () =>
          import('@app/weather-forecast-remote/weather-forecast-remote.component').then(
            (comp) => comp.WeatherForecastRemoteComponent
          ),
      },
      {
        path: 'football-scores-remote',
        loadComponent: () =>
          import('@app/football-scores-remote/football-scores-remote.component').then(
            (comp) => comp.FootballScoresRemoteComponent
          ),
      },
      {
        path: 'settings',
        loadComponent: () => import('@app/settings/settings.component').then((comp) => comp.SettingsComponent),
      },
      {
        matcher: startsWith('web-components-documentation'),
        loadComponent: () =>
          import('@app/mfe-template/mfe-template.component').then((comp) => comp.MfeTemplateComponent),
      },
    ],
  },
  {
    path: 'logout',
    component: LogoutComponent,
  },
  {
    path: 'unauthorized',
    component: UnauthorizedComponent,
  },
  {
    path: '**',
    component: NotFoundComponent,
  },
];
