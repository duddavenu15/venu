import { CommonModule } from '@angular/common';
import { Component, signal, ChangeDetectionStrategy, inject } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatSelectModule } from '@angular/material/select';
import { MatToolbarModule } from '@angular/material/toolbar';

import { DarkModeService } from '../../services/dark-mode.service';

@Component({
  selector: 'app-contact-us-dialog',
  imports: [
    CommonModule,
    FormsModule,
    MatButtonModule,
    MatCheckboxModule,
    MatDialogModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatToolbarModule,
    ReactiveFormsModule,
  ],
  templateUrl: './contact-us-dialog.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./contact-us-dialog.component.scss'],
})
export class ContactUsDialogComponent {
  darkModeService = inject(DarkModeService);

  topics = signal(['Idea', 'Question', 'Compliment', 'Problem', 'Other']);

  messageControl = new UntypedFormControl('', Validators.required);
  contactMeControl = new UntypedFormControl('');
  topicControl = new UntypedFormControl('', Validators.required);
  uploadControl = new UntypedFormControl('');
  contactForm = new UntypedFormGroup({
    message: this.messageControl,
    contactMe: this.contactMeControl,
    topic: this.topicControl,
    upload: this.uploadControl,
  });

  submit() {
    console.log('submit feedback');
  }
}
