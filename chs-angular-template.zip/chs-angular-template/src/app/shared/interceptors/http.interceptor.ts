import { HTTP_INTERCEPTORS, HttpResponse } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { ChsHttpHelperService } from '../services/chs-http-helper.service';
import { RequestsService } from '../services/requests.service';
import { UserService } from '../services/user.service';
import { environment } from '@env/environment';

@Injectable({
  providedIn: 'root',
})
export class AuthInterceptor implements HttpInterceptor {
  private httpHelperService = inject(ChsHttpHelperService);
  private requestsService = inject(RequestsService);
  private userService = inject(UserService);

  private noAuthHeaderEndpoints: string[] = [];

  constructor() {
    environment.authConfig.forEach((authConfig) => {
      this.noAuthHeaderEndpoints.push(
        authConfig.authWellknownEndpoints?.tokenEndpoint ?? '',
        authConfig.authWellknownEndpoints?.revocationEndpoint ?? '',
        authConfig.authWellknownEndpoints?.endSessionEndpoint ?? ''
      );
    });
  }

  /**
   * If you want to prevent the spinner-overlay from appearing on a specific HTTP request
   * use the HttpHelperService in your service like so:
   *  ----------------------------
   *
   *  return this.http.get(url, {
   *    headers: this.httpHelperService.ignoreSpinnerHttpHeader
   *  });
   *
   *
   *  To ignore the spinner-overlay with existing headers in your request
   *  ---------------------------
   *  const headers: HttpHeaders = this.httpHelperService.ignoreSpinnerHttpHeader;
   *  headers.set('Content-Type', 'json')
   *         .set('Authorization', 'Bearer ' + token);
   *
   *  return this.http.get(url, { headers: headers });
   */
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<any> {
    request = this.addAuthHeader(request);

    let spinnerIgnored = this.httpHelperService.IsSpinnerIgnoredOnRequest(request);
    if (!spinnerIgnored) {
      this.requestsService.increment();
    }

    // Handle response
    return next.handle(request).pipe(
      tap({
        next: (req) => {
          if (req instanceof HttpResponse && !spinnerIgnored) {
            this.requestsService.decrement();
          }

          return req;
        },
        error: (err) => {
          if (!spinnerIgnored) {
            this.requestsService.decrement();
          }

          return err;
        },
      })
    );
  }

  private addAuthHeader(request: HttpRequest<any>) {
    // Good practice to add this check to the if statement
    // && request.url.indexOf(environment.apiUrl) >= 0
    // Where apiUrl is the url of your backend service that requires the token
    let accessToken = this.userService.siteAccessToken();

    if (accessToken) {
      if (this.noAuthHeaderEndpoints.indexOf(request.url) < 0) {
        return request.clone({
          setHeaders: {
            Authorization: 'Bearer ' + accessToken,
          },
        });
      }
    }

    return request;
  }
}

export const httpRequestInterceptorProvider = {
  provide: HTTP_INTERCEPTORS,
  useClass: AuthInterceptor,
  multi: true,
};
