export enum ExposedModuleType {
  // expose Components (Angular specific?)
  Component = './Component',

  // expose corse-grained routes from MFE
  Route = './routes',

  // expose web components (Angular Elements) - this is the preferred option
  WebComponents = './web-components',
}
