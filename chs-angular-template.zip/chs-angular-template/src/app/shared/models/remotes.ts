import { environment } from '@env/environment';

environment;
export class MfeRemote {
  constructor(entry: string, name: string) {
    this.Entry = entry;
    this.Name = name;
  }

  Entry: string;
  Name: string;
}

export class Remotes {
  static TemplateMfe: MfeRemote = new MfeRemote(
    environment.remoteEntryUrls.weatherForecastMfe,
    'chs-angular-mfe-template'
  );
  static FootballScoresMfe: MfeRemote = new MfeRemote(
    environment.remoteEntryUrls.footballScoresMfe,
    'chs-angular-mfe-template'
  );
}
