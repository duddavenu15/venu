export class ClockDriftResponse {
  utc_datetime: string = '';
}
