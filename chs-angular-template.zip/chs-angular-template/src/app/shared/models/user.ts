export class User {
  email: string = '';
  email_verified: boolean = false;
  family_name: string = '';
  given_name: string = '';
  name: string = '';
  sub: string = '';
  preferred_username: string = '';
  zoneinfo: string = '';
  locale: string = '';
  claims: Claims = new Claims();
}

export class AppSecurityClaims {
  roles?: string | undefined;
  functions?: string | undefined;
  filters?: string | undefined;
}

export interface IAppSecurityFilter {
  Key: string;
  Value: string;
}

export class Claims extends AppSecurityClaims {
  ver: string = '';
  jti: string = '';
  iss: string = '';
  aud: string = '';
  iat: string = '';
  exp: string = '';
  cid: string = '';
  uid: string = '';
  scp: string = '';
  auth_time: string = '';
  sub: string = '';
  angularTemplateFunctions: string = '';
}
