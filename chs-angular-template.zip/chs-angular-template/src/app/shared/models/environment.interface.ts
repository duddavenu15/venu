import { OpenIdConfiguration } from 'angular-auth-oidc-client';

export enum OAuthSiteConfigId {
  site = 'site',
}

export interface CHSOpenIdConfiguration extends OpenIdConfiguration {
  configId: 'site';
}

export interface IEnvironment {
  production: boolean;
  authConfig: CHSOpenIdConfiguration[];
  idleTimeoutSettings: {
    inactivityTimeBeforeShowingCountdownInSeconds: number;
    countdownTimeInSeconds: number;
    pingEventTimeInSeconds: number;
  };
  remoteEntryUrls: {
    weatherForecastMfe: string;
    footballScoresMfe: string;
  };
  clockDriftApiEndpoint: string;
  maxAllowableClockDriftInMinutes: number;
}
