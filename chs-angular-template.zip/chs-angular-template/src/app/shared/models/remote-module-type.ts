export enum RemoteModuleType {
  // use for Angular 13+
  Module = 'module',

  // use for Angular 12 and below
  Script = 'script',
}
