import { Injectable, computed, signal } from '@angular/core';
import { Claims, User, OAuthSiteConfigId, IAppSecurityFilter } from '@app/shared/models';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  #userData = signal<User | undefined>(undefined);
  #userName = computed(() => this.#userData()?.preferred_username ?? '');

  #siteAccessToken = signal('');
  #siteClaims = signal<Claims | undefined>(undefined);

  public userData = computed(this.#userData);
  public userName = computed(this.#userName);
  public siteAccessToken = computed(this.#siteAccessToken);

  public siteFilters = computed<IAppSecurityFilter[]>(() => {
    let filters = this.#siteClaims()?.filters;
    if (filters) {
      return JSON.parse(filters);
    }

    return [];
  });
  public siteFunctions = computed<string[]>(() => this.#siteClaims()?.functions?.split(',') ?? []);
  public siteRoles = computed<string[]>(() => this.#siteClaims()?.roles?.split(',') ?? []);

  constructor() {}

  clear() {
    this.#userData.set(undefined);
    this.#siteAccessToken.set('');
    this.#siteClaims.set(undefined);
  }

  public setUserData(userData: User | undefined) {
    this.#userData.set(userData);
  }

  public setAccessTokenAndClaims(
    configId: OAuthSiteConfigId,
    params: {
      accessToken: string;
      claims?: Claims | undefined;
    }
  ) {
    this.#siteAccessToken.set(params.accessToken);
    if (params.claims) {
      this.#siteClaims.set(params.claims);
    }
  }
}
