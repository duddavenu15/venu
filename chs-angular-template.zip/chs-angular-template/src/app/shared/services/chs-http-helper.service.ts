import { Injectable } from '@angular/core';
import { HttpHeaders, HttpRequest } from '@angular/common/http';
import { environment } from '@env/environment';

@Injectable({
  providedIn: 'root',
})
export class ChsHttpHelperService {
  private spinnerIgnoredHeaderName = 'spinner-overlay-ignored';
  private errorInterceptorIgnoredHeaderName = 'error-interceptor-ignored';
  private secretKey = 'chs-angular-template-true-secret-key';
  private authEndpoints: string[] = [];

  constructor() {
    environment.authConfig.forEach((authConfig) => {
      this.authEndpoints.push(
        authConfig.authWellknownEndpoints?.issuer ?? '',
        authConfig.authWellknownEndpoints?.jwksUri ?? '',
        authConfig.authWellknownEndpoints?.authorizationEndpoint ?? '',
        authConfig.authWellknownEndpoints?.tokenEndpoint ?? '',
        authConfig.authWellknownEndpoints?.userInfoEndpoint ?? '',
        authConfig.authWellknownEndpoints?.revocationEndpoint ?? '',
        authConfig.authWellknownEndpoints?.endSessionEndpoint ?? ''
      );
    });
  }

  get ignoreSpinnerHttpHeader(): HttpHeaders {
    return new HttpHeaders({
      [this.spinnerIgnoredHeaderName]: this.secretKey,
    });
  }

  get ignoreErrorInterceptorHttpHeader(): HttpHeaders {
    return new HttpHeaders({
      [this.errorInterceptorIgnoredHeaderName]: this.secretKey,
    });
  }

  IsSpinnerIgnoredOnRequest(req: HttpRequest<any>): boolean {
    return (
      req.headers.get(this.spinnerIgnoredHeaderName) === this.secretKey ||
      // No spinner-overlay on auth calls
      this.authEndpoints.indexOf(req.url) !== -1
    );
  }

  IsErrorInterceptorIgnoredOnRequest(req: HttpRequest<any>): boolean {
    return req.headers.get(this.errorInterceptorIgnoredHeaderName) === this.secretKey;
  }
}
