import { Injectable, inject } from '@angular/core';
import { map, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '@env/environment';
import { ClockDriftResponse } from '../models/clock-drift-response';

@Injectable({
  providedIn: 'root',
})
export class ChsServerTimeService {
  private http = inject(HttpClient);

  private readonly maxAllowableClockDriftInMilliseconds: number;

  constructor() {
    this.maxAllowableClockDriftInMilliseconds = environment.maxAllowableClockDriftInMinutes * 60 * 1000;
  }

  doesClientHaveTimeDrift(): Observable<boolean> {
    return this.http.get<{ utc_datetime: string }>(environment.clockDriftApiEndpoint).pipe(
      map((response: ClockDriftResponse) => {
        if (response && response.utc_datetime) {
          const localDateTime: Date = new Date();
          const serverDateTime: Date = new Date(response.utc_datetime);
          const diffInMilliseconds = Math.abs(serverDateTime.valueOf() - localDateTime.valueOf());
          return diffInMilliseconds > this.maxAllowableClockDriftInMilliseconds;
        } else {
          return true;
        }
      })
    );
  }
}
