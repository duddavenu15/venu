import { Injectable, computed, signal, inject } from '@angular/core';
import { EventTypes, LoginResponse, OidcSecurityService, PublicEventsService } from 'angular-auth-oidc-client';
import { ErrorService } from '../errors/error.service';
import { catchError, combineLatest, EMPTY, filter, map, Observable } from 'rxjs';
import { UserService } from './user.service';
import { DeepLinkService } from './deep-link.service';
import { Claims, OAuthSiteConfigId, User } from '../models';
import { environment } from '@env/environment';

@Injectable({
  providedIn: 'root',
})
export class ChsAuthenticationHelperService {
  private oidcSecurityService = inject(OidcSecurityService);
  private eventService = inject(PublicEventsService);
  private userService = inject(UserService);
  private errorService = inject(ErrorService);
  private deepLinkService = inject(DeepLinkService);

  private authConfigs: string[] = [];
  #loginFlowComplete = signal(false);

  public loginFlowComplete = computed(this.#loginFlowComplete);

  constructor() {
    environment.authConfig.forEach((authConfig) => {
      this.authConfigs.push(authConfig.configId);
    });
    // Register for authentication events from angular-auth-oidc-client
    // Used to update the user information and the access_token.
    this.eventService
      .registerForEvents()
      .pipe(filter((notification) => notification.type === EventTypes.NewAuthenticationResult))
      .subscribe((response) => {
        if (response.value.isAuthenticated) {
          this.oidcSecurityService.getUserData(OAuthSiteConfigId.site).subscribe((userData) => {
            if (userData) {
              this.userService.setUserData(userData);
            }
          });
        }
      });
  }

  isAuthenticated(): Observable<boolean> {
    return this.oidcSecurityService.isAuthenticated(OAuthSiteConfigId.site);
  }

  checkAuthentication(): Observable<boolean> {
    return this.oidcSecurityService.checkAuthMultiple().pipe(
      map((responses: LoginResponse[]) => {
        let response: LoginResponse | undefined = responses.find((x) => x.configId === OAuthSiteConfigId.site);

        if (!response || !response.isAuthenticated) {
          // before we do our first auth redirect, capture our potential deep link url
          this.deepLinkService.setDeepLinkUrl();

          // Authorize the site
          this.oidcSecurityService.authorize(OAuthSiteConfigId.site);
        }

        // If we are both authenticated, set the user up
        if (response?.isAuthenticated) {
          this.userService.setUserData(response.userData);

          // Save the other info
          this.authConfigs.forEach((config) => {
            const siteConfigId: OAuthSiteConfigId = OAuthSiteConfigId[config as keyof typeof OAuthSiteConfigId];
            this.updateAccessTokenAndClaims(siteConfigId).subscribe(() => {
              this.#loginFlowComplete.set(true);
            });
          });

          this.deepLinkService.redirectToDeepLinkUrl();
        }

        return this.loginFlowComplete();
      }),
      catchError((error, caught) => {
        if (
          window.location.href.indexOf('code=') !== -1 &&
          window.location.href.indexOf('state=') !== -1 &&
          error?.message?.indexOf('could not find matching config for state') !== -1
        ) {
          // This occurs when we press the back button after being logged out.
          // Solved by reloading the page.
          window.location.assign(window.location.origin);
        } else {
          throw new Error(error);
        }

        return EMPTY;
      })
    );
  }

  // Called when authentication changes, used to get an access_token and update our user value
  // with user data and access_token data (claims).
  private updateAccessTokenAndClaims(configId: OAuthSiteConfigId): Observable<{
    accessToken: string;
    claims?: Claims | undefined;
  }> {
    const accessToken$: Observable<string> = this.oidcSecurityService.getAccessToken(configId);
    const claims$: Observable<Claims> = this.oidcSecurityService.getPayloadFromAccessToken(false, configId);

    return combineLatest([accessToken$, claims$]).pipe(
      map(([accessToken, claims]): { accessToken: string; claims: Claims } => {
        const accessTokenAndClaims = {
          accessToken: accessToken,
          claims: claims,
        };

        this.userService.setAccessTokenAndClaims(configId, accessTokenAndClaims);

        return accessTokenAndClaims;
      })
    );
  }

  logout() {
    this.oidcSecurityService.logoffAndRevokeTokens(OAuthSiteConfigId.site).subscribe(() => {
      this.oidcSecurityService.logoffLocalMultiple();
      this.userService.clear();
      this.#loginFlowComplete.set(false);
    });
  }

  refreshAccessToken(configId: OAuthSiteConfigId): Observable<{
    userData: User;
    accessTokenAndClaims: {
      accessToken: string;
      claims?: Claims | undefined;
    };
  }> {
    let accessToken = this.userService.siteAccessToken();

    const revokeSiteToken$ = this.oidcSecurityService.revokeAccessToken(accessToken, configId);
    const refreshSiteToken$ = this.oidcSecurityService.forceRefreshSession(undefined, configId);
    const updateAccessToken$ = this.updateAccessTokenAndClaims(configId);

    return combineLatest([revokeSiteToken$, refreshSiteToken$, updateAccessToken$]).pipe(
      map(([revokeResponse, refreshToken, updatedAccessToken]) => {
        return {
          userData: refreshToken.userData,
          accessTokenAndClaims: {
            accessToken: updatedAccessToken.accessToken,
            claims: updatedAccessToken.claims,
          },
        };
      })
    );
  }

  private errorHandler = (error: any, reject: (reason?: any) => void) => {
    this.errorService.showErrorDialog();
    reject();
  };
}
