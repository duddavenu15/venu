import { Injectable, computed, inject } from '@angular/core';
import { ActivatedRouteSnapshot } from '@angular/router';
import { UserService } from '../services/user.service';

@Injectable()
export class HasFunctionsGuard {
  private userService = inject(UserService);

  canActivate(route: ActivatedRouteSnapshot): boolean {
    let hasPermission: boolean = false;
    const functionsFromRoute: string[] = route.data['functions'] as Array<string>;

    // Get the allowed functions from the route (if no functions are specified, then they are authenticated)
    if (functionsFromRoute == null) {
      hasPermission = true;
    } else {
      // Check to see if the allowed function for this route exists in the user claims
      functionsFromRoute.forEach((functionPermission) => {
        if (this.userService.siteFunctions().includes(functionPermission)) {
          hasPermission = true;
        }
      });
    }

    return hasPermission;
  }
}
