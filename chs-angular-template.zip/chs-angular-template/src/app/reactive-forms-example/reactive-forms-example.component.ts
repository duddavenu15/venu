import { CommonModule } from '@angular/common';
import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
  selector: 'app-reactive-forms-example',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatCardModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatTooltipModule,
  ],
  templateUrl: './reactive-forms-example.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./reactive-forms-example.component.scss'],
})
export class ReactiveFormsExampleComponent {
  // Signal to store JSON representation of form when valid
  formJson = signal<string>('');

  // Main reactive form group
  exampleForm: FormGroup;

  private fb = inject(FormBuilder);

  constructor() {
    // Initialize form with validators and initial values
    this.exampleForm = this.fb.group(
      {
        // Basic fields with standard validators
        firstName: ['', [Validators.required, Validators.minLength(2)]],
        lastName: ['', [Validators.required, Validators.minLength(2)]],

        // Email fields with cross-field validation
        email: ['', [Validators.required, Validators.email]],
        confirmEmail: ['', [Validators.required, Validators.email]],

        // Phone with pattern validation
        phone: ['', [Validators.pattern(/^\d{3}-\d{3}-\d{4}$/)]],

        // Form array for dynamic hobbies (collection of controls)
        hobbies: this.fb.array([
          this.fb.control('', Validators.required), // Start with one hobby field
        ]),
      },
      {
        // Add cross-field validator at the form level
        validators: this.emailMatchValidator,
      }
    );
  }

  /**
   * Custom validator to ensure email and confirmEmail match
   * This demonstrates cross-field validation between dependent controls
   */
  emailMatchValidator(control: AbstractControl): ValidationErrors | null {
    const email = control.get('email');
    const confirmEmail = control.get('confirmEmail');

    // Return null if controls don't exist (form initialization)
    if (!email || !confirmEmail) {
      return null;
    }

    // Check if both fields have values and they don't match
    if (email.value && confirmEmail.value && email.value !== confirmEmail.value) {
      // Set error on confirmEmail field specifically
      confirmEmail.setErrors({ emailMismatch: true });
      return { emailMismatch: true };
    } else {
      // Clear the emailMismatch error if emails match
      // Preserve other errors if they exist
      if (confirmEmail.hasError('emailMismatch')) {
        const errors = confirmEmail.errors;
        delete errors?.['emailMismatch'];
        confirmEmail.setErrors(Object.keys(errors || {}).length > 0 ? errors : null);
      }
    }

    return null;
  }

  /**
   * Getter for the hobbies FormArray to use in template
   */
  get hobbies(): FormArray {
    return this.exampleForm.get('hobbies') as FormArray;
  }

  /**
   * Add a new hobby control to the form array dynamically
   */
  addHobby(): void {
    this.hobbies.push(this.fb.control('', Validators.required));
  }

  /**
   * Remove a hobby control from the form array by index
   */
  removeHobby(index: number): void {
    // Prevent removing the last hobby field
    if (this.hobbies.length > 1) {
      this.hobbies.removeAt(index);
    }
  }

  /**
   * Reset the form to initial state and clear JSON output
   */
  resetForm(): void {
    // Reset form values and validation state
    this.exampleForm.reset();

    // Reset the hobbies array to just one empty field
    this.hobbies.clear();
    this.hobbies.push(this.fb.control('', Validators.required));

    // Clear the JSON output
    this.formJson.set('');
  }

  /**
   * Submit form and display JSON representation when valid
   */
  submitForm(): void {
    if (this.exampleForm.valid) {
      // Format form value as indented JSON for display
      this.formJson.set(JSON.stringify(this.exampleForm.value, null, 2));
    }
  }

  /**
   * Helper to check if a form control has an error
   * Used in template to display validation messages
   */
  hasError(controlName: string, errorType: string): boolean {
    const control = this.exampleForm.get(controlName);
    return !!(control?.hasError(errorType) && (control?.dirty || control?.touched));
  }

  /**
   * Helper to check if confirmEmail has mismatch error
   */
  hasEmailMismatch(): boolean {
    const confirmEmail = this.exampleForm.get('confirmEmail');
    return !!(confirmEmail?.hasError('emailMismatch') && (confirmEmail?.dirty || confirmEmail?.touched));
  }
}
