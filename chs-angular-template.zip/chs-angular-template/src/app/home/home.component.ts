import { CommonModule } from '@angular/common';
import { Component, VERSION, signal, ChangeDetectionStrategy } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { MatToolbarModule } from '@angular/material/toolbar';

export interface TypographyLevel {
  name: string;
  cssClass: string;
  description: string;
  sampleText: string;
}

const SAMPLE_TEXT = 'Sample Text';

const TYPOGRAPHY_DATA: TypographyLevel[] = [
  {
    name: 'headline-1',
    cssClass: 'mat-headline-1',
    description: 'One-off header, usually at the top of the page (e.g. a hero header).',
    sampleText: SAMPLE_TEXT,
  },
  {
    name: 'headline-2',
    cssClass: 'mat-headline-2',
    description: 'One-off header, usually at the top of the page (e.g. a hero header).',
    sampleText: SAMPLE_TEXT,
  },
  {
    name: 'headline-3',
    cssClass: 'mat-headline-3',
    description: 'One-off header, usually at the top of the page (e.g. a hero header).',
    sampleText: SAMPLE_TEXT,
  },
  {
    name: 'headline-4',
    cssClass: 'mat-headline-4',
    description: 'One-off header, usually at the top of the page (e.g. a hero header).',
    sampleText: SAMPLE_TEXT,
  },
  {
    name: 'headline-5',
    cssClass: 'mat-headline-5',
    description: 'Section heading corresponding to the <h1> tag.',
    sampleText: SAMPLE_TEXT,
  },
  {
    name: 'headline-6',
    cssClass: 'mat-headline-6',
    description: 'Section heading corresponding to the <h2> tag.',
    sampleText: SAMPLE_TEXT,
  },
  {
    name: 'subtitle-1',
    cssClass: 'mat-subtitle-1',
    description: 'Section heading corresponding to the <h3> tag.',
    sampleText: SAMPLE_TEXT,
  },
  {
    name: 'subtitle-2',
    cssClass: 'mat-subtitle-2',
    description: 'Section heading corresponding to the <h4> tag.',
    sampleText: SAMPLE_TEXT,
  },
  { name: 'body-1', cssClass: 'mat-body-1', description: 'Base body text.', sampleText: SAMPLE_TEXT },
  { name: 'body-2', cssClass: 'mat-body-2', description: 'Secondary body text.', sampleText: SAMPLE_TEXT },
  { name: 'caption', cssClass: 'mat-caption', description: 'Smaller body and hint text.', sampleText: SAMPLE_TEXT },
  { name: 'button', cssClass: 'mat-button', description: 'Buttons and anchors.', sampleText: SAMPLE_TEXT },
];

@Component({
  selector: 'app-shell-home',
  imports: [CommonModule, MatTableModule, MatToolbarModule],
  templateUrl: './home.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent {
  ngVersion = signal(VERSION.full);
  displayedColumns: string[] = ['name', 'description', 'sampleText'];
  dataSource = TYPOGRAPHY_DATA;
}
