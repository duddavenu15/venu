import { CommonModule } from '@angular/common';
import { Component, effect, signal, untracked, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatSidenavModule } from '@angular/material/sidenav';
import { RouterModule } from '@angular/router';
import { FooterComponent, HeaderComponent } from '@app/shared/components';

import { LayoutService, DarkModeService, UserService, ChsAuthenticationHelperService } from '@app/shared/services';

interface INavigationItem {
  link: string;
  title: string;
  icon: string;
  isOutline?: boolean;
  externalLink?: boolean;
}

@Component({
  selector: 'app-layout',
  imports: [
    CommonModule,
    FooterComponent,
    HeaderComponent,
    MatButtonModule,
    MatIconModule,
    MatListModule,
    MatSidenavModule,
    MatTooltipModule,
    RouterModule,
  ],
  templateUrl: './layout.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./layout.component.scss'],
})
export class LayoutComponent {
  layoutService = inject(LayoutService);
  private userService = inject(UserService);
  authenticationService = inject(ChsAuthenticationHelperService);
  darkModeService = inject(DarkModeService);

  navigationItems = signal<INavigationItem[]>([]);

  constructor() {
    effect(() => {
      if (this.userService.userData()) {
        untracked(() => this.setupNavigation());
      }
    });
  }

  private setupNavigation() {
    let updatedNavigationItems: INavigationItem[] = [];
    updatedNavigationItems.push(
      {
        link: '/',
        title: 'Home',
        icon: 'home',
      },
      {
        link: '/weather-forecast',
        title: 'Weather Forecast',
        icon: 'list',
      },
      {
        link: '/reactive-forms-example',
        title: 'Reactive Forms Example',
        icon: 'edit_note',
        isOutline: true,
      },
      {
        link: '/weather-forecast-remote',
        title: 'Weather Forecast (MFE Web Component)',
        icon: 'list',
      },
      {
        link: '/web-components-documentation/weather-forecast',
        title: 'Weather Forecast Documentation (MFE Route)',
        icon: 'list',
      },
      {
        link: '/football-scores-remote',
        title: 'Football Scores (MFE Web Component)',
        icon: 'list',
      },
      {
        link: 'https://devrfcr.chsinc.com/',
        title: 'RFCR',
        icon: 'contact_support',
        externalLink: true,
      },
      {
        link: 'https://devpcr.chsinc.com',
        title: 'PCR',
        icon: 'contact_support',
        externalLink: true,
      },
      {
        link: 'https://devpcr.chsinc.com/Agreements/AgreementDetails.aspx?a=42106679&s=0',
        title: 'PCR (Deep Link)',
        icon: 'contact_support',
        externalLink: true,
      }
    );

    // update our signal with new values
    this.navigationItems.set(updatedNavigationItems);
  }

  toggleDarkMode(): void {
    this.darkModeService.setDarkMode(!this.darkModeService.isDarkMode());
  }

  toggleSidenavVisibility() {
    this.layoutService.toggleSidenavVisibility();
  }

  toggleSidenavExpandCollapse() {
    this.layoutService.toggleSidenavExpandCollapse();
  }
}
