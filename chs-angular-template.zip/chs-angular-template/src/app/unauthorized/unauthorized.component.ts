import { CommonModule } from '@angular/common';
import { Component, OnInit, ChangeDetectionStrategy, inject } from '@angular/core';
import { ChsServerTimeService, DarkModeService } from '@app/shared/services';
import { environment } from '@env/environment';

@Component({
  selector: 'app-unauthorized',
  imports: [CommonModule],
  templateUrl: './unauthorized.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./unauthorized.component.scss'],
})
export class UnauthorizedComponent implements OnInit {
  darkModeService = inject(DarkModeService);
  private serverTimeService = inject(ChsServerTimeService);

  public maxAllowableClockDriftInMinutes: number;
  public doesClientHaveTimeDrift: boolean = false;

  constructor() {
    this.maxAllowableClockDriftInMinutes = environment.maxAllowableClockDriftInMinutes;
  }

  ngOnInit() {
    this.serverTimeService.doesClientHaveTimeDrift().subscribe((doesClientHaveTimeDrift: boolean) => {
      this.doesClientHaveTimeDrift = doesClientHaveTimeDrift;
    });
  }
}
