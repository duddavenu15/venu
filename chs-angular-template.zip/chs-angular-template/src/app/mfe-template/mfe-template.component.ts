import { CommonModule } from '@angular/common';
import {
  Component,
  CUSTOM_ELEMENTS_SCHEMA,
  ViewChild,
  ViewContainerRef,
  effect,
  ChangeDetectionStrategy,
  inject,
} from '@angular/core';
import { ErrorComponent } from '@app/shared/components';
import { ErrorService } from '@app/shared/errors';
import { ExposedModuleType, Remotes } from '@app/shared/models';
import { DarkModeService, UserService } from '@app/shared/services';
import { ChsWebComponentWrapper, ChsWebComponentWrapperOptions } from '@chs/angular-native-federation';

@Component({
  selector: 'app-mfe-template',
  imports: [CommonModule, ChsWebComponentWrapper],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  template: '<chs-wc-wrapper #wrapper [options]="item" [props]="props" [events]="events"></chs-wc-wrapper>',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: [],
})
export class MfeTemplateComponent {
  private userService = inject(UserService);
  private darkModeService = inject(DarkModeService);

  @ViewChild('wrapper', { read: ViewContainerRef })
  viewContainer!: ViewContainerRef;

  constructor() {
    effect(() => {
      this.props = {
        ...this.props,
        accesstoken: this.userService.siteAccessToken(),
        darkmode: this.darkModeService.darkModeLowerString(),
      };
    });
  }

  item: ChsWebComponentWrapperOptions = {
    remoteEntry: Remotes.TemplateMfe.Entry,
    exposedModule: ExposedModuleType.WebComponents,
    elementName: 'chs-weather-forecast-documentation-element',
    errorCallback: (error: any) => {
      ErrorService.logError(error);
    },
    errorComponentType: ErrorComponent,
  };

  props = {
    accesstoken: '',
    darkmode: 'false',
  };

  events = {
    errorCallback: (event: Event) => {
      const error = (event as CustomEvent).detail;
      ErrorService.logError(error);
      // in this case the remote component has error handling and shows an error message, so no need to show our error component
      //ErrorService.showErrorComponent(this.viewContainer);
    },
  };
}
