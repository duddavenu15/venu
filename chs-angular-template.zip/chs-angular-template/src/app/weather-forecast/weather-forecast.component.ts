import { CommonModule } from '@angular/common';
import { Component, OnInit, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatToolbarModule } from '@angular/material/toolbar';
import { UserService } from '@app/shared/services';
import { WeatherForecastService } from './weather-forecast.service';
import { WeatherForecast } from './weather-forecast.interface';

@Component({
  imports: [CommonModule, MatCardModule, MatTableModule, MatToolbarModule],
  selector: 'app-shell-weather-forecast',
  templateUrl: './weather-forecast.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./weather-forecast.component.scss'],
})
export class WeatherForecastComponent implements OnInit {
  private weatherForecastService = inject(WeatherForecastService);
  private userService = inject(UserService);

  forecasts!: WeatherForecast[];
  displayedColumns: string[] = ['date', 'tempC', 'tempF', 'summary'];
  error!: boolean;

  ngOnInit() {
    this.weatherForecastService.getWeatherForecast(this.userService.siteAccessToken()).subscribe({
      next: (forecasts: WeatherForecast[]) => {
        this.forecasts = forecasts;
        this.error = false;
      },
      error: (err: any) => {
        this.error = true;
      },
    });
  }
}
