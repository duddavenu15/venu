import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { WeatherForecast } from '@app/weather-forecast/weather-forecast.interface';

@Injectable({
  providedIn: 'root',
})
export class WeatherForecastService {
  private http = inject(HttpClient);

  private url: string = 'https://localhost:7115/WeatherForecast';

  getWeatherForecast(token: string): Observable<WeatherForecast[]> {
    const headers = new HttpHeaders({ Authorization: 'Bearer ' + token });
    return this.http.get<WeatherForecast[]>(this.url, { headers: headers });
  }
}
