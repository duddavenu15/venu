import { CommonModule } from '@angular/common';
import { Component, DestroyRef, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatToolbarModule } from '@angular/material/toolbar';
import { SpinnerInlineComponent } from '@app/shared/components';
import { OAuthSiteConfigId } from '@app/shared/models';
import { ChsAuthenticationHelperService, DarkModeService, UserService } from '@app/shared/services';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-settings',
  imports: [CommonModule, MatToolbarModule, MatButtonModule, SpinnerInlineComponent],
  templateUrl: './settings.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./settings.component.scss'],
})
export class SettingsComponent {
  userService = inject(UserService);
  darkModeService = inject(DarkModeService);
  private chsAuthenticationHelperService = inject(ChsAuthenticationHelperService);

  public loadingNewAccessToken = signal(false);
  private destroyRef = inject(DestroyRef);

  refreshAccessToken() {
    this.loadingNewAccessToken.set(true);
    this.chsAuthenticationHelperService
      .refreshAccessToken(OAuthSiteConfigId.site)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => {
        this.loadingNewAccessToken.set(false);
      });
  }
}
