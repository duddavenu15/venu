import {
  ChsAuthenticationHelperService,
  ChsHttpHelperService,
  ChsIdleTimerService,
  LayoutService,
  LocalStorageService,
  RequestsService,
  ChsServerTimeService,
  DeepLinkService,
  DarkModeService,
  UserService,
} from '@app/shared/services';
import { ErrorService } from '@app/shared/errors';
import { HasFunctionsGuard, IsAuthenticatedGuard } from '@app/shared/guards';
import { httpRequestInterceptorProvider } from '@app/shared/interceptors';
import { OidcSecurityService } from 'angular-auth-oidc-client';

export const appProviders = [
  OidcSecurityService,

  // our guards
  IsAuthenticatedGuard,
  HasFunctionsGuard,

  // Our services
  ChsAuthenticationHelperService,
  ChsHttpHelperService,
  ChsIdleTimerService,
  ChsServerTimeService,
  ErrorService,
  LocalStorageService,
  LayoutService,
  DeepLinkService,
  DarkModeService,
  RequestsService,
  UserService,

  // for some reason this does not put our global error handler in a scope that the standalone components can see
  // for now, there is a module that is used for this in app.bootstrap.ts "ErrorHandlerModule".  We should revisit this with Angular 15
  // and see if it works or if there are more wireup hooks to make it work.
  /* {
        provide: ErrorHandler,
        useClass: GlobalErrorHandler
    }, */

  // Interceptors
  httpRequestInterceptorProvider,
];
