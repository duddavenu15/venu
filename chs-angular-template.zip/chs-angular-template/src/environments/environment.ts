// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.deployed.ts`.
// The list of file replacements can be found in `angular.json`.
import { LogLevel } from 'angular-auth-oidc-client';
import { IEnvironment } from '@app/shared/models';

export const environment: IEnvironment = {
  production: false,
  authConfig: [
    {
      // Use openid-configuration url to discover other endpoints.
      authority: 'https://signin-auth-dev.chsinc.com/oauth2/ausf7k4gluc2rGqOT1d7/.well-known/openid-configuration',
      authWellknownEndpoints: {
        issuer: 'https://signin-auth-dev.chsinc.com/oauth2/ausf7k4gluc2rGqOT1d7',
        jwksUri: 'https://signin-auth-dev.chsinc.com/oauth2/ausf7k4gluc2rGqOT1d7/v1/keys',
        authorizationEndpoint: 'https://signin-auth-dev.chsinc.com/oauth2/ausf7k4gluc2rGqOT1d7/v1/authorize',
        tokenEndpoint: 'https://signin-auth-dev.chsinc.com/oauth2/ausf7k4gluc2rGqOT1d7/v1/token',
        userInfoEndpoint: 'https://signin-auth-dev.chsinc.com/oauth2/ausf7k4gluc2rGqOT1d7/v1/userinfo',
        revocationEndpoint: 'https://signin-auth-dev.chsinc.com/oauth2/ausf7k4gluc2rGqOT1d7/v1/revoke',
        endSessionEndpoint: 'https://signin-auth-dev.chsinc.com/oauth2/ausf7k4gluc2rGqOT1d7/v1/logout',
      },
      redirectUrl: window.location.origin,
      postLogoutRedirectUri: 'http://localhost:4200/logout',
      clientId: '0oaiv16ghlWEOlu0n1d7',
      configId: 'site',
      scope: 'openid profile email offline_access user_info use_enterprise_logging',
      responseType: 'code',
      silentRenew: true,
      // Renew our token 1 minute before it expires
      renewTimeBeforeTokenExpiresInSeconds: 60,
      useRefreshToken: true,
      logLevel: LogLevel.Debug,
      startCheckSession: false,
      customParamsEndSessionRequest: {
        client_id: '0oaiv16ghlWEOlu0n1d7',
        logout_uri: 'http://localhost:4200/logout',
      },
    },
  ],
  idleTimeoutSettings: {
    inactivityTimeBeforeShowingCountdownInSeconds: 15 * 60, // 15 minutes
    countdownTimeInSeconds: 2 * 60, // 2 minutes
    pingEventTimeInSeconds: 2 * 60, // fire the ping event every 2 minutes
  },
  remoteEntryUrls: {
    //weatherForecastMfe: 'https://mfe-dev.chsinc.com/chs-angular-mfe-template/remoteEntry.json', // deployed
    weatherForecastMfe: 'http://localhost:4201/remoteEntry.json', // local
    footballScoresMfe: 'http://localhost:4201/remoteEntry.json', // local
  },
  clockDriftApiEndpoint: 'https://oktamanagementapi.chsinc.com/api/v1/auth/serverDateTime',
  maxAllowableClockDriftInMinutes: 5,
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
