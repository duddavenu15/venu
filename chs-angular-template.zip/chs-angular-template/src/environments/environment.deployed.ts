import { LogLevel } from 'angular-auth-oidc-client';
import { IEnvironment } from '@app/shared/models';

export const environment: IEnvironment = {
  production: false,
  authConfig: [
    {
      // Use openid-configuration url to discover other endpoints.
      authority: '#{OIDC-Site-Issuer}/.well-known/openid-configuration',
      authWellknownEndpoints: {
        issuer: '#{OIDC-Site-Issuer}',
        jwksUri: '#{OIDC-Site-Issuer}/v1/keys',
        authorizationEndpoint: '#{OIDC-Site-Issuer}/v1/authorize',
        tokenEndpoint: '#{OIDC-Site-Issuer}/v1/token',
        userInfoEndpoint: '#{OIDC-Site-Issuer}/v1/userinfo',
        revocationEndpoint: '#{OIDC-Site-Issuer}/v1/revoke',
        endSessionEndpoint: '#{OIDC-Site-Issuer}/v1/logout',
      },
      redirectUrl: window.location.origin,
      postLogoutRedirectUri: '#{OIDC-Site-PostLogoutRedirectUri}',
      clientId: '#{OIDC-Site-ClientId}',
      configId: 'site',
      scope: 'openid profile email offline_access user_info use_enterprise_logging',
      responseType: 'code',
      silentRenew: true,
      // Renew our token 1 minute before it expires
      renewTimeBeforeTokenExpiresInSeconds: 60,
      useRefreshToken: true,
      logLevel: LogLevel.Error,
      startCheckSession: false,
      customParamsEndSessionRequest: {
        client_id: '#{OIDC-Site-ClientId}',
      },
    },
  ],
  idleTimeoutSettings: {
    inactivityTimeBeforeShowingCountdownInSeconds: 15 * 60, // 15 minutes
    countdownTimeInSeconds: 2 * 60, // 2 minutes
    pingEventTimeInSeconds: 2 * 60, // fire the ping event every 2 minutes
  },
  remoteEntryUrls: {
    weatherForecastMfe: '#{MFE-RemoteEntryURL-WeatherForecast}',
    footballScoresMfe: '#{MFE-RemoteEntryURL-FootballScores}',
  },
  clockDriftApiEndpoint: 'https://oktamanagementapi.chsinc.com/api/v1/auth/serverDateTime',
  maxAllowableClockDriftInMinutes: 5,
};
