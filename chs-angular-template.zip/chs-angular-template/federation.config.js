const { withNativeFederation, fromPackageJson } = require('@angular-architects/native-federation/config');

module.exports = withNativeFederation({
  name: 'chs-angular-template',

  shared: fromPackageJson({
    //singleton: true,
    //strictVersion: true,
    requiredVersion: 'auto',
    includeSecondaries: true,
  }).patch(
    ['@angular/common', '@angular/core', '@angular/forms', '@angular/platform-browser', '@angular/router'],
    { includeSecondaries: { keepAll: true } },
  ),

  features: {
    denseExternals: true,
  },

  skip: [
    // Must share main.ts's native-federation runtime instance, otherwise loadRemoteModule hangs forever.
    '@chs/angular-native-federation',
    // Add further packages you don't need at runtime
  ]
  
});
