# CHS Angular Template

## Introduction

This Angular project is intended to be a starting point for new Angular applications.

## Features

1. MyCHS look and feel
1. Okta Authentication and Authorization
1. Material Design - Including Theming
   1. Pick your theme from `src/app/styles/_variables.scss`
1. Example .NET Core API call (Must be running API project locally - see API section below)
1. Use of claims from the access_token to hide/show links and allow/disallow access to APIs. Including route Guards.
1. Silent renew of access_token when access_token expires. Currently set to 5 minutes in Okta (can be configured on Authorization Server).
1. Manual refresh of access_token on Settings page.
1. Prettier for code formatting
1. ESLint for static analysis

## API

In order to use the .NET Core API you must have the repository cloned and running locally. The API uses Okta to authorize the user.

- Repository: https://dev.azure.com/chsinc/CHS/_git/chs-oidc-api-template/branches

## Getting Started

1. Copy the contents of this repository to you new Angular application repository (Do NOT copy the .git folder).
1. Search for chs-angular-template and replace with the name of your application.
1. Update the environment.\*.ts files with your application's Okta Authorization Server information.
1. Update the azure-pipelines.yml file for package name, folder paths, etc.
1. Update this Readme file.
1. Before deploying to Production make sure to decrease the log level of the OidcAngularClient library, i.e. LogLevel.Error, LogLevel.Warn or LogLevel.None

## Module Federation and Micro front ends (MFEs)

This repository is setup to load routes and components from the https://dev.azure.com/chsinc/CHS/_git/chs-angular-mfe-template repository project.
If you are not using MFEs, you can simply remove the following or comment it out:

- src\app\shared\models\common\remotes.ts
  - This is a file defining the remotes to be loaded, it can have the exported Remotes class commented out if you are not using MFE. Otherwise adjust for your remotes.
- src\app\app.routes.ts
  - This is the routing setup, there are three paths configured for MFE: weather-forecast-remote, football-scores-remote, mfe-template. Adjust these or remove according to your needs.
- src\app\layout\layout.component.html
  - Look for the items with MFE in them, remove or alter as needed for your remotes.
- src\app\weather-forecast-remote folder
  - This is an example of wrapping a web component loaded from a remote. Remove or alter as needed. If you remove the folder, alter the barrel file (index.ts) for the removal as well.

## Wiki

todo: - Add Wiki link here

## TODOs

1. Add Wiki link to section above.
1. Handle what happens when a user does not have the authZ for a route and they manually type in the url, currently a blank screen.
1. Add different languages support.
1. Add Enterprise Logging Integration

## Angular Details

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 14.0.0.

### Development server

Run `npm run start` to run the development configuration. This will open a browser to `http://localhost:4200/`.

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

### Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

### Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

### Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

### Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

### Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
