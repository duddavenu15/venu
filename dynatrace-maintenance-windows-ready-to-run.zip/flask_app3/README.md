# CHS Dynatrace Maintenance Windows

Lets the CHS Monitoring team create and manage maintenance windows in Dynatrace.

- **Front end:** built on the **CHS Angular template** (Angular 22, Angular Material,
  MyCHS look and feel, dark mode, inactivity sign-out), in `frontend/`.
  See `frontend/README.md` for what was kept from the template and what changed.
- **Back end:** Flask JSON API. It holds the Dynatrace token, does the AD sign-in,
  the NSLookup/audit logging and all Dynatrace calls. In production Flask also
  serves the built Angular app, so there is one server and one URL.

## Pages (Angular routes)

| Page | Route | Purpose |
|------|-------|---------|
| Home | `/` | Shortcuts to each page, the User Guide card and the tutorial video |
| User Guide | `/guide` (signed in) and `/help` (public) | Illustrated how-to for end users |
| Settings | `/settings` | Your account, dark mode, inactivity timeout (user menu, top right) |
| Create Window | `/create` | Form: Generate JSON, Copy JSON, Clear, Push to Dynatrace |
| All Windows | `/list` | Every window in the tenant (all pages), with who/where it was submitted from and a delete action |
| Submission Log | `/audit` | Audit trail of pushes, deletes and sign-ins with client IP + reverse-DNS name |
| Sign in | `/login` | AD sign-in; only members of `Dynatrace_Users` get in |

## User Guide

`/guide` (inside the site) and `/help` (public, linked from the sign-in page) show an
illustrated guide: how it works, signing in, every field and button, the All Windows
and Submission Log pages, and quick fixes. It has **Download PDF** and **Print** buttons.

- Content: `frontend/src/app/user-guide/`
- Screenshots and PDF: `frontend/src/assets/guide/` (`g-*.png`, `CHS-Maintenance-Window-User-Guide.pdf`)

To update the PDF after editing the guide: open `/help` in Chrome or Edge, click
**Print**, choose **Save as PDF**, replace the PDF in `frontend/src/assets/guide/`,
then rebuild the front end.

## API endpoints (Flask)

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/me` | Who is signed in + auth mode (also sets the `XSRF-TOKEN` cookie) |
| POST | `/api/login` / `/api/logout` | AD sign-in / sign-out |
| GET | `/api/config` | Tenant, CST lock, entity types for the dropdown |
| POST | `/api/preview-maintenance-window` | Generate JSON (no push) |
| POST | `/api/maintenance-windows` | Push to Dynatrace (logs user, IP, reverse DNS) |
| GET | `/api/maintenance-windows` | List all windows (follows `nextPageKey`) |
| DELETE | `/api/maintenance-windows/<objectId>` | Delete a window |
| GET | `/api/audit` | Submission log records |
| GET | `/tutorial-video` | Download the tutorial video |

Every POST/DELETE must carry the `X-XSRF-TOKEN` header matching the
`XSRF-TOKEN` cookie; Angular's HttpClient does this automatically.

## Access control (AD group)

Every page and API call requires sign-in. Users sign in with their CHS network
account; the app binds to AD **as that user** (no service account needed) and
only lets them in if they're a member of `AD_REQUIRED_GROUP`
(default `Dynatrace_Users`). Nested group membership counts.

| Variable | Example | Notes |
|---|---|---|
| `AUTH_MODE` | `ldap` | `disabled` turns the check off for local dev only (a red banner shows) |
| `LDAP_SERVER` | `ldaps://dc01.chs.local` | Use LDAPS (636) so passwords aren't sent in clear |
| `LDAP_BASE_DN` | `DC=chs,DC=local` | |
| `LDAP_UPN_SUFFIX` | `chs.local` | Lets users type `jdoe` instead of `jdoe@chs.local` |
| `AD_REQUIRED_GROUP` | `Dynatrace_Users` | |
| `AD_GROUP_DN` | `CN=Dynatrace_Users,OU=Groups,DC=chs,DC=local` | Optional; skips the group lookup |
| `LDAP_CA_CERT_FILE` | `/etc/ssl/chs-root-ca.pem` | If the DC cert is signed by an internal CA |
| `SECRET_KEY` | long random string | **Required in prod** – signs the session cookie |
| `SESSION_HOURS` | `8` | |
| `SESSION_COOKIE_SECURE` | `1` | Set to 1 once the site is on HTTPS |

**Check the settings before switching on:** `python tools/test_ldap.py` asks for
a username and password and tests each step (reach the DC, sign in, find the
group, check membership), saying exactly which one fails.

## Submitter NSLookup / audit log

On every create and delete the app takes the client IP, does a reverse DNS
(PTR) lookup on it, and writes a JSON line to `logs/mw_audit.jsonl` with the
user, IP, resolved host name, window name, entity type/names and the Dynatrace
**objectId** of the new window. That objectId is how the List page shows
"Submitted from" next to each window. Failed/rejected submissions and sign-ins
(including denied ones) are logged too.

- Lookups time out after `DNS_TIMEOUT_SECONDS` (default 3) and never block a submission.
- Log path / rotation: `AUDIT_LOG_PATH`, `AUDIT_LOG_MAX_BYTES` (10 MB), `AUDIT_LOG_BACKUPS` (10).
- **Behind IIS / nginx / a load balancer** set `TRUST_PROXY_HOPS=1`, otherwise
  every submission will be logged with the proxy's IP instead of the user's.

## Entity type targeting

The **Entity Type** dropdown is loaded **live from Dynatrace**
(`GET /api/v2/entityTypes`, all pages) whenever the Create page opens, so it
always matches the tenant you point the app at (sandbox or production).

- **Common** (top of the list): the types in `entity_types.json` that exist in
  the tenant, with friendly labels. Edit that file to change the shortlist.
- **All entity types from Dynatrace**: every other type the tenant reports.
- **Advanced &rarr; Custom entity selector**: free-form `entitySelector`.
- The &#8635; button next to the dropdown reloads the list from Dynatrace.
- The list is cached on the server for `ENTITY_TYPES_CACHE_MINUTES` (default 60).
- If Dynatrace can't be reached (or the token lacks `entities.read`) the page
  says so and falls back to `entity_types.json`. Set `ENTITY_TYPES_SOURCE=file`
  to always use the file.

Names typed in the box are resolved with
`GET /api/v2/entities?entitySelector=type("<TYPE>"),entityName.equals("<name>")`;
raw entity IDs (e.g. `HOST_GROUP-0123456789ABCDEF`) are accepted as-is. A name
that matches several entities includes all of them. Unresolved names are
reported back; if none resolve the request is rejected with HTTP 400. Leaving the
box empty creates an environment-wide window (the UI asks for confirmation).

`tools/dump_entity_types.py --in-use` is still handy for deciding which types
belong in the Common shortlist (it shows which types actually have entities).

## Create page options (from the Dynatrace team's recommended layout)

- **Generate JSON** builds the exact payload *Create* would send (including entity
  lookups) and shows it without sending anything. **Copy JSON** copies it.
- **Clear** resets the form to the defaults: Planned, *Detect problems, don't
  alert*, Monthly on day 1, 02:00&ndash;04:00, Wednesday for weekly, range today &rarr; 2030-12-31.
- **CST only**: `FIXED_TIME_ZONE` (default `America/Chicago`) locks every window
  to that time zone. Set `FIXED_TIME_ZONE=` (empty) to show the time zone dropdown again.
- **Custom entity selector (advanced)** in the Entity Type list accepts any
  Dynatrace `entitySelector`, e.g. `type(HOST),hostGroupName("PROD-WEB")` or
  `type(HOST),mzName("PROD")`. It is resolved to the matching entities at submit
  time (max `SELECTOR_MAX_ENTITIES`, default 500) and the window is created for
  those. Entities that join the group later are **not** added automatically.
- The page shows which tenant it pushes to, so sandbox vs production is obvious.

## Listing all windows

Dynatrace returns maintenance windows a page at a time (often only **50 per
reply**). `/api/maintenance-windows` keeps calling with `nextPageKey` (and
nothing else, as Dynatrace requires) **until Dynatrace stops sending a
`nextPageKey`**, then returns everything in one list.

| Situation | What happens |
|---|---|
| Rate limited (429) or server error (5xx) on a page | Retries that page up to `LIST_PAGE_RETRIES` times (default 3), honouring `Retry-After`, then 1s / 2s / 4s |
| Network blip | Same retries |
| Dynatrace rejects `pageSize=500` | Automatically retries with `pageSize=50` |
| A page still fails after retries | The List page shows the error (no silent partial list) |
| Dynatrace sends a page key it already sent | Paging stops (loop guard) and the List page shows a warning |
| `LIST_MAX_PAGES` (default **0 = no limit**) set to a number and reached, or Dynatrace's `totalCount` is higher than what came back | The List page shows a red warning: "Only X of Y windows could be loaded" |

Duplicates (if windows are added while paging) are removed. The count next to
the filter box says e.g. "1234 windows (all loaded from Dynatrace in 25 requests)".

## Configuration

- `DYNATRACE_BASE_URL` &mdash; e.g. `https://vwh15794.live.dynatrace.com`
- `DYNATRACE_API_TOKEN` &mdash; **required** (no longer hard-coded). Scopes:
  - `settings.read`, `settings.write` (manage maintenance windows)
  - `entities.read` (resolve names, dump entity types)

Copy `.env.example` to `.env` for local development; it is loaded automatically.

## Running it

### One-time setup

```bash
pip install -r requirements.txt
cp .env.example .env            # fill in token + LDAP settings (or AUTH_MODE=disabled for dev)
```

### Build the front end

The front end uses the CHS Angular template, which needs two packages from the
**CHS-NPM** Azure DevOps feed (`@chs/angular-material-themes`,
`@chs/angular-native-federation`). Use a machine that is set up for that feed
(the same `.npmrc` / credentials you use for other CHS Angular apps) and Node 22.12+:

```bash
cd frontend
npm ci                          # installs exactly what package-lock.json lists
npm run build-deployed          # production build -> frontend/dist/dynatrace-maintenance-windows
```

`azure-pipelines.yml` does the same build in Azure DevOps.

### Run

```bash
python app.py                   # or: waitress-serve --listen=0.0.0.0:5000 app:app
```

Open <http://localhost:5000/>. Flask serves the built front end and the API from
the same address. To serve a build from somewhere else, set `FRONTEND_DIST`.

### Front-end development (live reload)

Run both, then open <http://localhost:4200/>:

```bash
python app.py                   # terminal 1 - API on :5000
cd frontend && npm start        # terminal 2 - Angular dev server on :4200
```

`frontend/proxy.conf.json` forwards `/api` and `/tutorial-video` to Flask (passing
on the caller's IP), so sign-in, cookies, CSRF and the Submission Log work the same
as in production.

## Project layout

```
flask_app3/
├── app.py                  # Flask JSON API + serves the built Angular app
├── auth.py                 # AD sign-in + Dynatrace_Users group check
├── audit.py                # reverse-DNS lookup + JSON-lines audit log
├── entity_types.json       # "Common" entity types (top of the dropdown)
├── tools/
│   ├── dump_entity_types.py
│   └── test_ldap.py        # check AD settings before AUTH_MODE=ldap
├── logs/                   # mw_audit.jsonl (created at runtime)
├── static/video/           # tutorial video
├── requirements.txt
└── frontend/               # CHS Angular template (Angular 22 + Material)
    ├── README.md           # what's kept from the template / what changed
    ├── azure-pipelines.yml
    ├── proxy.conf.json     # dev-server proxy to Flask
    ├── dist/dynatrace-maintenance-windows/   # build output (served by Flask)
    └── src/
        ├── assets/guide/   # User Guide screenshots + PDF
        └── app/
            ├── layout/, shared/          # template shell: header, side menu, footer, dialogs, services
            ├── home/, login/, logout/, settings/, unauthorized/
            ├── create-window/            # Create page
            ├── window-list/              # All Windows page
            ├── submission-log/           # Submission Log page
            └── user-guide/               # User Guide (/guide and /help)
```
