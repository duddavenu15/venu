import json
import logging
import os
import re
import ipaddress
import secrets
import socket
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import timedelta

try:  # optional: load a local .env file during development
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))
except ImportError:
    pass

from flask import Flask, abort, jsonify, request, send_from_directory, session
from werkzeug.middleware.proxy_fix import ProxyFix

import audit
import auth
from auth import AuthError, current_user, login_required

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("mw.app")

app = Flask(__name__)
app.json.sort_keys = False  # keep payload keys in the order Dynatrace documents them

# -----------------------------------------------------------------------------
# App / session configuration
# -----------------------------------------------------------------------------
_secret = os.environ.get("SECRET_KEY")
if not _secret:
    _secret = secrets.token_hex(32)
    log.warning("SECRET_KEY not set - using a random key; users will be signed out on every restart "
                "and sessions won't work across multiple worker processes.")
app.config.update(
    SECRET_KEY=_secret,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("SESSION_COOKIE_SECURE", "0") == "1",  # set 1 when served over HTTPS
    PERMANENT_SESSION_LIFETIME=timedelta(hours=int(os.environ.get("SESSION_HOURS", "8"))),
)

# If the app sits behind IIS / nginx / a load balancer, set TRUST_PROXY_HOPS=1 so
# request.remote_addr is the real client IP (from X-Forwarded-For) rather than the proxy's.
_proxy_hops = int(os.environ.get("TRUST_PROXY_HOPS", "0"))
if _proxy_hops > 0:
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=_proxy_hops, x_proto=_proxy_hops, x_host=_proxy_hops)

if auth.AUTH_MODE == "disabled":
    log.warning("AUTH_MODE=disabled - the AD group check is OFF. Never run like this in production.")

# -----------------------------------------------------------------------------
# Dynatrace configuration
# -----------------------------------------------------------------------------
DYNATRACE_BASE_URL = os.environ.get("DYNATRACE_BASE_URL", "https://vwh15794.live.dynatrace.com").rstrip("/")
DYNATRACE_API_TOKEN = os.environ.get("DYNATRACE_API_TOKEN", "")

SETTINGS_OBJECTS_URL = f"{DYNATRACE_BASE_URL}/api/v2/settings/objects"
ENTITIES_URL = f"{DYNATRACE_BASE_URL}/api/v2/entities"
SCHEMA_ID = "builtin:alerting.maintenance-window"

# Dynatrace returns maintenance windows a page at a time (often only 50 per reply, whatever
# pageSize we ask for). We keep asking with nextPageKey until Dynatrace stops sending one.
LIST_PAGE_SIZE = int(os.environ.get("LIST_PAGE_SIZE", "500"))
LIST_FALLBACK_PAGE_SIZE = 50          # used if Dynatrace rejects LIST_PAGE_SIZE
# 0 = no page limit: keep paging until Dynatrace stops sending nextPageKey.
# (A repeated nextPageKey still stops the loop.) Set a number to cap it, e.g. 1000 = 50,000 windows.
LIST_MAX_PAGES = int(os.environ.get("LIST_MAX_PAGES", "0"))
LIST_PAGE_RETRIES = int(os.environ.get("LIST_PAGE_RETRIES", "3"))  # per page, for 429 / 5xx / network blips

ENTITY_TYPES_FILE = os.environ.get(
    "ENTITY_TYPES_FILE", os.path.join(os.path.dirname(os.path.abspath(__file__)), "entity_types.json")
)
ENTITY_ID_RE = re.compile(r"^[A-Z][A-Z0-9_]*-[0-9A-F]{16}$")

# Pseudo entity type for the "Custom entity selector (advanced)" scope option
SELECTOR_SCOPE = "ENTITY_SELECTOR"
SELECTOR_MAX_ENTITIES = int(os.environ.get("SELECTOR_MAX_ENTITIES", "500"))

# The Dynatrace team's layout is CST-only. Set FIXED_TIME_ZONE="" to get the time zone dropdown back.
FIXED_TIME_ZONE = os.environ.get("FIXED_TIME_ZONE", "America/Chicago").strip()
TENANT_LABEL = urllib.parse.urlparse(DYNATRACE_BASE_URL).netloc or DYNATRACE_BASE_URL


# Entity types for the dropdown come live from Dynatrace (GET /api/v2/entityTypes).
# entity_types.json is now only the short "Common" list shown at the top of the
# dropdown (with friendly labels), and the fallback if Dynatrace can't be reached.
ENTITY_TYPES_SOURCE = os.environ.get("ENTITY_TYPES_SOURCE", "dynatrace").strip().lower()   # or "file"
ENTITY_TYPES_CACHE_SECONDS = int(os.environ.get("ENTITY_TYPES_CACHE_MINUTES", "60")) * 60
_entity_cache = {"at": 0.0, "rows": None, "error": None}
_entity_lock = threading.Lock()


def load_entity_types():
    """The curated "Common" list from entity_types.json (re-read each time, no restart needed)."""
    try:
        with open(ENTITY_TYPES_FILE, encoding="utf-8") as f:
            rows = json.load(f)
        rows = [r for r in rows if isinstance(r, dict) and r.get("type")]
        if rows:
            return rows
    except (OSError, json.JSONDecodeError) as e:
        log.error("Could not read %s: %s", ENTITY_TYPES_FILE, e)
    return [{"type": "HOST", "label": "Host / Node"}]


def fetch_entity_types_from_dynatrace():
    """Every entity type the tenant knows about, following nextPageKey."""
    rows, params, pages = [], {"pageSize": "500"}, 0
    while True:
        _, body = dt_request(f"{DYNATRACE_BASE_URL}/api/v2/entityTypes?{urllib.parse.urlencode(params)}")
        body = body if isinstance(body, dict) else {}
        for t in body.get("types", []):
            tid = t.get("type")
            if tid:
                rows.append({"type": tid, "label": t.get("displayName") or tid})
        pages += 1
        nxt = body.get("nextPageKey")
        if not nxt or pages >= 50:
            return rows
        params = {"nextPageKey": nxt}


def get_entity_types(force=False):
    """
    Returns {"common": [...], "all": [...], "source", "error", "loaded_at"}.
    "common" = types from entity_types.json that exist in the tenant (friendly labels),
    "all"    = every other type Dynatrace reports, sorted by name.
    Cached for ENTITY_TYPES_CACHE_MINUTES; falls back to the file if Dynatrace fails.
    """
    curated = load_entity_types()
    if ENTITY_TYPES_SOURCE != "dynatrace" or not DYNATRACE_API_TOKEN:
        return {"common": curated, "all": [], "source": "file", "error": None, "loaded_at": None}

    with _entity_lock:
        age = time.time() - _entity_cache["at"]
        if force or _entity_cache["rows"] is None or age > ENTITY_TYPES_CACHE_SECONDS:
            try:
                _entity_cache.update(rows=fetch_entity_types_from_dynatrace(), at=time.time(), error=None)
                log.info("Loaded %d entity types from Dynatrace", len(_entity_cache["rows"]))
            except Exception as e:  # keep the last good list if we have one
                msg = f"{type(e).__name__}: {e}"
                if isinstance(e, urllib.error.HTTPError):
                    dt_msg = (http_error_json(e).get("response_body") or {}).get("error", {})
                    dt_msg = dt_msg.get("message") if isinstance(dt_msg, dict) else None
                    msg = f"Dynatrace returned {e.code}" + (f": {dt_msg}" if dt_msg else "")
                log.warning("Could not load entity types from Dynatrace: %s", msg)
                _entity_cache["error"] = msg
                # retry in ~1 minute rather than on every request
                _entity_cache["at"] = time.time() - ENTITY_TYPES_CACHE_SECONDS + 60
        rows, error, loaded_at = _entity_cache["rows"], _entity_cache["error"], _entity_cache["at"]

    if not rows:
        return {"common": curated, "all": [], "source": "file", "error": error, "loaded_at": None}

    live = {r["type"]: r for r in rows}
    common = [c for c in curated if c["type"] in live]
    common_ids = {c["type"] for c in common}
    others = sorted((r for r in rows if r["type"] not in common_ids), key=lambda r: r["label"].lower())
    return {"common": common, "all": others, "source": "dynatrace", "error": error,
            "loaded_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(loaded_at))}


def allowed_entity_type_ids():
    g = get_entity_types()
    return {t["type"] for t in g["common"] + g["all"]}


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------
def parse_checkbox(value):
    return str(value).lower() in ("true", "on", "1", "yes")


def parse_entity_names(raw):
    """Turn the names textarea content into a clean, case-insensitively deduplicated list."""
    if not raw:
        return []
    seen, unique = set(), []
    for line in raw.replace(",", "\n").splitlines():
        name = line.strip()
        if name and name.lower() not in seen:
            seen.add(name.lower())
            unique.append(name)
    return unique


def _clean_ip(value):
    """Strip ports/brackets and IPv4-mapped IPv6 prefixes ('::ffff:10.1.2.3' -> '10.1.2.3')."""
    value = (value or "").strip().strip('"')
    if value.startswith("[") and "]" in value:          # [2001:db8::1]:1234
        value = value[1:value.index("]")]
    elif value.count(":") == 1:                         # 10.1.2.3:51234
        value = value.split(":", 1)[0]
    try:
        addr = ipaddress.ip_address(value)
        if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped:
            addr = addr.ipv4_mapped
        return str(addr)
    except ValueError:
        return value


def _is_loopback(value):
    try:
        return ipaddress.ip_address(_clean_ip(value)).is_loopback
    except ValueError:
        return False


_server_ip_cache = {}


def server_lan_ip():
    """This machine's real network address (what other PCs use to reach it), never 127.0.0.1."""
    if "ip" in _server_ip_cache:
        return _server_ip_cache["ip"]
    ip = None
    try:
        # No packet is sent: connecting a UDP socket just makes the OS pick the outbound interface.
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(("10.255.255.255", 1))
            ip = sock.getsockname()[0]
    except OSError:
        pass
    if not ip or _is_loopback(ip):
        try:
            ip = next((a[4][0] for a in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)
                       if not _is_loopback(a[4][0])), None)
        except OSError:
            ip = None
    _server_ip_cache["ip"] = ip
    return ip


def client_ip_info():
    """
    The submitting computer's IP, plus how we know it.
    Returns (ip, source, peer):
      peer   = address of whatever connected to Flask (may be a proxy)
      source = "direct" | "forwarded by local proxy" | "browser on the app server"
    - A proxy on this same server (Angular dev server, IIS, nginx) connects from 127.0.0.1;
      we then use the address it puts in X-Forwarded-For (the right-most entry, which that
      proxy added itself, so a client can't fake it).
    - If the browser itself is running on the server, we record the server's real network
      IP instead of 127.0.0.1.
    """
    peer = _clean_ip(request.remote_addr)
    if not _is_loopback(peer):
        return peer, "direct", peer

    forwarded = [p for p in (x.strip() for x in request.headers.get("X-Forwarded-For", "").split(",")) if p]
    if forwarded and not _is_loopback(forwarded[-1]):
        return _clean_ip(forwarded[-1]), "forwarded by local proxy", peer

    lan = server_lan_ip()
    if lan:
        return lan, "browser on the app server", peer
    return peer, "loopback (could not determine the server's network IP)", peer


def client_ip():
    return client_ip_info()[0]


def client_ip_fields():
    """IP + reverse DNS (nslookup) fields for the audit log."""
    ip, source, peer = client_ip_info()
    hostname, dns_note = audit.reverse_lookup(ip)
    if hostname and hostname.lower().startswith("localhost"):
        hostname = None
    if not hostname and source == "browser on the app server":
        fqdn = socket.getfqdn()
        hostname = fqdn if fqdn and not fqdn.lower().startswith("localhost") else socket.gethostname()
        dns_note = "local machine name"
    fields = {"client_ip": ip, "client_hostname": hostname, "dns_lookup": dns_note, "ip_source": source}
    if peer != ip:
        fields["peer_ip"] = peer
    return fields


def dt_request(url, method="GET", body=None):
    """Wrapper around urllib for Dynatrace API calls. Returns (status, parsed_json)."""
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Authorization": f"Api-Token {DYNATRACE_API_TOKEN}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        raw = resp.read().decode("utf-8", errors="replace").strip()
        return resp.status, (json.loads(raw) if raw else {})


def _selector_quote(value):
    # entitySelector string values: escape backslash and double quote with "~"
    return value.replace("~", "~~").replace('"', '~"')


def resolve_entities(entity_type, names):
    """
    Resolve display names (or raw entity IDs) of the chosen type to Dynatrace entity IDs.
    Returns (resolved, unresolved):
      resolved   = [{"name", "entityId", "displayName"}, ...]   (a name can match >1 entity)
      unresolved = names that matched nothing
    """
    resolved, unresolved = [], []
    for name in names:
        if ENTITY_ID_RE.match(name):
            selector = f'type("{entity_type}"),entityId("{name}")'
        else:
            selector = f'type("{entity_type}"),entityName.equals("{_selector_quote(name)}")'
        params = {"entitySelector": selector, "pageSize": "50", "fields": "+properties.detectedName"}
        url = f"{ENTITIES_URL}?{urllib.parse.urlencode(params)}"
        try:
            _, body = dt_request(url)
            entities = body.get("entities", []) if isinstance(body, dict) else []
        except (urllib.error.HTTPError, urllib.error.URLError, json.JSONDecodeError) as e:
            log.warning("Entity lookup failed for %s %r: %s", entity_type, name, e)
            entities = []
        if not entities:
            unresolved.append(name)
        for ent in entities:
            resolved.append({
                "name": name,
                "entityId": ent.get("entityId"),
                "displayName": ent.get("displayName", name),
            })
    return resolved, unresolved


def _type_from_id(entity_id):
    """HOST_GROUP-0123456789ABCDEF -> HOST_GROUP"""
    return entity_id.rsplit("-", 1)[0] if entity_id and "-" in entity_id else None


def resolve_selector(selector):
    """
    Resolve a free-form entitySelector (e.g. type(HOST),hostGroupName("PROD-WEB") or
    type(HOST),mzName("PROD")) to concrete entities, following nextPageKey.
    The window is created with one filter per entity found *now* - entities that
    appear later are not added automatically.
    Returns (resolved, truncated).
    """
    resolved = []
    params = {"entitySelector": selector, "pageSize": "500"}
    while True:
        _, body = dt_request(f"{ENTITIES_URL}?{urllib.parse.urlencode(params)}")
        body = body if isinstance(body, dict) else {}
        for ent in body.get("entities", []):
            eid = ent.get("entityId")
            resolved.append({"name": ent.get("displayName", eid), "entityId": eid,
                             "displayName": ent.get("displayName", eid),
                             "type": ent.get("type") or _type_from_id(eid)})
            if len(resolved) >= SELECTOR_MAX_ENTITIES:
                return resolved, True
        nxt = body.get("nextPageKey")
        if not nxt:
            return resolved, False
        params = {"nextPageKey": nxt}


def _hms(value):
    """'14:00' -> '14:00:00' (Dynatrace expects seconds)."""
    value = (value or "").strip()
    return f"{value}:00" if re.fullmatch(r"\d{2}:\d{2}", value) else value


def _local_datetime(value):
    """'2026-10-27T14:00' (datetime-local) -> '2026-10-27T14:00:00'."""
    value = (value or "").strip()
    return f"{value}:00" if re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}", value) else value


def build_schedule(form):
    schedule_type = form.get("schedule_type", "ONCE").upper()
    time_zone = FIXED_TIME_ZONE or form.get("time_zone", "America/Chicago")

    if schedule_type == "ONCE":
        return {
            "scheduleType": "ONCE",
            "onceRecurrence": {
                "startTime": _local_datetime(form.get("start_time")),
                "endTime": _local_datetime(form.get("end_time")),
                "timeZone": time_zone,
            },
        }

    time_window = {
        "startTime": _hms(form.get("time_window_start")),
        "endTime": _hms(form.get("time_window_end")),
        "timeZone": time_zone,
    }
    recurrence_range = {
        "scheduleStartDate": form.get("range_start_date", "").strip(),
        "scheduleEndDate": form.get("range_end_date", "").strip(),
    }

    if schedule_type == "DAILY":
        return {"scheduleType": "DAILY",
                "dailyRecurrence": {"timeWindow": time_window, "recurrenceRange": recurrence_range}}
    if schedule_type == "WEEKLY":
        return {"scheduleType": "WEEKLY",
                "weeklyRecurrence": {"dayOfWeek": form.get("day_of_week", "MONDAY").upper(),
                                     "timeWindow": time_window, "recurrenceRange": recurrence_range}}
    if schedule_type == "MONTHLY":
        return {"scheduleType": "MONTHLY",
                "monthlyRecurrence": {"dayOfMonth": int(form.get("day_of_month", "1")),
                                      "timeWindow": time_window, "recurrenceRange": recurrence_range}}
    raise ValueError(f"Unsupported schedule type: {schedule_type}")


def http_error_json(e):
    body = e.read().decode("utf-8", errors="replace").strip()
    try:
        parsed = json.loads(body) if body else {}
    except json.JSONDecodeError:
        parsed = {"raw_response": body}
    return {"error": "Dynatrace API returned an error", "status_code": e.code, "response_body": parsed}


# -----------------------------------------------------------------------------
# CSRF protection for the Angular front end
# Angular's HttpClient reads the XSRF-TOKEN cookie and sends it back in the
# X-XSRF-TOKEN header on POST/PUT/DELETE. We reject state-changing calls without it.
# -----------------------------------------------------------------------------
CSRF_COOKIE = "XSRF-TOKEN"
CSRF_HEADER = "X-XSRF-TOKEN"


def _csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(32)
    return session["csrf"]


@app.before_request
def csrf_protect():
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        sent = request.headers.get(CSRF_HEADER, "")
        expected = session.get("csrf")
        if not expected or not secrets.compare_digest(sent, expected):
            return jsonify({"error": "Security token missing or expired. Reload the page and try again."}), 403


@app.after_request
def set_csrf_cookie(response):
    response.set_cookie(CSRF_COOKIE, _csrf_token(), samesite="Lax",
                        secure=app.config["SESSION_COOKIE_SECURE"], httponly=False)
    return response


def request_data():
    """Accept JSON (Angular) or form posts; normalise values to the strings the builders expect."""
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return request.form
    out = {}
    for k, v in data.items():
        if isinstance(v, bool):
            out[k] = "true" if v else "false"
        elif v is None:
            out[k] = ""
        elif isinstance(v, list):
            out[k] = "\n".join(str(x) for x in v)
        else:
            out[k] = str(v)
    return out


# -----------------------------------------------------------------------------
# API: session / sign in / config
# -----------------------------------------------------------------------------
def _user_json(user):
    return None if not user else {"username": user["username"], "display_name": user["display_name"]}


@app.route("/api/me", methods=["GET"])
def api_me():
    """Called by the Angular app on load: who is signed in (if anyone) + site settings."""
    _csrf_token()
    return jsonify({
        "user": _user_json(current_user()),
        "auth_mode": auth.AUTH_MODE,
        "required_group": auth.AD_REQUIRED_GROUP,
    })


@app.route("/api/login", methods=["POST"])
def api_login():
    data = request_data()
    username = data.get("username", "")
    try:
        user = auth.authenticate(username, data.get("password", ""))
    except AuthError as e:
        audit.write("login_denied", user=username.strip(), **client_ip_fields(), reason=str(e))
        return jsonify({"error": str(e)}), 401

    session.clear()                 # new session id on sign-in
    session.permanent = True
    session["user"] = user
    _csrf_token()                   # fresh CSRF token for the new session
    audit.write("login", user=user["username"], **client_ip_fields())
    return jsonify({"user": _user_json(user)})


@app.route("/api/logout", methods=["POST"])
def api_logout():
    session.clear()
    return jsonify({"ok": True})


@app.route("/api/config", methods=["GET"])
@login_required
def api_config():
    groups = get_entity_types(force=request.args.get("refresh") == "1")
    return jsonify({
        "tenant_label": TENANT_LABEL,
        "tenant_url": DYNATRACE_BASE_URL,
        "fixed_time_zone": FIXED_TIME_ZONE,
        "selector_scope": SELECTOR_SCOPE,
        "selector_max": SELECTOR_MAX_ENTITIES,
        "entity_types": groups["common"] + groups["all"],
        "entity_type_groups": {"common": groups["common"], "all": groups["all"]},
        "entity_types_source": groups["source"],
        "entity_types_error": groups["error"],
        "entity_types_loaded_at": groups["loaded_at"],
    })


@app.route("/api/audit", methods=["GET"])
@login_required
def api_audit():
    limit = min(int(request.args.get("limit", "1000")), 5000)
    return jsonify({"records": audit.read_records(limit=limit)})


@app.route("/tutorial-video", methods=["GET"])
@login_required
def tutorial_video():
    """Serve the tutorial video as a download."""
    return send_from_directory(
        os.path.join(app.root_path, "static", "video"),
        "dynatrace_maintenance_windows_tutorial.mp4",
        as_attachment=True,
        download_name="Dynatrace_Maintenance_Windows_Tutorial.mp4",
    )


# -----------------------------------------------------------------------------
# API: preview / create maintenance window
# -----------------------------------------------------------------------------
class RequestRejected(Exception):
    def __init__(self, message, reason, **extra):
        super().__init__(message)
        self.reason, self.extra = reason, extra


def prepare_window(form):
    """
    Validate the form, resolve the scope to entity IDs and build the Settings API payload.
    Shared by Preview JSON and Create so both produce exactly the same thing.
    Returns (payload, meta); raises RequestRejected for user errors.
    """
    entity_type = form.get("entity_type", "HOST").strip().upper()
    name = form.get("name", "").strip()
    names = parse_entity_names(form.get("entity_names", form.get("host_names", "")))
    selector = form.get("entity_selector", "").strip()
    meta = {"window_name": name, "entity_type": entity_type, "entity_names": names,
            "entity_selector": selector or None, "resolved": [], "unresolved": [], "truncated": False}

    if not name:
        raise RequestRejected("Name is required.", "missing name", meta=meta)

    if entity_type == SELECTOR_SCOPE:
        if not selector:
            raise RequestRejected("Enter an entity selector, or pick an entity type instead.", "empty selector", meta=meta)
        meta["resolved"], meta["truncated"] = resolve_selector(selector)
        if not meta["resolved"]:
            raise RequestRejected("The entity selector matched no entities in Dynatrace.", "selector matched nothing", meta=meta)
    else:
        if entity_type not in allowed_entity_type_ids():
            raise RequestRejected(f"Entity type {entity_type} is not in the allowed list.", "entity type not allowed", meta=meta)
        if names:
            meta["resolved"], meta["unresolved"] = resolve_entities(entity_type, names)
            if not meta["resolved"]:
                raise RequestRejected(f"None of the supplied names were found in Dynatrace as {entity_type}.",
                                      "no entities resolved", meta=meta)

    seen, filters = set(), []
    for r in meta["resolved"]:
        eid = r.get("entityId")
        if eid and eid not in seen:
            seen.add(eid)
            filters.append({"entityType": r.get("type") or entity_type, "entityId": eid,
                            "entityTags": [], "managementZones": []})
    meta["entity_ids"] = list(seen)

    general = {
        "name": name,
        "maintenanceType": form.get("maintenance_type", "PLANNED").upper(),
        "suppression": form.get("suppression", "DETECT_PROBLEMS_DONT_ALERT").upper(),
        "disableSyntheticMonitorExecution": parse_checkbox(form.get("disable_synthetic_monitor_execution", "false")),
    }
    description = form.get("description", "").strip()
    if description:
        general["description"] = description

    payload = [{
        "schemaId": SCHEMA_ID,
        "schemaVersion": "2.15",
        "scope": "environment",
        "value": {"enabled": True, "generalProperties": general,
                  "schedule": build_schedule(form), "filters": filters},
    }]
    return payload, meta


def _submitter():
    # who + where: client IP (never the loopback address) and its nslookup name
    return dict({"user": current_user()["username"]}, **client_ip_fields())


def _meta_for_audit(meta):
    return {k: meta.get(k) for k in ("window_name", "entity_type", "entity_names", "entity_selector")}


@app.route("/api/preview-maintenance-window", methods=["POST"])
@login_required
def preview_maintenance_window():
    """'Generate JSON': build the exact payload Create would send, without sending it."""
    if not DYNATRACE_API_TOKEN:
        return jsonify({"error": "Missing DYNATRACE_API_TOKEN environment variable"}), 500
    try:
        payload, meta = prepare_window(request_data())
        return jsonify({"request_payload": payload, "resolved": meta["resolved"], "unresolved": meta["unresolved"],
                        "truncated": meta["truncated"], "entity_type": meta["entity_type"]}), 200
    except RequestRejected as e:
        m = e.extra.get("meta", {})
        return jsonify({"error": str(e), "unresolved": m.get("unresolved", [])}), 400
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except urllib.error.HTTPError as e:
        return jsonify(http_error_json(e)), e.code
    except urllib.error.URLError as e:
        return jsonify({"error": "Failed to reach Dynatrace API", "details": str(e)}), 502


@app.route("/api/maintenance-windows", methods=["POST"])
@app.route("/create-maintenance-window", methods=["POST"])
@login_required
def create_maintenance_window():
    if not DYNATRACE_API_TOKEN:
        return jsonify({"error": "Missing DYNATRACE_API_TOKEN environment variable"}), 500

    submitter = _submitter()
    form = request_data()
    audit_base = dict(submitter, window_name=form.get("name", "").strip(),
                      entity_type=form.get("entity_type", "").strip().upper())
    try:
        payload, meta = prepare_window(request_data())
        audit_base.update(_meta_for_audit(meta))

        status, parsed = dt_request(SETTINGS_OBJECTS_URL, method="POST", body=payload)
        object_ids = [i.get("objectId") for i in parsed if isinstance(i, dict) and i.get("objectId")] \
            if isinstance(parsed, list) else []

        audit.write("create", **audit_base, object_ids=object_ids, entity_ids=meta["entity_ids"],
                    unresolved=meta["unresolved"], schedule=payload[0]["value"]["schedule"],
                    dynatrace_status=status, tenant=DYNATRACE_BASE_URL)

        return jsonify({
            "status_code": status,
            "object_ids": object_ids,
            "entity_type": meta["entity_type"],
            "resolved": meta["resolved"],
            "unresolved": meta["unresolved"],
            "truncated": meta["truncated"],
            "submitter": submitter,
            "request_payload": payload,
            "dynatrace_response": parsed,
        }), status

    except RequestRejected as e:
        m = e.extra.get("meta", {})
        audit_base.update(_meta_for_audit(m))
        audit.write("create_rejected", **audit_base, unresolved=m.get("unresolved"), reason=e.reason)
        return jsonify({"error": str(e), "unresolved": m.get("unresolved", []), "submitter": submitter}), 400
    except ValueError as e:
        audit.write("create_rejected", **audit_base, reason=str(e))
        return jsonify({"error": str(e)}), 400
    except urllib.error.HTTPError as e:
        err = http_error_json(e)
        audit.write("create_failed", **audit_base, dynatrace_status=e.code, error=err["response_body"])
        return jsonify(dict(err, submitter=submitter)), e.code
    except urllib.error.URLError as e:
        audit.write("create_failed", **audit_base, error=str(e))
        return jsonify({"error": "Failed to reach Dynatrace API", "details": str(e)}), 502
    except Exception as e:
        log.exception("Unexpected error creating maintenance window")
        audit.write("create_failed", **audit_base, error=str(e))
        return jsonify({"error": "Unexpected error", "details": str(e)}), 500


# -----------------------------------------------------------------------------
# API: list / delete maintenance windows
# -----------------------------------------------------------------------------
def _get_page_with_retry(url):
    """
    One page from Dynatrace, retrying rate limits (429), server errors (5xx) and network blips.
    Waits for Retry-After when Dynatrace sends it, otherwise 1s, 2s, 4s...
    """
    for attempt in range(LIST_PAGE_RETRIES + 1):
        try:
            return dt_request(url)[1]
        except urllib.error.HTTPError as e:
            retryable = e.code == 429 or e.code >= 500
            if not retryable or attempt == LIST_PAGE_RETRIES:
                raise
            try:
                wait = float(e.headers.get("Retry-After") or 0)
            except (TypeError, ValueError):
                wait = 0
            wait = min(max(wait, 2 ** attempt), 30)
            log.warning("Dynatrace returned %s while paging; retrying in %.0fs", e.code, wait)
        except urllib.error.URLError as e:
            if attempt == LIST_PAGE_RETRIES:
                raise
            wait = 2 ** attempt
            log.warning("Network error while paging (%s); retrying in %ss", e.reason, wait)
        time.sleep(wait)


def fetch_all_maintenance_windows():
    """
    Page through the Settings API until Dynatrace stops returning a nextPageKey.
    Dynatrace caps each reply (often 50 items), so one call only gets the first page.
    Returns a dict: items, pages_fetched, total_count (what Dynatrace says exists),
    complete (True when every page was read), warning (text if not).
    """
    first = {
        "schemaIds": SCHEMA_ID,
        "scopes": "environment",
        "fields": "objectId,value,summary,created,modified",
        "pageSize": str(LIST_PAGE_SIZE),
    }
    url = f"{SETTINGS_OBJECTS_URL}?{urllib.parse.urlencode(first)}"
    try:
        body = _get_page_with_retry(url)
    except urllib.error.HTTPError as e:
        if e.code != 400 or LIST_PAGE_SIZE == LIST_FALLBACK_PAGE_SIZE:
            raise
        # Some tenants reject large page sizes outright: ask for Dynatrace's 50 instead.
        log.warning("Dynatrace rejected pageSize=%s; retrying with %s", LIST_PAGE_SIZE, LIST_FALLBACK_PAGE_SIZE)
        first["pageSize"] = str(LIST_FALLBACK_PAGE_SIZE)
        body = _get_page_with_retry(f"{SETTINGS_OBJECTS_URL}?{urllib.parse.urlencode(first)}")

    items, pages, total, seen_keys, warning = [], 0, None, set(), None
    while True:
        pages += 1
        body = body if isinstance(body, dict) else {}
        items.extend(body.get("items", []))
        if body.get("totalCount") is not None:
            total = body["totalCount"]
        next_key = body.get("nextPageKey")
        if not next_key:
            break                                    # Dynatrace has nothing more: done
        if next_key in seen_keys:
            warning = "Dynatrace repeated a page key, so paging was stopped to avoid a loop."
            break
        if LIST_MAX_PAGES > 0 and pages >= LIST_MAX_PAGES:
            warning = f"Stopped after {pages} pages (LIST_MAX_PAGES safety limit)."
            break
        seen_keys.add(next_key)
        # With nextPageKey, Dynatrace rejects every other query parameter.
        body = _get_page_with_retry(f"{SETTINGS_OBJECTS_URL}?{urllib.parse.urlencode({'nextPageKey': next_key})}")

    # de-duplicate in case Dynatrace's pages overlapped while windows were being added
    unique, ids = [], set()
    for it in items:
        oid = it.get("objectId")
        if oid in ids:
            continue
        ids.add(oid)
        unique.append(it)

    if total is not None and len(unique) < total and not warning:
        warning = f"Dynatrace reported {total} windows but only {len(unique)} were returned."
    if warning:
        log.warning("Maintenance window list incomplete: %s", warning)
    return {"items": unique, "pages_fetched": pages, "total_count": total if total is not None else len(unique),
            "complete": warning is None, "warning": warning}


@app.route("/api/maintenance-windows", methods=["GET"])
@login_required
def list_maintenance_windows():
    if not DYNATRACE_API_TOKEN:
        return jsonify({"error": "Missing DYNATRACE_API_TOKEN environment variable"}), 500

    try:
        result = fetch_all_maintenance_windows()
        raw_items = result["items"]
        submitted = audit.index_by_object_id()

        items = []
        for item in raw_items:
            value = item.get("value", {}) or {}
            general = value.get("generalProperties", {}) or {}
            schedule = value.get("schedule", {}) or {}
            filters = value.get("filters", []) or []
            rec = submitted.get(item.get("objectId"))
            items.append({
                "objectId": item.get("objectId"),
                "name": general.get("name", ""),
                "description": general.get("description", ""),
                "maintenanceType": general.get("maintenanceType", ""),
                "suppression": general.get("suppression", ""),
                "enabled": value.get("enabled", False),
                "scheduleType": schedule.get("scheduleType", ""),
                "schedule": schedule,
                "filters": [{"entityType": f.get("entityType"), "entityId": f.get("entityId")} for f in filters],
                "summary": item.get("summary", ""),
                "created": item.get("created"),
                "modified": item.get("modified"),
                "submittedBy": None if not rec else {
                    "user": rec.get("user"),
                    "client_ip": rec.get("client_ip"),
                    "client_hostname": rec.get("client_hostname"),
                    "timestamp": rec.get("timestamp"),
                    "entity_names": rec.get("entity_names"),
                    "entity_selector": rec.get("entity_selector"),
                },
            })

        items.sort(key=lambda i: (i["name"] or "").lower())
        return jsonify({"status_code": 200, "items": items, "pages_fetched": result["pages_fetched"],
                        "total_count": result["total_count"], "complete": result["complete"],
                        "warning": result["warning"]}), 200

    except urllib.error.HTTPError as e:
        return jsonify(http_error_json(e)), e.code
    except urllib.error.URLError as e:
        return jsonify({"error": "Failed to reach Dynatrace API", "details": str(e)}), 502
    except Exception as e:
        log.exception("Unexpected error listing maintenance windows")
        return jsonify({"error": "Unexpected error", "details": str(e)}), 500


@app.route("/api/maintenance-windows/<path:object_id>", methods=["DELETE"])
@login_required
def delete_maintenance_window(object_id):
    if not DYNATRACE_API_TOKEN:
        return jsonify({"error": "Missing DYNATRACE_API_TOKEN environment variable"}), 500

    audit_base = dict({"user": current_user()["username"]}, **client_ip_fields(),
                      object_ids=[object_id], window_name=request.args.get("name", ""))
    try:
        url = f"{SETTINGS_OBJECTS_URL}/{urllib.parse.quote(object_id, safe='')}"
        status, _ = dt_request(url, method="DELETE")
        audit.write("delete", **audit_base, dynatrace_status=status)
        return jsonify({"status_code": status, "objectId": object_id}), status
    except urllib.error.HTTPError as e:
        err = http_error_json(e)
        audit.write("delete_failed", **audit_base, dynatrace_status=e.code)
        return jsonify(err), e.code
    except urllib.error.URLError as e:
        return jsonify({"error": "Failed to reach Dynatrace API", "details": str(e)}), 502
    except Exception as e:
        return jsonify({"error": "Unexpected error", "details": str(e)}), 500


# -----------------------------------------------------------------------------
# Angular front end
# The built app (frontend/dist/mw-ui/browser) is served from "/". Any path that
# isn't an API route or a real file gets index.html so Angular's router handles it.
# -----------------------------------------------------------------------------
# Built by `npm run build-deployed` (or `npm run build` for a local build) in frontend/.
FRONTEND_DIST = os.environ.get(
    "FRONTEND_DIST",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "frontend", "dist", "dynatrace-maintenance-windows"),
)


@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def angular_app(path):
    if path.startswith("api/"):
        return jsonify({"error": "Not found"}), 404
    index = os.path.join(FRONTEND_DIST, "index.html")
    if not os.path.exists(index):
        return ("Front end not built. Run: cd frontend && npm ci && npm run build-deployed", 503)
    if path and os.path.isfile(os.path.join(FRONTEND_DIST, path)):
        return send_from_directory(FRONTEND_DIST, path)
    if "." in path.rsplit("/", 1)[-1]:
        abort(404)  # a missing asset, not an app route
    response = send_from_directory(FRONTEND_DIST, "index.html")
    response.headers["Cache-Control"] = "no-cache"
    return response


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=os.environ.get("FLASK_DEBUG", "0") == "1")
