#!/usr/bin/env python3
"""
Check the AD sign-in settings in .env before turning on AUTH_MODE=ldap.

    python tools/test_ldap.py

It asks for a username and password, then checks each step separately and
tells you which one fails:
  1. settings present      2. can reach the domain controller
  3. username/password OK  4. Dynatrace_Users group found
  5. this user is a member (nested groups count)

Nothing is changed in AD; this only reads.
"""
import getpass
import os
import socket
import ssl
import sys
import urllib.parse

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(HERE, ".env"))
except ImportError:
    pass

from ldap3 import ALL, SUBTREE, Connection, Server, Tls          # noqa: E402
from ldap3.utils.conv import escape_filter_chars                  # noqa: E402

OK, BAD = "  [ OK ]", "  [FAIL]"
IN_CHAIN = "1.2.840.113556.1.4.1941"


def env(name, default=""):
    return os.environ.get(name, default).strip()


def main():
    server_url = env("LDAP_SERVER")
    base_dn = env("LDAP_BASE_DN")
    upn = env("LDAP_UPN_SUFFIX").lstrip("@")
    group = env("AD_REQUIRED_GROUP", "Dynatrace_Users")
    group_dn = env("AD_GROUP_DN")
    starttls = env("LDAP_USE_STARTTLS", "0") == "1"
    ca_file = env("LDAP_CA_CERT_FILE") or None

    print("\n1. Settings from .env")
    for k, v in [("LDAP_SERVER", server_url), ("LDAP_BASE_DN", base_dn), ("LDAP_UPN_SUFFIX", upn),
                 ("AD_REQUIRED_GROUP", group), ("AD_GROUP_DN", group_dn or "(looked up)"),
                 ("LDAP_USE_STARTTLS", starttls), ("LDAP_CA_CERT_FILE", ca_file or "(system default)")]:
        print(f"     {k:18} = {v}")
    if not server_url or not base_dn:
        print(BAD, "LDAP_SERVER and LDAP_BASE_DN must be set in .env"); return 1
    print(OK, "required settings present")

    # 2. network
    print("\n2. Reaching the domain controller")
    u = urllib.parse.urlparse(server_url if "://" in server_url else "ldap://" + server_url)
    port = u.port or (636 if u.scheme == "ldaps" else 389)
    try:
        socket.create_connection((u.hostname, port), timeout=8).close()
        print(OK, f"{u.hostname}:{port} is reachable")
    except OSError as e:
        print(BAD, f"cannot connect to {u.hostname}:{port} ({e})")
        print("        Check the server name, DNS, and that the firewall allows this port.")
        return 1

    # 3. bind
    print("\n3. Signing in as you")
    username = input("     Username (e.g. jdoe): ").strip()
    password = getpass.getpass("     Password (not shown): ")
    if not username or not password:
        print(BAD, "username and password are both needed"); return 1
    if "\\" in username:
        sam, bind = username.split("\\", 1)[1], username
    elif "@" in username:
        sam, bind = username.split("@", 1)[0], username
    else:
        sam, bind = username, (f"{username}@{upn}" if upn else username)
    print(f"     binding as: {bind}")

    tls = Tls(validate=ssl.CERT_REQUIRED, ca_certs_file=ca_file)
    server = Server(server_url, get_info=ALL, tls=tls, connect_timeout=10)
    conn = Connection(server, user=bind, password=password, raise_exceptions=False, receive_timeout=15)
    try:
        conn.open()
        if starttls and u.scheme != "ldaps":
            conn.start_tls()
    except Exception as e:
        print(BAD, f"could not open a secure connection: {type(e).__name__}: {e}")
        if "certificate" in str(e).lower() or "ssl" in str(e).lower():
            print("        The DC's certificate isn't trusted. Export your company's root CA as a")
            print("        Base-64 .cer/.pem file and set LDAP_CA_CERT_FILE to its path.")
        return 1
    if not conn.bind():
        res = conn.result or {}
        print(BAD, f"sign-in rejected: {res.get('description')} {res.get('message', '')}".strip())
        print("        Check the username/password, and that LDAP_UPN_SUFFIX matches your domain.")
        return 1
    print(OK, "username and password accepted")

    # 4. group
    print("\n4. Finding the access group")
    if not group_dn:
        conn.search(base_dn, f"(&(objectClass=group)(|(sAMAccountName={escape_filter_chars(group)})"
                             f"(cn={escape_filter_chars(group)})))", SUBTREE, attributes=["distinguishedName"], size_limit=1)
        if not conn.entries:
            print(BAD, f"group '{group}' not found under {base_dn}")
            print("        Check AD_REQUIRED_GROUP and LDAP_BASE_DN, or set AD_GROUP_DN to the group's full DN.")
            return 1
        group_dn = conn.entries[0].entry_dn
    print(OK, f"group: {group_dn}")

    # 5. membership
    print("\n5. Checking you are a member")
    conn.search(base_dn, f"(&(objectCategory=person)(objectClass=user)(sAMAccountName={escape_filter_chars(sam)})"
                         f"(memberOf:{IN_CHAIN}:={escape_filter_chars(group_dn)}))",
                SUBTREE, attributes=["displayName"], size_limit=1)
    if not conn.entries:
        print(BAD, f"{sam} is NOT a member of {group} (directly or through nested groups)")
        print("        Sign-in works, but this user would be refused by the site. Request the group.")
        return 1
    print(OK, f"{conn.entries[0].displayName} is a member. The site will let this user in.")
    conn.unbind()
    print("\nAll good. Set AUTH_MODE=ldap in .env and restart the app.\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
