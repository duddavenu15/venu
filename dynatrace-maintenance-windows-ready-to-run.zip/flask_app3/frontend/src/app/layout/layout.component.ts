import { CommonModule } from '@angular/common';
import { Component, effect, signal, untracked, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatSidenavModule } from '@angular/material/sidenav';
import { RouterModule } from '@angular/router';
import { FooterComponent, HeaderComponent } from '@app/shared/components';

import { LayoutService, DarkModeService, UserService, ChsAuthenticationHelperService } from '@app/shared/services';

interface INavigationItem {
  link: string;
  title: string;
  icon: string;
  isOutline?: boolean;
  externalLink?: boolean;
}

@Component({
  selector: 'app-layout',
  imports: [
    CommonModule,
    FooterComponent,
    HeaderComponent,
    MatButtonModule,
    MatIconModule,
    MatListModule,
    MatSidenavModule,
    MatTooltipModule,
    RouterModule,
  ],
  templateUrl: './layout.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./layout.component.scss'],
})
export class LayoutComponent {
  layoutService = inject(LayoutService);
  userService = inject(UserService);
  authenticationService = inject(ChsAuthenticationHelperService);
  darkModeService = inject(DarkModeService);

  navigationItems = signal<INavigationItem[]>([]);

  constructor() {
    effect(() => {
      if (this.userService.userData()) {
        untracked(() => this.setupNavigation());
      }
    });
  }

  private setupNavigation() {
    this.navigationItems.set([
      { link: '/', title: 'Home', icon: 'home' },
      { link: '/create', title: 'Create Window', icon: 'event_available', isOutline: true },
      { link: '/list', title: 'All Windows', icon: 'list_alt' },
      { link: '/audit', title: 'Submission Log', icon: 'receipt_long', isOutline: true },
      { link: '/guide', title: 'User Guide', icon: 'menu_book', isOutline: true },
    ]);
  }

  toggleDarkMode(): void {
    this.darkModeService.setDarkMode(!this.darkModeService.isDarkMode());
  }

  toggleSidenavVisibility() {
    this.layoutService.toggleSidenavVisibility();
  }

  toggleSidenavExpandCollapse() {
    this.layoutService.toggleSidenavExpandCollapse();
  }
}
