/** The signed-in user, as returned by Flask after the AD (LDAP) sign-in. */
export interface User {
  username: string;
  display_name: string;
}

/** GET /api/me */
export interface MeResponse {
  user: User | null;
  auth_mode: string;
  required_group: string;
}
