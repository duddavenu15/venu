export interface IEnvironment {
  production: boolean;
  /** Prefix for API calls. '' = same server as the site (Flask serves both). */
  apiBaseUrl: string;
  idleTimeoutSettings: {
    inactivityTimeBeforeShowingCountdownInSeconds: number;
    countdownTimeInSeconds: number;
    pingEventTimeInSeconds: number;
  };
  /** Who to contact for help, shown in the Contact us dialog and the guide. */
  contacts: string;
}
