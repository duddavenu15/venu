import { HTTP_INTERCEPTORS, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { ChsAuthenticationHelperService } from '../services/chs-authentication-helper.service';
import { ChsHttpHelperService } from '../services/chs-http-helper.service';
import { RequestsService } from '../services/requests.service';

@Injectable({
  providedIn: 'root',
})
export class AuthInterceptor implements HttpInterceptor {
  private httpHelperService = inject(ChsHttpHelperService);
  private requestsService = inject(RequestsService);
  private authService = inject(ChsAuthenticationHelperService);

  /**
   * - Shows the spinner-overlay while requests are in flight (as in the CHS template).
   *   To skip it for a request, send `headers: this.httpHelperService.ignoreSpinnerHttpHeader`.
   * - The session is a cookie set by Flask after the AD sign-in, so no Authorization header
   *   is added. Angular's XSRF support sends the X-XSRF-TOKEN header on POST/DELETE.
   * - A 401 from any API call (session ended) sends the user back to the sign-in page.
   */
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<any> {
    const spinnerIgnored = this.httpHelperService.IsSpinnerIgnoredOnRequest(request);
    request = this.httpHelperService.stripMarkerHeaders(request);
    if (!spinnerIgnored) {
      this.requestsService.increment();
    }

    const isAuthCall = request.url.includes('/api/login') || request.url.includes('/api/me');

    return next.handle(request).pipe(
      tap({
        next: (event) => {
          if (event instanceof HttpResponse && !spinnerIgnored) {
            this.requestsService.decrement();
          }
        },
        error: (err: HttpErrorResponse) => {
          if (!spinnerIgnored) {
            this.requestsService.decrement();
          }
          if (err.status === 401 && !isAuthCall) {
            this.authService.sessionExpired();
          }
        },
      })
    );
  }
}

export const httpRequestInterceptorProvider = {
  provide: HTTP_INTERCEPTORS,
  useClass: AuthInterceptor,
  multi: true,
};
