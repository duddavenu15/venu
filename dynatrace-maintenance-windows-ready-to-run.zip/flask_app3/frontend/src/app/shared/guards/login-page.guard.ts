import { Injectable, inject } from '@angular/core';
import { Router, UrlTree } from '@angular/router';
import { Observable, map } from 'rxjs';
import { ChsAuthenticationHelperService } from '../services/chs-authentication-helper.service';

/** Keeps people who are already signed in off the sign-in page. */
@Injectable()
export class LoginPageGuard {
  private authService = inject(ChsAuthenticationHelperService);
  private router = inject(Router);

  canActivate(): Observable<boolean | UrlTree> {
    return this.authService.loadSession().pipe(map((user) => (user ? this.router.createUrlTree(['/']) : true)));
  }
}
