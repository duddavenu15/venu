import { Injectable, inject } from '@angular/core';
import { ActivatedRouteSnapshot } from '@angular/router';
import { ChsAuthenticationHelperService } from '../services/chs-authentication-helper.service';
import { Observable } from 'rxjs';

@Injectable()
export class IsAuthenticatedGuard {
  private chsAuthenticationHelperService = inject(ChsAuthenticationHelperService);

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    return this.chsAuthenticationHelperService.checkAuthentication();
  }
}
