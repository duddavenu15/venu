import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class LocalStorageService {
  // Local storage keys
  private baseKey: string = window.location.hostname; // 'chsconnect-dev.chsinc.com'

  public get(key: string): string | null {
    return localStorage.getItem(this.baseKey + key);
  }

  public set(key: string, value: string): void {
    localStorage.setItem(this.baseKey + key, value);
  }

  public remove(key: string): void {
    localStorage.removeItem(this.baseKey + key);
  }
}
