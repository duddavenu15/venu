import { BreakpointObserver } from '@angular/cdk/layout';
import { Injectable, computed, signal, inject } from '@angular/core';
import { CHSBreakpoints } from '@chs/angular-material-themes';

@Injectable({
  providedIn: 'root',
})
export class LayoutService {
  private observer = inject(BreakpointObserver);

  #showSidenav = signal(true);
  #expandedSidenav = signal(true);
  #isDesktop = signal(true);
  #isMobile = signal(false);

  public showSidenav = computed(this.#showSidenav);
  public expandedSidenav = computed(this.#expandedSidenav);
  public isDesktop = computed(this.#isDesktop);
  public isMobile = computed(this.#isMobile);

  constructor() {
    // Watch our breakpoints for changes, then update our values.
    this.observer
      .observe([
        CHSBreakpoints.ExtraSmall, // `(max-width: 575.98px)`
        CHSBreakpoints.Small, // `(min-width: 576px) and (max-width: 767.98px)`
        CHSBreakpoints.Medium, // `(min-width: 768px) and (max-width: 991.98px)`
        CHSBreakpoints.Large, // `(min-width: 992px) and (max-width: 1199.98px)`
        CHSBreakpoints.ExtraLarge, // `(min-width: 1200px) and (max-width: 1399.98px)`
        CHSBreakpoints.ExtraExtraLarge, // `(min-width: 1400px)`
      ])
      .subscribe((result) => {
        for (const query of Object.keys(result.breakpoints)) {
          if (result.breakpoints[query]) {
            const isMobile =
              query == CHSBreakpoints.ExtraSmall || query == CHSBreakpoints.Small || query == CHSBreakpoints.Medium;
            const isDesktop = !isMobile;

            this.#isMobile.set(isMobile);
            this.#isDesktop.set(isDesktop);
            this.#showSidenav.set(isDesktop);
          }
        }
      });
  }

  // Functions
  public toggleSidenavVisibility() {
    // When mobile, toggle.  When not mobile, always show sidenav.
    const showSidenav = this.#isMobile() ? !this.#showSidenav() : true;
    this.#showSidenav.set(showSidenav);
  }

  public toggleSidenavExpandCollapse() {
    // When desktop, toggle.  When not desktop, always have sidenav expanded.
    const expandedSidenav = this.#isDesktop() ? !this.#expandedSidenav() : true;
    this.#expandedSidenav.set(expandedSidenav);
  }
}
