import { Injectable, computed, effect, signal, inject } from '@angular/core';
import { LocalStorageService } from './local-storage.service';
import { OverlayContainer } from '@angular/cdk/overlay';

@Injectable({
  providedIn: 'root',
})
export class DarkModeService {
  private overlayContainer = inject(OverlayContainer);
  private localStorageService = inject(LocalStorageService);

  // Observables and their current values
  #isDarkMode = signal(false);
  public isDarkMode = computed(this.#isDarkMode);
  public darkModeLowerString = computed(() => this.#isDarkMode().toString().toLowerCase());

  #localStorageKey: string = 'dark-mode';

  constructor() {
    // Wire up the initial values to our observable behavior subjects
    const browserWantsDarkMode: boolean =
      window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    const localStorageDarkModeValue: string | null = this.localStorageService.get(this.#localStorageKey);

    if (browserWantsDarkMode && localStorageDarkModeValue === null) {
      this.setDarkMode(true);
    } else {
      this.setDarkMode(localStorageDarkModeValue === 'true');
    }

    effect(() => {
      if (this.#isDarkMode()) {
        this.overlayContainer.getContainerElement().classList.add('dark-mode');
      } else {
        this.overlayContainer.getContainerElement().classList.remove('dark-mode');
      }
    });
  }

  // Setters
  public setDarkMode(value: boolean) {
    this.localStorageService.set(this.#localStorageKey, value.toString());
    this.#isDarkMode.set(value);
  }
}
