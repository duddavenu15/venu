import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '@env/environment';
import { Observable, catchError, firstValueFrom, map, of } from 'rxjs';
import { MeResponse, User } from '../models';
import { DeepLinkService } from './deep-link.service';
import { UserService } from './user.service';

/**
 * Sign-in for this site.
 *
 * The CHS template signs in with Okta in the browser. This site keeps the existing
 * server-side sign-in instead: Flask checks the user's AD (LDAP) password and their
 * membership of the Dynatrace_Users group, then keeps a session cookie.
 * The public members (loginFlowComplete, checkAuthentication, logout) match the
 * template's service, so the layout, guards and idle timer work unchanged.
 */
@Injectable({
  providedIn: 'root',
})
export class ChsAuthenticationHelperService {
  private http = inject(HttpClient);
  private router = inject(Router);
  private userService = inject(UserService);
  private deepLinkService = inject(DeepLinkService);

  #loginFlowComplete = signal(false);
  public loginFlowComplete = computed(this.#loginFlowComplete);

  private api = environment.apiBaseUrl;

  /** Ask Flask who is signed in. Also makes Flask set the XSRF-TOKEN cookie. */
  loadSession(): Observable<User | null> {
    return this.http.get<MeResponse>(`${this.api}/api/me`).pipe(
      map((me) => {
        this.userService.setAuthInfo(me.auth_mode, me.required_group);
        this.userService.setUserData(me.user ?? undefined);
        this.#loginFlowComplete.set(!!me.user);
        return me.user;
      }),
      catchError(() => {
        this.userService.clear();
        this.#loginFlowComplete.set(false);
        return of(null);
      })
    );
  }

  isAuthenticated(): Observable<boolean> {
    return of(this.loginFlowComplete());
  }

  /** Used by IsAuthenticatedGuard: signed in -> continue, otherwise go to the sign-in page. */
  checkAuthentication(): Observable<boolean> {
    if (this.loginFlowComplete()) {
      return of(true);
    }
    return this.loadSession().pipe(
      map((user) => {
        if (user) {
          return true;
        }
        // remember where the user was going so we can send them back after sign-in
        this.deepLinkService.setDeepLinkUrl();
        this.router.navigate(['/login']);
        return false;
      })
    );
  }

  /** Sign in with AD username/password. Throws with a readable message on failure. */
  async login(username: string, password: string): Promise<void> {
    try {
      const res = await firstValueFrom(this.http.post<{ user: User }>(`${this.api}/api/login`, { username, password }));
      this.userService.setUserData(res.user);
      this.#loginFlowComplete.set(true);
      if (!this.deepLinkService.redirectToDeepLinkUrl()) {
        this.router.navigate(['/']);
      }
    } catch (e) {
      const err = e as HttpErrorResponse;
      throw new Error(err.error?.error || (err.status === 0 ? 'Could not reach the server.' : 'Sign-in failed.'));
    }
  }

  logout() {
    this.http.post(`${this.api}/api/logout`, {}).subscribe({
      complete: () => this.finishLogout(),
      error: () => this.finishLogout(),
    });
  }

  /** Called when the server says the session has ended (HTTP 401). */
  sessionExpired() {
    if (!this.loginFlowComplete()) {
      return;
    }
    this.userService.clear();
    this.#loginFlowComplete.set(false);
    this.deepLinkService.setDeepLinkUrl();
    this.router.navigate(['/login'], { queryParams: { expired: 1 } });
  }

  private finishLogout() {
    this.userService.clear();
    this.#loginFlowComplete.set(false);
    this.router.navigate(['/logout']);
  }
}
