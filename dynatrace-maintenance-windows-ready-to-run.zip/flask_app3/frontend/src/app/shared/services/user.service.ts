import { Injectable, computed, signal } from '@angular/core';
import { User } from '@app/shared/models';

/** Holds the signed-in user (set by ChsAuthenticationHelperService). */
@Injectable({
  providedIn: 'root',
})
export class UserService {
  #userData = signal<User | undefined>(undefined);
  #authMode = signal<string>('ldap');
  #requiredGroup = signal<string>('Dynatrace_Users');

  public userData = computed(this.#userData);
  public userName = computed(() => this.#userData()?.display_name || this.#userData()?.username || '');
  public userId = computed(() => this.#userData()?.username ?? '');
  public firstName = computed(() => (this.userName().split(' ')[0] ?? '').replace(/[()]/g, ''));
  /** "ldap" normally; "disabled" only for local testing (AD check switched off on the server). */
  public authMode = computed(this.#authMode);
  public authDisabled = computed(() => this.#authMode() === 'disabled');
  public requiredGroup = computed(this.#requiredGroup);

  clear() {
    this.#userData.set(undefined);
  }

  public setUserData(userData: User | undefined) {
    this.#userData.set(userData);
  }

  public setAuthInfo(authMode: string, requiredGroup: string) {
    this.#authMode.set(authMode);
    this.#requiredGroup.set(requiredGroup);
  }
}
