import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { environment } from '@env/environment';
import { Observable, shareReplay } from 'rxjs';
import { AuditRecord, CreateResponse, ListResponse, PreviewResponse, SiteConfig, WindowForm } from '../models';

/**
 * Calls to the Flask API. Flask holds the Dynatrace token, does the AD check,
 * the NSLookup of the caller's IP and the audit log. The browser never talks to Dynatrace.
 */
@Injectable({
  providedIn: 'root',
})
export class ApiService {
  private http = inject(HttpClient);
  private api = environment.apiBaseUrl;
  private config$?: Observable<SiteConfig>;

  /** Tenant, CST lock and entity types (loaded live from Dynatrace). Pass true to reload from Dynatrace. */
  config(reloadFromDynatrace = false): Observable<SiteConfig> {
    if (!this.config$ || reloadFromDynatrace) {
      const params = reloadFromDynatrace ? new HttpParams().set('refresh', '1') : undefined;
      this.config$ = this.http.get<SiteConfig>(`${this.api}/api/config`, { params }).pipe(shareReplay(1));
    }
    return this.config$;
  }

  /** "Generate JSON": builds the payload (with entity lookups) without sending it to Dynatrace. */
  preview(form: WindowForm): Observable<PreviewResponse> {
    return this.http.post<PreviewResponse>(`${this.api}/api/preview-maintenance-window`, form);
  }

  /** "Push to Dynatrace". */
  create(form: WindowForm): Observable<CreateResponse> {
    return this.http.post<CreateResponse>(`${this.api}/api/maintenance-windows`, form);
  }

  /** Every window in the tenant; Flask follows nextPageKey until Dynatrace has no more pages. */
  list(): Observable<ListResponse> {
    return this.http.get<ListResponse>(`${this.api}/api/maintenance-windows`);
  }

  delete(objectId: string, name: string): Observable<unknown> {
    return this.http.delete(`${this.api}/api/maintenance-windows/${encodeURIComponent(objectId)}`, {
      params: new HttpParams().set('name', name),
    });
  }

  audit(limit = 1000): Observable<{ records: AuditRecord[] }> {
    return this.http.get<{ records: AuditRecord[] }>(`${this.api}/api/audit`, {
      params: new HttpParams().set('limit', limit),
    });
  }
}
