import { Injectable, inject } from '@angular/core';
import { LocalStorageService } from './local-storage.service';
import { Params, Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class DeepLinkService {
  private localStorageService = inject(LocalStorageService);
  private router = inject(Router);

  private redirectUrlLocalStorageKey: string = 'redirect-url';
  private redirectUrlSearchParamsLocalStorageKey: string = 'redirect-url-search-params';

  // Setters
  public setDeepLinkUrl() {
    // don't redirect to logout/login, this happens if you click sign in button from logout page
    const path = window.location.pathname;
    const pathToSave = path === '/logout' || path === '/login' ? '' : encodeURIComponent(path);

    const searchParamsToSave = encodeURIComponent(window.location.search.substring(1));
    this.localStorageService.set(this.redirectUrlLocalStorageKey, pathToSave);
    this.localStorageService.set(this.redirectUrlSearchParamsLocalStorageKey, searchParamsToSave);
  }

  /** Returns true when it navigated to a saved deep link. */
  public redirectToDeepLinkUrl(): boolean {
    const redirectUrl = this.localStorageService.get(this.redirectUrlLocalStorageKey);
    const redirectUrlSearchParams = this.localStorageService.get(this.redirectUrlSearchParamsLocalStorageKey);
    this.localStorageService.remove(this.redirectUrlLocalStorageKey);
    this.localStorageService.remove(this.redirectUrlSearchParamsLocalStorageKey);

    if (redirectUrl) {
      const decodedRedirectUrl = decodeURIComponent(redirectUrl);

      if (decodedRedirectUrl !== '/') {
        if (redirectUrlSearchParams) {
          const decodedRedirectUrlSearchParams = decodeURIComponent(redirectUrlSearchParams);

          let params = decodedRedirectUrlSearchParams.split('&');
          let queryParams: Params = {};
          params.forEach((d) => {
            const pair = d.split('=');
            queryParams[`${pair[0]}`] = pair[1];
          });

          this.router.navigate([decodedRedirectUrl], { queryParams });
        } else {
          this.router.navigate([decodedRedirectUrl]);
        }
        return true;
      }
    }
    return false;
  }
}
