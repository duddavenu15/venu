import { Injectable, computed, effect, signal } from '@angular/core';
import { toObservable } from '@angular/core/rxjs-interop';
import { delay, distinctUntilChanged, filter } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RequestsService {
  #inFlightRequests = signal(0);
  #showSpinner = signal(false);

  public showSpinner = computed(this.#showSpinner);
  public inFlightRequests = computed(this.#inFlightRequests);

  constructor() {
    toObservable(this.#inFlightRequests)
      .pipe(
        filter((x) => x >= 0),
        distinctUntilChanged(),
        delay(250) // Delay to help prevent flickering when making multiple quick requests.  Also prevents expression changed error.
      )
      .subscribe((requests) => {
        this.#showSpinner.set(requests !== 0);
      });
  }

  increment() {
    this.#inFlightRequests.update((current) => current + 1);
  }

  decrement() {
    this.#inFlightRequests.update((current) => (current > 0 ? current - 1 : current));
  }
}
