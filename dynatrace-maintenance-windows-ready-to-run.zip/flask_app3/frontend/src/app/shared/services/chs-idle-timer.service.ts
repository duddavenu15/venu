import { Injectable, effect, signal, inject } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Title } from '@angular/platform-browser';
import { InactivityModalComponent } from '../components/inactivity-modal/inactivity-modal.component';
import { environment } from '@env/environment';
import { UserIdleService } from 'angular-user-idle';
import { ChsAuthenticationHelperService } from './chs-authentication-helper.service';

@Injectable({
  providedIn: 'root',
})
export class ChsIdleTimerService {
  private userIdleService = inject(UserIdleService);
  private dialog = inject(MatDialog);
  private chsAuthenticationHelperService = inject(ChsAuthenticationHelperService);
  private titleService = inject(Title);

  #timeLeftToInteract = signal<number>(environment.idleTimeoutSettings.countdownTimeInSeconds);
  private countdownDialog: MatDialogRef<InactivityModalComponent> | undefined;
  private currentTitle: string = '';

  constructor() {
    this.userIdleService.onTimerStart().subscribe((count: number) => {
      if (count > 0) {
        if (this.currentTitle === '') {
          this.currentTitle = this.titleService.getTitle();
        }

        const remainingTime: number = environment.idleTimeoutSettings.countdownTimeInSeconds - count;
        if (remainingTime > -1) {
          this.#timeLeftToInteract.set(remainingTime);
          this.titleService.setTitle(`(${remainingTime}) seconds until logout...`);

          if (!this.countdownDialog) {
            this.countdownDialog = this.dialog.open(InactivityModalComponent, {
              data: this.#timeLeftToInteract(),
              width: '360px',
            });
          }
        }
      }
    });

    effect(() => {
      if (this.chsAuthenticationHelperService.loginFlowComplete()) {
        this.setup();
      } else {
        this.stop();
      }
    });
  }

  public toggleIdle() {
    this.userIdleService.stopWatching();
    this.userIdleService.startWatching();
    this.closeDialog();
  }

  private setup() {
    this.toggleIdle();
    this.handleIdleTimeout();
  }

  private stop() {
    this.userIdleService.stopWatching();
  }

  private handleIdleTimeout() {
    this.userIdleService.onTimeout().subscribe(() => {
      this.closeDialog();
      this.chsAuthenticationHelperService.logout();
    });
  }

  private closeDialog() {
    this.countdownDialog?.close();
    this.countdownDialog = undefined;
    if (this.currentTitle) {
      this.titleService.setTitle(this.currentTitle);
    }
  }
}
