import { HttpHeaders, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ChsHttpHelperService {
  private spinnerIgnoredHeaderName = 'spinner-overlay-ignored';
  private errorInterceptorIgnoredHeaderName = 'error-interceptor-ignored';
  private secretKey = 'dynatrace-maintenance-windows-true-secret-key';

  get ignoreSpinnerHttpHeader(): HttpHeaders {
    return new HttpHeaders({
      [this.spinnerIgnoredHeaderName]: this.secretKey,
    });
  }

  get ignoreErrorInterceptorHttpHeader(): HttpHeaders {
    return new HttpHeaders({
      [this.errorInterceptorIgnoredHeaderName]: this.secretKey,
    });
  }

  IsSpinnerIgnoredOnRequest(req: HttpRequest<any>): boolean {
    return req.headers.get(this.spinnerIgnoredHeaderName) === this.secretKey;
  }

  IsErrorInterceptorIgnoredOnRequest(req: HttpRequest<any>): boolean {
    return req.headers.get(this.errorInterceptorIgnoredHeaderName) === this.secretKey;
  }

  /** Strip our marker headers before the request leaves the browser. */
  stripMarkerHeaders(req: HttpRequest<any>): HttpRequest<any> {
    let headers = req.headers;
    if (headers.has(this.spinnerIgnoredHeaderName)) headers = headers.delete(this.spinnerIgnoredHeaderName);
    if (headers.has(this.errorInterceptorIgnoredHeaderName))
      headers = headers.delete(this.errorInterceptorIgnoredHeaderName);
    return headers === req.headers ? req : req.clone({ headers });
  }
}
