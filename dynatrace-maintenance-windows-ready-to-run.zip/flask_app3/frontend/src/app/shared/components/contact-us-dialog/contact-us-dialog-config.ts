import { MatDialogConfig } from '@angular/material/dialog';

export class ContactUsDialogConfig extends MatDialogConfig {
  constructor(data: any = {}, width: string = '450px') {
    super();
    this.data = data;
    this.width = width;
    this.panelClass = 'dialog-panel';
  }
}
