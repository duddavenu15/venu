import { CommonModule } from '@angular/common';
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { RouterLink } from '@angular/router';
import { environment } from '@env/environment';

import { DarkModeService } from '../../services/dark-mode.service';

@Component({
  selector: 'app-contact-us-dialog',
  imports: [CommonModule, MatButtonModule, MatDialogModule, MatIconModule, MatToolbarModule, RouterLink],
  templateUrl: './contact-us-dialog.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./contact-us-dialog.component.scss'],
})
export class ContactUsDialogComponent {
  darkModeService = inject(DarkModeService);
  contacts = environment.contacts;
}
