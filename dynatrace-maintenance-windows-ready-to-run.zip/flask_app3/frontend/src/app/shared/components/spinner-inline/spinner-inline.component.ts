import { CommonModule } from '@angular/common';
import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-spinner-inline',
  imports: [CommonModule],
  templateUrl: './spinner-inline.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./spinner-inline.component.scss'],
})
export class SpinnerInlineComponent {
  @Input() show: boolean = false;
  constructor() {}
}
