import { CommonModule } from '@angular/common';
import { Component, signal, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatToolbarModule } from '@angular/material/toolbar';
import { LegalDialogComponent, LegalDialogConfig } from '../legal-dialog';
import packageJson from '@root/package.json';
import { DarkModeService } from '../../services/dark-mode.service';
import { LayoutService } from '../../services/layout.service';

@Component({
  selector: 'app-footer',
  imports: [CommonModule, MatToolbarModule],
  templateUrl: './footer.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent {
  private dialogService = inject(MatDialog);
  layoutService = inject(LayoutService);
  darkModeService = inject(DarkModeService);

  date = signal(new Date().getFullYear());
  version = signal(packageJson.version);

  openLegalDialog() {
    const dialogConfig = new LegalDialogConfig(null, '70%');
    this.dialogService.open(LegalDialogComponent, dialogConfig);
  }
}
