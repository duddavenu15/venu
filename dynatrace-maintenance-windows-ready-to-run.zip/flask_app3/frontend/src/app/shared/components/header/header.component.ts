import { CommonModule } from '@angular/common';
import { Component, computed, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatMenuModule } from '@angular/material/menu';
import { RouterModule } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { ChsAuthenticationHelperService } from '../../services/chs-authentication-helper.service';
import { DarkModeService } from '../../services/dark-mode.service';
import { LayoutService } from '../../services/layout.service';
import { UserService } from '../../services/user.service';
import { ContactUsDialogComponent } from '../contact-us-dialog/contact-us-dialog.component';
import { ContactUsDialogConfig } from '../contact-us-dialog/contact-us-dialog-config';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatButtonModule, MatIconModule, MatMenuModule, MatToolbarModule, RouterModule],
  templateUrl: './header.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent {
  userService = inject(UserService);
  layoutService = inject(LayoutService);
  darkModeService = inject(DarkModeService);
  private chsAuthenticationHelperService = inject(ChsAuthenticationHelperService);
  private dialogService = inject(MatDialog);

  public logoUrl = computed(() =>
    this.darkModeService.isDarkMode()
      ? './assets/images/chs-logo-default-white.png'
      : './assets/images/chs-logo-default.png'
  );

  toggleSidenavVisibility() {
    this.layoutService.toggleSidenavVisibility();
  }

  doLogout() {
    this.chsAuthenticationHelperService.logout();
  }

  openContactUsDialog = (): void => {
    const dialogConfig = new ContactUsDialogConfig(null, '70%');
    this.dialogService.open(ContactUsDialogComponent, dialogConfig);
  };
}
