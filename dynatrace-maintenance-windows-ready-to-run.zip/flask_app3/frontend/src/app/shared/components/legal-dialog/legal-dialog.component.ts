import { CommonModule } from '@angular/common';
import { Component, computed, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { DarkModeService } from '../../services/dark-mode.service';

@Component({
  selector: 'app-legal-dialog',
  imports: [CommonModule, MatButtonModule, MatDialogModule, MatIconModule, MatToolbarModule],
  templateUrl: './legal-dialog.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./legal-dialog.component.scss'],
})
export class LegalDialogComponent {
  darkModeService = inject(DarkModeService);

  public logoUrl = computed(() =>
    this.darkModeService.isDarkMode()
      ? './assets/images/chs-logo-thumb-white.png'
      : './assets/images/chs-logo-thumb.png'
  );
}
