export * from './legal-dialog.component';
export * from './legal-dialog-config';
