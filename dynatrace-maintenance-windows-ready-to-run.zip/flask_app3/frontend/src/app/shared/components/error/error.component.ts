import { CommonModule } from '@angular/common';
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { DarkModeService } from '../../services/dark-mode.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-error',
  imports: [CommonModule, MatIconModule],
  templateUrl: './error.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./error.component.scss'],
})
export class ErrorComponent {
  darkModeService = inject(DarkModeService);
}
