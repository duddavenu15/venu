import { CommonModule } from '@angular/common';
import {
  AfterViewInit,
  Component,
  CUSTOM_ELEMENTS_SCHEMA,
  ViewChild,
  ViewContainerRef,
  ChangeDetectionStrategy,
  inject,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { showErrorComponent } from '@chs/angular-native-federation';
import { ErrorComponent } from '../error/error.component';

@Component({
  imports: [CommonModule, MatButtonModule, MatDialogModule, MatIconModule, MatToolbarModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  selector: 'app-error-dialog',
  templateUrl: './error-dialog.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./error-dialog.component.scss'],
})
export class ErrorDialogComponent implements AfterViewInit {
  private dialogRef = inject<MatDialogRef<ErrorDialogComponent>>(MatDialogRef);

  @ViewChild('vc', { read: ViewContainerRef })
  viewContainer!: ViewContainerRef;

  ngAfterViewInit() {
    this.dialogRef.addPanelClass('dialog-panel');
    showErrorComponent(this.viewContainer, ErrorComponent);
  }

  close(): void {
    this.dialogRef.close();
  }
}
