import { CommonModule } from '@angular/common';
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-inactivity-modal',
  imports: [CommonModule, MatDialogModule],
  templateUrl: './inactivity-modal.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./inactivity-modal.component.scss'],
})
export class InactivityModalComponent {
  private dialogRef = inject<MatDialogRef<InactivityModalComponent>>(MatDialogRef);
  data = inject<BehaviorSubject<number>>(MAT_DIALOG_DATA);
}
