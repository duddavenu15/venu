import { CommonModule } from '@angular/common';
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogConfig, MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';

export interface ConfirmDialogData {
  title: string;
  message: string;
  confirmText: string;
  cancelText?: string;
  /** 'warn' for destructive actions (red header + button). */
  tone?: 'primary' | 'warn';
}

/** Opens with `dialog.open(ConfirmDialogComponent, new ConfirmDialogConfig({...}))`; closes with true/false. */
export class ConfirmDialogConfig extends MatDialogConfig<ConfirmDialogData> {
  constructor(data: ConfirmDialogData, width: string = '460px') {
    super();
    this.data = data;
    this.width = width;
    this.panelClass = 'dialog-panel';
    this.autoFocus = 'dialog';
  }
}

@Component({
  selector: 'app-confirm-dialog',
  imports: [CommonModule, MatButtonModule, MatDialogModule, MatIconModule, MatToolbarModule],
  template: `
    <div class="confirm-dialog">
      <h1 mat-dialog-title>
        <mat-toolbar [color]="data.tone === 'warn' ? 'warn' : 'primary'">
          <span>{{ data.title }}</span>
          <span class="header-spacer"></span>
          <button
            mat-icon-button
            [mat-dialog-close]="false"
            aria-label="Close">
            <mat-icon>close</mat-icon>
          </button>
        </mat-toolbar>
      </h1>
      <div
        mat-dialog-content
        class="confirm-message">
        {{ data.message }}
      </div>
      <div
        mat-dialog-actions
        class="dialog-actions">
        <button
          mat-button
          [mat-dialog-close]="false">
          {{ data.cancelText || 'Cancel' }}
        </button>
        <button
          mat-flat-button
          [color]="data.tone === 'warn' ? 'warn' : 'primary'"
          [mat-dialog-close]="true"
          class="confirm-button">
          {{ data.confirmText }}
        </button>
      </div>
    </div>
  `,
  styles: [
    `
      .confirm-message {
        white-space: pre-line;
        line-height: 1.5;
      }
      .dialog-actions {
        padding: 8px 16px 16px !important;
        float: none !important;
        justify-content: flex-end;
      }
    `,
  ],
  changeDetection: ChangeDetectionStrategy.Eager,
})
export class ConfirmDialogComponent {
  data = inject<ConfirmDialogData>(MAT_DIALOG_DATA);
}
