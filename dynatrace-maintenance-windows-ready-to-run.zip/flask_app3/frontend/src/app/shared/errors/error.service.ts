import { Injectable, ViewContainerRef, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ErrorComponent } from '../components/error/error.component';
import { ErrorDialogComponent } from '../components/error-dialog/error-dialog.component';
import { showErrorComponent } from '@chs/angular-native-federation';

@Injectable({
  providedIn: 'root',
})
export class ErrorService {
  private dialog = inject(MatDialog);

  public static logError(error: any) {
    console.error(error);
  }

  public static showErrorComponent(viewContainer: ViewContainerRef) {
    showErrorComponent(viewContainer, ErrorComponent);
  }

  public showErrorDialog() {
    this.dialog.open(ErrorDialogComponent);
  }
}
