import { CommonModule } from '@angular/common';
import { Component, ChangeDetectionStrategy, HostListener, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { Router, RouterLink } from '@angular/router';
import { DarkModeService } from '@app/shared/services';
import { environment } from '@env/environment';

/**
 * Illustrated user guide. Shown inside the layout at /guide, and on its own at /help
 * (linked from the sign-in page) for people who can't sign in yet.
 * Screenshots and the PDF copy live in src/assets/guide/.
 */
@Component({
  selector: 'app-user-guide',
  imports: [CommonModule, MatButtonModule, MatToolbarModule, RouterLink],
  templateUrl: './user-guide.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./user-guide.component.scss'],
})
export class UserGuideComponent {
  darkModeService = inject(DarkModeService);
  private router = inject(Router);

  readonly standalone = this.router.url.startsWith('/help');
  readonly contacts = environment.contacts;
  readonly pdf = 'assets/guide/CHS-Maintenance-Window-User-Guide.pdf';

  readonly sections = [
    { id: 'overview', label: 'How it works' },
    { id: 'signin', label: 'Signing in' },
    { id: 'layout', label: 'Finding your way' },
    { id: 'create', label: 'Create a window' },
    { id: 'buttons', label: 'The four buttons' },
    { id: 'list', label: 'All windows' },
    { id: 'log', label: 'Submission Log' },
    { id: 'faq', label: 'Questions & fixes' },
  ];

  scrollTo(id: string, event: Event): void {
    event.preventDefault();
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  print(): void {
    window.print();
  }

  /** Expand all collapsible sections so they appear on paper / in the PDF. */
  @HostListener('window:beforeprint')
  expandAll(): void {
    document.querySelectorAll('.guide details').forEach((d) => d.setAttribute('open', ''));
  }
}
