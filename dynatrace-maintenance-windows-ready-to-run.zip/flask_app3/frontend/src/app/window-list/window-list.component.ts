import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { AfterViewInit, ChangeDetectionStrategy, Component, computed, inject, signal, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ConfirmDialogComponent, ConfirmDialogConfig } from '@app/shared/components';
import { MaintenanceWindow } from '@app/shared/models';
import { ApiService } from '@app/shared/services';
import { errorText } from '@app/shared/utils/clipboard';
import { firstValueFrom } from 'rxjs';

export interface WindowRow extends MaintenanceWindow {
  scheduleText: string;
  rangeText: string;
  targetsMain: string;
  targetsSub: string;
  targetsMono: boolean;
  submittedUser: string;
  searchText: string;
}

/** Handles the current Dynatrace shape (timeWindow + recurrenceRange) and the older flat one. */
function windowText(r: any): { time: string; range: string } {
  const tw = r?.timeWindow || r || {};
  const range = r?.recurrenceRange
    ? `${r.recurrenceRange.scheduleStartDate} → ${r.recurrenceRange.scheduleEndDate}`
    : '';
  return { time: `${tw.startTime ?? ''}–${tw.endTime ?? ''} (${tw.timeZone ?? ''})`, range };
}

function describeSchedule(type: string, s: any): { text: string; range: string } {
  if (!s) return { text: type || '', range: '' };
  switch (type) {
    case 'ONCE': {
      const o = s.onceRecurrence || {};
      return { text: `Once: ${o.startTime ?? ''} → ${o.endTime ?? ''} (${o.timeZone ?? ''})`, range: '' };
    }
    case 'DAILY': {
      const w = windowText(s.dailyRecurrence);
      return { text: `Daily ${w.time}`, range: w.range };
    }
    case 'WEEKLY': {
      const r = s.weeklyRecurrence || {};
      const w = windowText(r);
      return { text: `Weekly on ${r.dayOfWeek ?? ''} ${w.time}`, range: w.range };
    }
    case 'MONTHLY': {
      const r = s.monthlyRecurrence || {};
      const w = windowText(r);
      return { text: `Monthly on day ${r.dayOfMonth ?? ''} ${w.time}`, range: w.range };
    }
    default:
      return { text: type || '', range: '' };
  }
}

function describeTargets(item: MaintenanceWindow): { main: string; sub: string; mono: boolean } {
  const f = item.filters || [];
  if (!f.length) return { main: 'Entire environment', sub: '', mono: false };
  const sb = item.submittedBy;
  if (sb?.entity_selector) {
    return { main: sb.entity_selector, sub: `${f.length} entit${f.length === 1 ? 'y' : 'ies'}`, mono: true };
  }
  if (sb?.entity_names?.length) {
    const shown = sb.entity_names.slice(0, 5).join(', ');
    const more = sb.entity_names.length > 5 ? ` +${sb.entity_names.length - 5} more` : '';
    return { main: f[0].entityType || '', sub: shown + more, mono: false };
  }
  const types = [...new Set(f.map((x) => x.entityType || 'tag/MZ filter'))].join(', ');
  return { main: types, sub: `${f.length} filter${f.length === 1 ? '' : 's'}`, mono: false };
}

@Component({
  selector: 'app-window-list',
  imports: [
    CommonModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatSortModule,
    MatTableModule,
    MatToolbarModule,
    MatTooltipModule,
  ],
  templateUrl: './window-list.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./window-list.component.scss'],
})
export class WindowListComponent implements AfterViewInit {
  private api = inject(ApiService);
  private dialog = inject(MatDialog);

  readonly displayedColumns = ['name', 'maintenanceType', 'schedule', 'targets', 'submittedBy', 'enabled', 'actions'];
  dataSource = new MatTableDataSource<WindowRow>([]);

  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  loading = signal(false);
  loaded = signal(false);
  error = signal<string | null>(null);
  incomplete = signal<string | null>(null);
  pagesFetched = signal(0);
  totalInDynatrace = signal(0);
  rowCount = signal(0);
  filteredCount = signal(0);
  filter = signal('');
  deleting = signal<string | null>(null);

  countText = computed(() => {
    const all = this.rowCount();
    const p = this.pagesFetched();
    const pages = this.incomplete()
      ? `${p} request${p === 1 ? '' : 's'}`
      : `all loaded from Dynatrace in ${p} request${p === 1 ? '' : 's'}`;
    return this.filter().trim()
      ? `${this.filteredCount()} of ${all} windows (${pages})`
      : `${all} window${all === 1 ? '' : 's'} (${pages})`;
  });

  constructor() {
    this.dataSource.filterPredicate = (row, f) => row.searchText.includes(f);
    this.dataSource.sortingDataAccessor = (row, col) => {
      switch (col) {
        case 'name':
          return (row.name || '').toLowerCase();
        case 'schedule':
          return row.scheduleType;
        case 'submittedBy':
          return row.submittedUser;
        case 'enabled':
          return row.enabled ? 1 : 0;
        default:
          return (row as any)[col] ?? '';
      }
    };
    this.load();
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    try {
      const data = await firstValueFrom(this.api.list());
      const rows: WindowRow[] = (data.items || []).map((i) => {
        const s = describeSchedule(i.scheduleType, i.schedule);
        const t = describeTargets(i);
        const sb = i.submittedBy;
        return {
          ...i,
          scheduleText: s.text,
          rangeText: s.range,
          targetsMain: t.main,
          targetsSub: t.sub,
          targetsMono: t.mono,
          submittedUser: sb?.user ?? '',
          searchText: [
            i.name,
            i.description,
            i.scheduleType,
            i.maintenanceType,
            sb?.user,
            sb?.client_ip,
            sb?.client_hostname,
            sb?.entity_selector,
            (sb?.entity_names || []).join(' '),
          ]
            .filter(Boolean)
            .join(' ')
            .toLowerCase(),
        };
      });
      this.dataSource.data = rows;
      this.rowCount.set(rows.length);
      this.applyFilter(this.filter());
      this.pagesFetched.set(data.pages_fetched || 1);
      this.totalInDynatrace.set(data.total_count ?? rows.length);
      this.incomplete.set(data.complete === false ? data.warning || 'Not every page could be loaded.' : null);
      this.loaded.set(true);
    } catch (e) {
      const err = e as HttpErrorResponse;
      if (err.status !== 401) this.error.set('Failed to load: ' + errorText(err.status, err.error));
    } finally {
      this.loading.set(false);
    }
  }

  applyFilter(value: string): void {
    this.filter.set(value);
    this.dataSource.filter = value.trim().toLowerCase();
    this.filteredCount.set(this.dataSource.filteredData.length);
    this.paginator?.firstPage();
  }

  async remove(row: WindowRow): Promise<void> {
    const name = row.name || '(unnamed)';
    const ok = await firstValueFrom(
      this.dialog
        .open(
          ConfirmDialogComponent,
          new ConfirmDialogConfig({
            title: 'Delete maintenance window?',
            message: `"${name}" will be removed from Dynatrace. This can't be undone.`,
            confirmText: 'Delete',
            tone: 'warn',
          })
        )
        .afterClosed()
    );
    if (!ok) return;
    this.deleting.set(row.objectId);
    try {
      await firstValueFrom(this.api.delete(row.objectId, name));
      await this.load();
    } catch (e) {
      const err = e as HttpErrorResponse;
      if (err.status !== 401) this.error.set('Delete failed: ' + errorText(err.status, err.error));
    } finally {
      this.deleting.set(null);
    }
  }

  when(ts: string | undefined): string {
    return (ts || '').replace('T', ' ').replace('+00:00', ' UTC');
  }
}
