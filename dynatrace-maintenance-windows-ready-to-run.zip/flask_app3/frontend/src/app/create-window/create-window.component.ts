import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, computed, DestroyRef, inject, signal } from '@angular/core';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ConfirmDialogComponent, ConfirmDialogConfig, SpinnerInlineComponent } from '@app/shared/components';
import { PreviewResponse, ScheduleType, SiteConfig, WindowForm } from '@app/shared/models';
import { ApiService } from '@app/shared/services';
import { copyText, errorText } from '@app/shared/utils/clipboard';
import { firstValueFrom } from 'rxjs';

type ResultKind = 'pending' | 'success' | 'error';

const DAYS = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];
const TIME_ZONES = ['America/Chicago', 'America/New_York', 'America/Denver', 'America/Los_Angeles', 'UTC'];

const LABELS: Record<string, string> = {
  name: 'Name',
  start_time: 'Start Time',
  end_time: 'End Time',
  time_window_start: 'Start Time',
  time_window_end: 'End Time',
  range_start_date: 'Range Start Date',
  range_end_date: 'Range End Date',
  day_of_month: 'Day of Month',
  entity_selector: 'Entity Selector',
};

function isoDate(d: Date): string {
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}

@Component({
  selector: 'app-create-window',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatCardModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatToolbarModule,
    MatTooltipModule,
    SpinnerInlineComponent,
  ],
  templateUrl: './create-window.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./create-window.component.scss'],
})
export class CreateWindowComponent {
  private api = inject(ApiService);
  private dialog = inject(MatDialog);
  private destroyRef = inject(DestroyRef);
  private fb = inject(FormBuilder).nonNullable;

  readonly days = DAYS;
  readonly timeZones = TIME_ZONES;

  config = signal<SiteConfig | null>(null);
  configError = signal<string | null>(null);
  reloadingTypes = signal(false);

  form = this.fb.group({
    name: '',
    description: '',
    maintenance_type: 'PLANNED',
    suppression: 'DETECT_PROBLEMS_DONT_ALERT',
    disable_synthetic_monitor_execution: false,
    schedule_type: 'MONTHLY' as ScheduleType,
    time_zone: 'America/Chicago',
    start_time: '',
    end_time: '',
    time_window_start: '02:00',
    time_window_end: '04:00',
    day_of_week: 'WEDNESDAY',
    day_of_month: 1 as number | null,
    range_start_date: isoDate(new Date()),
    range_end_date: '2030-12-31',
    entity_type: 'HOST',
    entity_names: '',
    entity_selector: '',
  });

  private value = toSignal(this.form.valueChanges, { initialValue: this.form.getRawValue() });
  scheduleType = computed(() => this.value().schedule_type);
  isCustomSelector = computed(() => !!this.config() && this.value().entity_type === this.config()!.selector_scope);
  namesLabel = computed(() => {
    const t = this.config()?.entity_types.find((e) => e.type === this.value().entity_type);
    return (t?.label ?? 'Entity') + ' names';
  });
  tzShort = computed(() => (this.config()?.fixed_time_zone === 'America/Chicago' ? 'CST' : ''));
  typesStatus = computed(() => {
    const c = this.config();
    if (!c) return '';
    const n = c.entity_types.length;
    if (c.entity_types_source === 'dynatrace') {
      const at = c.entity_types_loaded_at ? ` at ${c.entity_types_loaded_at.slice(11, 16)} UTC` : '';
      return `${n} entity types loaded from Dynatrace${at}`;
    }
    return c.entity_types_error
      ? `Couldn't load entity types from Dynatrace (${c.entity_types_error}). Showing the saved list.`
      : 'Showing the saved entity type list.';
  });

  result = signal<{ kind: ResultKind; text: string } | null>(null);
  json = signal<{ title: string; text: string } | null>(null);
  /** True only after Generate JSON (or a push) produced JSON for the form as it is now. */
  jsonReady = signal(false);
  busy = signal<'generate' | 'push' | null>(null);
  copyLabel = signal('Copy JSON');
  private copyTimer?: ReturnType<typeof setTimeout>;

  constructor() {
    this.loadConfig(false);
    this.form.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => {
      this.jsonReady.set(false); // form changed: JSON is out of date
      this.copyLabel.set('Copy JSON');
    });
  }

  // ---- config / entity types -------------------------------------------
  private loadConfig(reload: boolean): void {
    if (reload) this.reloadingTypes.set(true);
    this.api.config(reload).subscribe({
      next: (c) => {
        this.config.set(c);
        this.configError.set(null);
        if (c.fixed_time_zone) this.form.controls.time_zone.setValue(c.fixed_time_zone, { emitEvent: false });
        const current = this.form.controls.entity_type.value;
        const ok = current === c.selector_scope || c.entity_types.some((t) => t.type === current);
        if (!ok && c.entity_types.length) this.form.controls.entity_type.setValue(c.entity_types[0].type);
        this.reloadingTypes.set(false);
      },
      error: (e: HttpErrorResponse) => {
        if (e.status !== 401) this.configError.set(errorText(e.status, e.error));
        this.reloadingTypes.set(false);
      },
    });
  }

  reloadEntityTypes(): void {
    this.loadConfig(true);
  }

  // ---- validation ----------------------------------------------------------
  /** Required fields that are currently empty. */
  private missingFields(): string[] {
    const v = this.form.getRawValue();
    const need = ['name'].concat(
      v.schedule_type === 'ONCE'
        ? ['start_time', 'end_time']
        : ['time_window_start', 'time_window_end', 'range_start_date', 'range_end_date']
    );
    if (v.schedule_type === 'MONTHLY') need.push('day_of_month');
    if (this.isCustomSelector()) need.push('entity_selector');
    return need.filter((k) => {
      const val = (v as Record<string, unknown>)[k];
      return val === null || val === undefined || !String(val).trim();
    });
  }

  /**
   * Check the form before a button does anything.
   * Empty required fields -> "Please fill in the form before clicking ..." and the fields turn red.
   */
  private checkForm(buttonName: string): boolean {
    const missing = this.missingFields();
    if (missing.length) {
      for (const key of missing) {
        const control = this.form.get(key);
        // No validators on these controls, so the error clears as soon as the user types.
        control?.setErrors({ required: true });
        control?.markAsTouched();
      }
      const labels = missing.map((k) => LABELS[k] ?? k);
      this.result.set({
        kind: 'error',
        text: `Please fill in the form before clicking "${buttonName}".\n\nRequired: ${labels.join(', ')}`,
      });
      setTimeout(() => document.getElementById(missing[0])?.focus());
      return false;
    }
    const v = this.form.getRawValue();
    let problem: string | null = null;
    if (v.schedule_type !== 'ONCE' && v.range_end_date < v.range_start_date) {
      problem = 'Range End Date must be on or after Range Start Date.';
    } else if (v.schedule_type === 'ONCE' && v.end_time <= v.start_time) {
      problem = 'End Time must be after Start Time.';
    } else if (v.schedule_type === 'MONTHLY' && !(Number(v.day_of_month) >= 1 && Number(v.day_of_month) <= 31)) {
      problem = 'Day of Month must be between 1 and 31.';
    }
    if (problem) {
      this.result.set({ kind: 'error', text: problem });
      return false;
    }
    return true;
  }

  private payload(): WindowForm {
    return this.form.getRawValue() as WindowForm;
  }

  private resolvedText(data: PreviewResponse): string {
    let t = '';
    if (data.unresolved?.length) {
      t += `\n\nUnresolved names (not found as ${data.entity_type}):\n - ` + data.unresolved.join('\n - ');
    }
    if (data.resolved?.length) {
      const list = data.resolved.slice(0, 25).map((h) => `${h.displayName} (${h.entityId})`);
      t +=
        `\n\nMatched ${data.resolved.length} entit${data.resolved.length === 1 ? 'y' : 'ies'}:\n - ` +
        list.join('\n - ');
      if (data.resolved.length > 25) t += `\n - ... and ${data.resolved.length - 25} more`;
    } else {
      t += '\n\nNo entities selected: this window applies to the ENTIRE environment.';
    }
    if (data.truncated) {
      t += '\n\nWARNING: the selector matched more entities than the limit; only the first ones were included.';
    }
    return t;
  }

  private showJson(title: string, obj: unknown): void {
    this.json.set({ title, text: JSON.stringify(obj, null, 2) });
    this.jsonReady.set(true);
  }

  // ---- Generate JSON (nothing is sent to Dynatrace) -----------------------
  async generate(): Promise<boolean> {
    if (!this.checkForm('Generate JSON')) return false;
    this.busy.set('generate');
    this.result.set({ kind: 'pending', text: 'Resolving entities and building payload...' });
    try {
      const data = await firstValueFrom(this.api.preview(this.payload()));
      this.result.set({
        kind: 'pending',
        text: 'Preview only - nothing has been sent to Dynatrace yet.' + this.resolvedText(data),
      });
      this.showJson('Request payload (preview)', data.request_payload);
      return true;
    } catch (e) {
      const err = e as HttpErrorResponse;
      if (err.status !== 401) this.result.set({ kind: 'error', text: errorText(err.status, err.error) });
      return false;
    } finally {
      this.busy.set(null);
    }
  }

  // ---- Copy JSON (greyed out until Generate JSON has run) -------------------
  async copyJson(): Promise<void> {
    if (!this.jsonReady() || !this.json()) {
      this.result.set({ kind: 'error', text: 'Please fill in the form and click "Generate JSON" before copying.' });
      return;
    }
    const ok = await copyText(this.json()!.text);
    this.copyLabel.set(ok ? 'Copied!' : 'Select the JSON and press Ctrl+C');
    clearTimeout(this.copyTimer);
    this.copyTimer = setTimeout(() => this.copyLabel.set('Copy JSON'), 2000);
  }

  // ---- Clear ----------------------------------------------------------------
  clear(): void {
    const c = this.config();
    this.form.reset();
    this.form.patchValue({
      range_start_date: isoDate(new Date()),
      time_zone: c?.fixed_time_zone || 'America/Chicago',
    });
    this.result.set(null);
    this.json.set(null);
    this.jsonReady.set(false);
  }

  // ---- Push to Dynatrace ------------------------------------------------------
  async push(): Promise<void> {
    if (!this.checkForm('Push to Dynatrace')) return;
    if (!this.isCustomSelector() && !this.form.controls.entity_names.value.trim()) {
      const ok = await firstValueFrom(
        this.dialog
          .open(
            ConfirmDialogComponent,
            new ConfirmDialogConfig({
              title: 'Entire environment?',
              message:
                'No entity names were entered, so this window will put the ENTIRE environment into maintenance.\n\nOnly do this for company-wide outages.',
              confirmText: 'Yes, entire environment',
              tone: 'warn',
            })
          )
          .afterClosed()
      );
      if (!ok) return;
    }
    this.busy.set('push');
    this.result.set({ kind: 'pending', text: 'Pushing to tenant...' });
    try {
      const data = await firstValueFrom(this.api.create(this.payload()));
      let message = 'Success! Maintenance window pushed to Dynatrace.';
      if (data.object_ids?.length) message += '\nObject ID: ' + data.object_ids.join(', ');
      if (data.submitter) {
        const s = data.submitter;
        message +=
          `\n\nLogged as submitted by ${s.user} from ${s.client_ip}` +
          (s.client_hostname ? ` (${s.client_hostname})` : ` (reverse DNS: ${s.dns_lookup})`);
      }
      this.result.set({ kind: 'success', text: message + this.resolvedText(data) });
      this.showJson('Payload sent to Dynatrace', data.request_payload);
    } catch (e) {
      const err = e as HttpErrorResponse;
      if (err.status !== 401) {
        this.result.set({ kind: 'error', text: errorText(err.status, err.error) });
        if (err.error?.response_body) this.showJson('Dynatrace error response', err.error.response_body);
      }
    } finally {
      this.busy.set(null);
    }
  }

  dayLabel(d: string): string {
    return d.charAt(0) + d.slice(1).toLowerCase();
  }
}
