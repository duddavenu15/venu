import { CommonModule } from '@angular/common';
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { DarkModeService, UserService } from '@app/shared/services';
import { environment } from '@env/environment';

@Component({
  selector: 'app-unauthorized',
  imports: [CommonModule, MatButtonModule, RouterLink],
  templateUrl: './unauthorized.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./unauthorized.component.scss'],
})
export class UnauthorizedComponent {
  darkModeService = inject(DarkModeService);
  userService = inject(UserService);
  contacts = environment.contacts;
}
