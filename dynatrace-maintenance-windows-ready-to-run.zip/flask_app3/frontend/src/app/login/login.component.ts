import { CommonModule } from '@angular/common';
import { Component, ChangeDetectionStrategy, inject, input, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { RouterLink } from '@angular/router';
import { SpinnerInlineComponent } from '@app/shared/components';
import { ChsAuthenticationHelperService, DarkModeService, UserService } from '@app/shared/services';

/**
 * Sign-in with a CHS network (AD) account. Flask checks the password against AD and
 * that the user is in the Dynatrace_Users group. Styled like the template's sign-out page.
 */
@Component({
  selector: 'app-login',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    RouterLink,
    SpinnerInlineComponent,
  ],
  templateUrl: './login.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent {
  darkModeService = inject(DarkModeService);
  userService = inject(UserService);
  private authService = inject(ChsAuthenticationHelperService);
  private fb = inject(FormBuilder).nonNullable;

  /** ?expired=1 when sent here because the session ended. */
  expired = input<string>('');

  form = this.fb.group({
    username: ['', Validators.required],
    password: ['', Validators.required],
  });
  busy = signal(false);
  error = signal<string | null>(null);
  hidePassword = signal(true);

  async submit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.busy.set(true);
    this.error.set(null);
    try {
      const { username, password } = this.form.getRawValue();
      await this.authService.login(username.trim(), password);
    } catch (e) {
      this.error.set((e as Error).message);
      this.form.controls.password.reset('');
    } finally {
      this.busy.set(false);
    }
  }
}
