import { Routes } from '@angular/router';
import { NotFoundComponent } from '@app/shared/components';
import { IsAuthenticatedGuard, LoginPageGuard } from '@app/shared/guards';
import { HomeComponent } from './home/home.component';
import { LayoutComponent } from './layout/layout.component';
import { LogoutComponent } from './logout/logout.component';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';

export const appRoutes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    canActivate: [IsAuthenticatedGuard],
    children: [
      {
        path: '',
        component: HomeComponent,
        title: 'Home | Dynatrace Maintenance Windows',
      },
      {
        path: 'create',
        title: 'Create Maintenance Window | Dynatrace Maintenance Windows',
        loadComponent: () =>
          import('@app/create-window/create-window.component').then((comp) => comp.CreateWindowComponent),
      },
      {
        path: 'list',
        title: 'All Maintenance Windows | Dynatrace Maintenance Windows',
        loadComponent: () => import('@app/window-list/window-list.component').then((comp) => comp.WindowListComponent),
      },
      {
        path: 'audit',
        title: 'Submission Log | Dynatrace Maintenance Windows',
        loadComponent: () =>
          import('@app/submission-log/submission-log.component').then((comp) => comp.SubmissionLogComponent),
      },
      {
        path: 'guide',
        title: 'User Guide | Dynatrace Maintenance Windows',
        loadComponent: () => import('@app/user-guide/user-guide.component').then((comp) => comp.UserGuideComponent),
      },
      {
        path: 'settings',
        title: 'Settings | Dynatrace Maintenance Windows',
        loadComponent: () => import('@app/settings/settings.component').then((comp) => comp.SettingsComponent),
      },
    ],
  },
  {
    // The same guide, open to everyone (linked from the sign-in page) so people can read
    // how the site works and how to get access before they can sign in.
    path: 'help',
    title: 'User Guide | Dynatrace Maintenance Windows',
    loadComponent: () => import('@app/user-guide/user-guide.component').then((comp) => comp.UserGuideComponent),
  },
  {
    path: 'login',
    title: 'Sign in | Dynatrace Maintenance Windows',
    canActivate: [LoginPageGuard],
    loadComponent: () => import('@app/login/login.component').then((comp) => comp.LoginComponent),
  },
  {
    path: 'logout',
    component: LogoutComponent,
  },
  {
    path: 'unauthorized',
    component: UnauthorizedComponent,
  },
  {
    path: '**',
    component: NotFoundComponent,
  },
];
