import { CommonModule } from '@angular/common';
import { Component, HostListener, ChangeDetectionStrategy, inject } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ChsIdleTimerService, RequestsService } from './shared/services';
import { SpinnerOverlayComponent } from './shared/components';

@Component({
  selector: 'app-root',
  imports: [CommonModule, RouterModule, SpinnerOverlayComponent],
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  requestsService = inject(RequestsService);
  private chsIdleTimerService = inject(ChsIdleTimerService);

  @HostListener('window:mousemove', ['$event'])
  @HostListener('window:resize', ['$event'])
  @HostListener('document:keydown', ['$event'])
  @HostListener('document:focus', ['$event'])
  onMouseMove($event: any) {
    this.chsIdleTimerService.toggleIdle();
  }
}
