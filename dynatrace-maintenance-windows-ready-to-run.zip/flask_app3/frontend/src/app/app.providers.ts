import {
  ApiService,
  ChsAuthenticationHelperService,
  ChsHttpHelperService,
  ChsIdleTimerService,
  DarkModeService,
  DeepLinkService,
  LayoutService,
  LocalStorageService,
  RequestsService,
  UserService,
} from '@app/shared/services';
import { ErrorService } from '@app/shared/errors';
import { IsAuthenticatedGuard, LoginPageGuard } from '@app/shared/guards';
import { httpRequestInterceptorProvider } from '@app/shared/interceptors';

export const appProviders = [
  // our guards
  IsAuthenticatedGuard,
  LoginPageGuard,

  // Our services
  ApiService,
  ChsAuthenticationHelperService,
  ChsHttpHelperService,
  ChsIdleTimerService,
  ErrorService,
  LocalStorageService,
  LayoutService,
  DeepLinkService,
  DarkModeService,
  RequestsService,
  UserService,

  // for some reason this does not put our global error handler in a scope that the standalone components can see
  // for now, there is a module that is used for this in app.bootstrap.ts "ErrorHandlerModule".  We should revisit this with Angular 15
  // and see if it works or if there are more wireup hooks to make it work.
  /* {
        provide: ErrorHandler,
        useClass: GlobalErrorHandler
    }, */

  // Interceptors
  httpRequestInterceptorProvider,
];
