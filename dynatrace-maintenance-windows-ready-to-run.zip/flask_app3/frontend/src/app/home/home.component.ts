import { CommonModule } from '@angular/common';
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { RouterLink } from '@angular/router';
import { UserService } from '@app/shared/services';

interface HomeCard {
  link: string;
  icon: string;
  title: string;
  text: string;
  tone: 'green' | 'teal' | 'amber';
}

@Component({
  selector: 'app-shell-home',
  imports: [CommonModule, MatButtonModule, MatCardModule, MatIconModule, MatToolbarModule, RouterLink],
  templateUrl: './home.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent {
  userService = inject(UserService);

  cards: HomeCard[] = [
    {
      link: '/create',
      icon: 'event_available',
      title: 'Create a maintenance window',
      text: 'Pick the servers, set the schedule, push to Dynatrace.',
      tone: 'green',
    },
    {
      link: '/list',
      icon: 'list_alt',
      title: 'See all windows',
      text: 'Every window in Dynatrace, who created it, and delete.',
      tone: 'teal',
    },
    {
      link: '/audit',
      icon: 'receipt_long',
      title: 'Submission Log',
      text: 'Who did what, from which IP and PC.',
      tone: 'amber',
    },
  ];
}
