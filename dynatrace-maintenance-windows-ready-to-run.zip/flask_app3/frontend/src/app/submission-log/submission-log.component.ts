import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { AfterViewInit, ChangeDetectionStrategy, Component, inject, signal, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AuditRecord } from '@app/shared/models';
import { ApiService } from '@app/shared/services';
import { errorText } from '@app/shared/utils/clipboard';

@Component({
  selector: 'app-submission-log',
  imports: [
    CommonModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatTableModule,
    MatToolbarModule,
    MatTooltipModule,
  ],
  templateUrl: './submission-log.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./submission-log.component.scss'],
})
export class SubmissionLogComponent implements AfterViewInit {
  private api = inject(ApiService);

  readonly displayedColumns = [
    'timestamp',
    'event',
    'user',
    'client_ip',
    'client_hostname',
    'window',
    'targets',
    'object_ids',
  ];
  dataSource = new MatTableDataSource<AuditRecord>([]);
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  loading = signal(false);
  loaded = signal(false);
  error = signal<string | null>(null);
  filter = signal('');
  total = signal(0);
  shown = signal(0);

  constructor() {
    this.dataSource.filterPredicate = (r, f) => JSON.stringify(r).toLowerCase().includes(f);
    this.load();
  }

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
  }

  load(): void {
    this.loading.set(true);
    this.error.set(null);
    this.api.audit().subscribe({
      next: (d) => {
        this.dataSource.data = d.records || [];
        this.total.set(this.dataSource.data.length);
        this.applyFilter(this.filter());
        this.loading.set(false);
        this.loaded.set(true);
      },
      error: (e: HttpErrorResponse) => {
        if (e.status !== 401) this.error.set(errorText(e.status, e.error));
        this.loading.set(false);
      },
    });
  }

  applyFilter(value: string): void {
    this.filter.set(value);
    this.dataSource.filter = value.trim().toLowerCase();
    this.shown.set(this.dataSource.filteredData.length);
    this.paginator?.firstPage();
  }

  when(ts: string): string {
    return (ts || '').slice(0, 19).replace('T', ' ');
  }

  eventLabel(e: string): string {
    return e.replaceAll('_', ' ');
  }
}
