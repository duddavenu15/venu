import { CommonModule } from '@angular/common';
import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatToolbarModule } from '@angular/material/toolbar';
import { ChsAuthenticationHelperService, DarkModeService, UserService } from '@app/shared/services';
import { environment } from '@env/environment';

@Component({
  selector: 'app-settings',
  imports: [CommonModule, MatToolbarModule, MatButtonModule, MatIconModule, MatSlideToggleModule],
  templateUrl: './settings.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./settings.component.scss'],
})
export class SettingsComponent {
  userService = inject(UserService);
  darkModeService = inject(DarkModeService);
  private authService = inject(ChsAuthenticationHelperService);

  idleMinutes = Math.round(environment.idleTimeoutSettings.inactivityTimeBeforeShowingCountdownInSeconds / 60);
  countdownMinutes = Math.round(environment.idleTimeoutSettings.countdownTimeInSeconds / 60);

  signOut() {
    this.authService.logout();
  }
}
