import { CommonModule } from '@angular/common';
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { DarkModeService } from '@app/shared/services';

@Component({
  selector: 'app-logout',
  imports: [CommonModule, MatButtonModule, RouterLink],
  templateUrl: './logout.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./logout.component.scss'],
})
export class LogoutComponent {
  darkModeService = inject(DarkModeService);
}
