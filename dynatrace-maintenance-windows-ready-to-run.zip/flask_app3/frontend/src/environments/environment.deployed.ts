import { IEnvironment } from '@app/shared/models';

export const environment: IEnvironment = {
  production: true,
  apiBaseUrl: '',
  idleTimeoutSettings: {
    inactivityTimeBeforeShowingCountdownInSeconds: 15 * 60, // 15 minutes
    countdownTimeInSeconds: 2 * 60, // 2 minutes
    pingEventTimeInSeconds: 2 * 60, // fire the ping event every 2 minutes
  },
  contacts: 'Matt Brawley or Brian Strickler',
};
