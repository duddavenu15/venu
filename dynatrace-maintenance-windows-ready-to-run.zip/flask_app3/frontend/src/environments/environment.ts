// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --configuration deployed` replaces `environment.ts` with `environment.deployed.ts`.
// The list of file replacements can be found in `angular.json`.
import { IEnvironment } from '@app/shared/models';

export const environment: IEnvironment = {
  production: false,
  // The Flask API is served from the same site, so calls are relative ('/api/...').
  // When running `npm start` (port 4200), proxy.conf.json forwards /api to Flask on port 5000.
  apiBaseUrl: '',
  idleTimeoutSettings: {
    inactivityTimeBeforeShowingCountdownInSeconds: 15 * 60, // 15 minutes
    countdownTimeInSeconds: 2 * 60, // 2 minutes
    pingEventTimeInSeconds: 2 * 60, // fire the ping event every 2 minutes
  },
  contacts: 'Matt Brawley or Brian Strickler',
};
