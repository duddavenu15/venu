# Dynatrace Maintenance Windows (front end)

Built from the **CHS Angular Template** (`chs-angular-template` v22). The Flask app one
folder up is the back end: it holds the Dynatrace API token, does the AD sign-in, the
NSLookup/audit log and all Dynatrace calls, and serves this app's build.

## Getting started

You need access to the **CHS-NPM** Azure DevOps feed (for `@chs/angular-material-themes`
and `@chs/angular-native-federation`), set up the same way as for other CHS Angular apps,
and Node 22.12+.

```bash
npm ci                    # install exactly what package-lock.json lists
npm start                 # dev server on http://localhost:4200 (start Flask on :5000 first)
npm run build-deployed    # production build -> dist/dynatrace-maintenance-windows (served by Flask)
npm run lint              # ESLint (template rules)
npm run format            # Prettier (template settings, CRLF)
```

`proxy.conf.json` forwards `/api` and `/tutorial-video` to Flask on port 5000 during
`npm start`, and passes on the caller's IP so the Submission Log records the real address.

## Kept from the template

- MyCHS look and feel: header with logo and user menu, collapsible side menu, footer
  (Privacy / Cookie / Terms of Use / version), CHS Material theme and fonts
- Dark mode (moon/sun button in the side menu, remembered per browser)
- Inactivity sign-out with countdown dialog (`environment.idleTimeoutSettings`)
- Spinner overlay while requests are in flight, global error handler and error dialog
- Deep links (after signing in you return to the page you asked for)
- Not found and unauthorized pages, legal dialog
- Angular 22 + Material, native federation build, ESLint, Prettier, Husky, Azure pipeline

## Changed from the template

| Template | This app | Why |
|---|---|---|
| Okta sign-in in the browser (`angular-auth-oidc-client`) | Sign-in page posting to Flask, which checks the AD password and **Dynatrace_Users** membership and keeps a session cookie | Access is controlled by the AD group; the Dynatrace token must stay on the server |
| Bearer token added by `AuthInterceptor` | Session cookie + Angular XSRF header; a 401 sends the user back to sign-in | Same reason |
| `ChsAuthenticationHelperService` (Okta) | Same class name and public members (`loginFlowComplete`, `checkAuthentication`, `logout`), backed by `/api/me`, `/api/login`, `/api/logout` | Layout, guards and idle timer work unchanged |
| Claims-based `HasFunctionsGuard`, clock-drift check | Removed | No Okta claims; access is the AD group |
| Settings page showing the access token | Your account, dark mode, timeout | No token in the browser |
| Contact us feedback form (placeholder) | CHS Monitoring team contacts | The template form isn't wired to anything |
| Demo pages (weather forecast, reactive forms, MFE examples) | Removed, per the template README | Not used |
| `environment.authConfig`, `remoteEntryUrls`, clock-drift settings | `apiBaseUrl`, `contacts` | See `src/app/shared/models/environment.interface.ts` |

`angular-auth-oidc-client` is still listed in `package.json` (unused, not in the bundle)
so that `package-lock.json` stays identical to the template's and `npm ci` works in the
pipeline. Remove it with `npm uninstall angular-auth-oidc-client` when convenient.

## App pages

| Route | Folder |
|---|---|
| `/` Home | `src/app/home` |
| `/create` Create Window | `src/app/create-window` |
| `/list` All Windows | `src/app/window-list` |
| `/audit` Submission Log | `src/app/submission-log` |
| `/guide` User Guide (signed in), `/help` (public) | `src/app/user-guide` |
| `/settings` | `src/app/settings` |
| `/login`, `/logout`, `/unauthorized` | `src/app/login`, `src/app/logout`, `src/app/unauthorized` |

Each page with its own colours has a `_<name>.component-theme.scss` registered in
`src/app/styles/_theme.scss`, following the template's light/dark theming pattern.
API calls go through `src/app/shared/services/api.service.ts`.

## Before deploying to production

- `azure-pipelines.yml`: check `OctopusPackageID` / `BuildOutputSubfolders`.
- `src/environments/environment.deployed.ts`: `apiBaseUrl` stays `''` when Flask serves the site.
