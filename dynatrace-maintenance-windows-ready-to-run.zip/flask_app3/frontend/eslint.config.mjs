import angular from "angular-eslint";
import tseslint from "typescript-eslint";

export default tseslint.config({
    ignores: ["projects/**/*", "**/federation.config.js"],
}, {
    files: ["**/*.ts"],
    extends: [...angular.configs.tsRecommended],
    processor: angular.processInlineTemplates,

    rules: {
        "@angular-eslint/directive-selector": ["error", {
            type: "attribute",
            prefix: "app",
            style: "camelCase",
        }],

        "@angular-eslint/component-selector": ["error", {
            type: "element",
            prefix: "app",
            style: "kebab-case",
        }],

        "@angular-eslint/prefer-on-push-component-change-detection": "off",
    },
}, {
    files: ["**/*.html"],
    extends: [...angular.configs.templateRecommended],

    rules: {
        "@angular-eslint/template/prefer-control-flow": ["error"],
    },
});