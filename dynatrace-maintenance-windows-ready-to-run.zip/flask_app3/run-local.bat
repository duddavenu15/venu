@echo off
REM Start the Dynatrace Maintenance Windows site on this PC (no Node/npm needed).
REM First run: creates a Python environment, installs packages and a .env settings file.
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found. Install Python 3.10+ from https://www.python.org and tick "Add python.exe to PATH".
  pause
  exit /b 1
)

if not exist venv (
  echo Creating Python environment...
  python -m venv venv
)
call venv\Scripts\activate.bat

echo Installing / checking Python packages...
pip install -r requirements.txt --quiet --disable-pip-version-check

if not exist .env (
  copy .env.example .env >nul
  echo.
  echo A settings file .env was created. Notepad will open it now:
  echo   - set DYNATRACE_API_TOKEN to your sandbox token
  echo   - set AUTH_MODE=disabled for local testing, and SESSION_COOKIE_SECURE=0
  echo Save it, close Notepad, then this window continues.
  notepad .env
)

if not exist frontend\dist\dynatrace-maintenance-windows\index.html (
  echo The front-end build is missing from frontend\dist. Use the zip that includes it.
  pause
  exit /b 1
)

echo.
echo Starting the site on http://localhost:5000  (press Ctrl+C to stop)
start "" http://localhost:5000
python app.py
pause
