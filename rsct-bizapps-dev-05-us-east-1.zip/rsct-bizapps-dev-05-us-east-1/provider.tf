provider "aws" {
  assume_role {
    role_arn = "arn:aws:iam::${var.account_id}:role/svc/terraform/terraform-cloud-execution-role"
  }

  region = var.region
}

provider "aws" {
  alias = "dns"

  assume_role {
    role_arn = "arn:aws:iam::325090749307:role/svc/terraform/terraform-cloud-execution-role"
  }

  region = var.region
}

terraform {
  cloud {
    organization = "chsinc"

    workspaces {
      name = "terraform-aws-dynatrace-rsct-bizapps-dev-05-us-east-1"
    }
  }
 
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "6.63.0"
    }
    time = {
      source  = "hashicorp/time"
      version = "~> 0.13"
   }
     archive = {
      source  = "hashicorp/archive"
      version = "~> 2.7"
    }
  }
}