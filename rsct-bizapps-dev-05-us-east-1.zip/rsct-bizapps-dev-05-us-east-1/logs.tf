resource "aws_cloudwatch_log_group" "firehose" {
  count = local.logs_ingest_enabled ? 1 : 0

  name              = local.firehose_log_group_name
  retention_in_days = 14
  kms_key_id        = var.use_cmk ? aws_kms_key.log_ingest[0].arn : null

  tags = local.common_tags
}

resource "aws_cloudwatch_log_stream" "firehose" {
  count = local.logs_ingest_enabled ? 1 : 0

  name           = local.firehose_log_stream_name
  log_group_name = aws_cloudwatch_log_group.firehose[0].name
}
