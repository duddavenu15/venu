# See for usage:
# https://app.terraform.io/app/chsinc/registry/modules/private/chsinc/library/aws/
module "library" {
  source  = "app.terraform.io/chsinc/library/aws"
  version = "5.1.0"
}
