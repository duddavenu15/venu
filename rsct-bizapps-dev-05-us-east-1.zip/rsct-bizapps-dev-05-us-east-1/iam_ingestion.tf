data "aws_iam_policy_document" "firehose_assume_role" {
  count = local.logs_ingest_enabled ? 1 : 0

  statement {
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["firehose.amazonaws.com"]
    }

    actions = [
      "sts:AssumeRole"
    ]
  }
}

data "aws_iam_policy_document" "firehose_permissions" {
  count = local.logs_ingest_enabled ? 1 : 0

  statement {
    sid    = "ReadIngestionToken"
    effect = "Allow"

    actions = [
      "secretsmanager:GetSecretValue"
    ]

    resources = [
      local.ingest_secret_arn
    ]
  }

  statement {
    sid    = "WriteFirehoseLogs"
    effect = "Allow"

    actions = [
      "logs:PutLogEvents"
    ]

    resources = [
      local.firehose_log_stream_arn
    ]
  }

  statement {
    sid    = "WriteFailedDeliveriesToS3"
    effect = "Allow"

    actions = [
      "s3:AbortMultipartUpload",
      "s3:GetBucketLocation",
      "s3:GetObject",
      "s3:ListBucket",
      "s3:ListBucketMultipartUploads",
      "s3:PutObject"
    ]

    resources = [
      local.backup_bucket_arn,
      "${local.backup_bucket_arn}/*"
    ]
  }

  dynamic "statement" {
    for_each = var.use_cmk ? [1] : []

    content {
      sid    = "UseLogIngestionKmsKey"
      effect = "Allow"

      actions = [
        "kms:Decrypt",
        "kms:GenerateDataKey",
        "kms:CreateGrant"
      ]

      resources = [
        aws_kms_key.log_ingest[0].arn
      ]
    }
  }
}

resource "aws_iam_role" "firehose" {
  count = local.logs_ingest_enabled ? 1 : 0

  name               = "${local.name_prefix}-firehose-role"
  assume_role_policy = data.aws_iam_policy_document.firehose_assume_role[0].json

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-firehose-role"
    }
  )
}

resource "aws_iam_role_policy" "firehose" {
  count = local.logs_ingest_enabled ? 1 : 0

  name   = "${local.name_prefix}-firehose-policy"
  role   = aws_iam_role.firehose[0].id
  policy = data.aws_iam_policy_document.firehose_permissions[0].json
}

data "aws_iam_policy_document" "log_subscription_assume_role" {
  count = local.logs_ingest_enabled ? 1 : 0

  statement {
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["logs.amazonaws.com"]
    }

    actions = [
      "sts:AssumeRole"
    ]
  }
}

data "aws_iam_policy_document" "log_subscription_permissions" {
  count = local.logs_ingest_enabled ? 1 : 0

  statement {
    sid    = "PutLogsIntoFirehose"
    effect = "Allow"

    actions = [
      "firehose:PutRecord",
      "firehose:PutRecordBatch"
    ]

    resources = [
      local.firehose_arn
    ]
  }

  dynamic "statement" {
    for_each = var.use_cmk ? [1] : []

    content {
      sid    = "UseLogIngestionKmsKey"
      effect = "Allow"

      actions = [
        "kms:GenerateDataKey",
        "kms:Decrypt"
      ]

      resources = [
        aws_kms_key.log_ingest[0].arn
      ]
    }
  }
}

resource "aws_iam_role" "log_subscription" {
  count = local.logs_ingest_enabled ? 1 : 0

  name               = "${local.name_prefix}-log-subscription-role"
  assume_role_policy = data.aws_iam_policy_document.log_subscription_assume_role[0].json

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-log-subscription-role"
    }
  )
}

resource "aws_iam_role_policy" "log_subscription" {
  count = local.logs_ingest_enabled ? 1 : 0

  name   = "${local.name_prefix}-log-subscription-policy"
  role   = aws_iam_role.log_subscription[0].id
  policy = data.aws_iam_policy_document.log_subscription_permissions[0].json
}
