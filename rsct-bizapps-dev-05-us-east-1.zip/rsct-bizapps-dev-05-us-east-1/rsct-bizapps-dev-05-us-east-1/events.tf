resource "aws_cloudwatch_event_connection" "dynatrace" {
  count = local.event_ingest_enabled ? 1 : 0

  name               = local.event_connection_name
  authorization_type = "API_KEY"
  description        = "Dynatrace EventBridge ingestion connection"

  kms_key_identifier = (
    var.use_cmk ? aws_kms_key.api_client[0].arn : null
  )

  auth_parameters {
    api_key {
      key   = "Authorization"
      value = "Bearer ${var.dynatrace_ingest_token}"
    }

    invocation_http_parameters {
      header {
        key   = "Dt-Tenant"
        value = local.environment_id
      }
    }
  }
}

resource "aws_cloudwatch_event_api_destination" "dynatrace" {
  count = local.event_ingest_enabled ? 1 : 0

  name                             = local.event_destination_name
  connection_arn                   = aws_cloudwatch_event_connection.dynatrace[0].arn
  invocation_endpoint              = local.dynatrace_eventbridge_endpoint
  http_method                      = "POST"
  invocation_rate_limit_per_second = 100
  description                      = "Dynatrace EventBridge API destination"

  depends_on = [
    aws_cloudwatch_event_connection.dynatrace
  ]
}

data "aws_iam_policy_document" "eventbridge_assume_role" {
  count = local.event_ingest_enabled ? 1 : 0

  statement {
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["events.amazonaws.com"]
    }

    actions = [
      "sts:AssumeRole"
    ]
  }
}

data "aws_iam_policy_document" "eventbridge_permissions" {
  count = local.event_ingest_enabled ? 1 : 0

  statement {
    sid    = "InvokeDynatraceApiDestination"
    effect = "Allow"

    actions = [
      "events:InvokeApiDestination"
    ]

    resources = [
      aws_cloudwatch_event_api_destination.dynatrace[0].arn
    ]
  }
}

resource "aws_iam_role" "eventbridge" {
  count = local.event_ingest_enabled ? 1 : 0

  name               = "${local.name_prefix}-eventbridge-role"
  assume_role_policy = data.aws_iam_policy_document.eventbridge_assume_role[0].json

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-eventbridge-role"
    }
  )
}

resource "aws_iam_role_policy" "eventbridge" {
  count = local.event_ingest_enabled ? 1 : 0

  name   = "${local.name_prefix}-eventbridge-policy"
  role   = aws_iam_role.eventbridge[0].id
  policy = data.aws_iam_policy_document.eventbridge_permissions[0].json
}

resource "aws_cloudwatch_event_rule" "dynatrace" {
  count = local.event_ingest_enabled ? 1 : 0

  name           = local.event_rule_name
  event_bus_name = local.event_bus_name
  description    = "Forward selected AWS events to Dynatrace."

  event_pattern = jsonencode({
    source = var.event_sources
  })

  tags = merge(
    local.common_tags,
    {
      Name = local.event_rule_name
    }
  )
}

resource "aws_cloudwatch_event_target" "dynatrace" {
  count = local.event_ingest_enabled ? 1 : 0

  rule           = aws_cloudwatch_event_rule.dynatrace[0].name
  event_bus_name = local.event_bus_name
  target_id      = "dynatrace"
  arn            = aws_cloudwatch_event_api_destination.dynatrace[0].arn
  role_arn       = aws_iam_role.eventbridge[0].arn

  retry_policy {
    maximum_event_age_in_seconds = 86400
    maximum_retry_attempts       = 185
  }

  depends_on = [
    aws_iam_role_policy.eventbridge
  ]
}