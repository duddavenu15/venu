resource "aws_kms_key" "log_ingest" {
  count = var.use_cmk && local.logs_ingest_enabled ? 1 : 0

  description             = "Dynatrace log-ingestion encryption key"
  deletion_window_in_days = 30
  enable_key_rotation     = true

  policy = jsonencode({
    Version = "2012-10-17"

    Statement = [
      {
        Sid    = "EnableAccountRootPermissions"
        Effect = "Allow"

        Principal = {
          AWS = "arn:aws:iam::${var.account_id}:root"
        }

        Action   = "kms:*"
        Resource = "*"
      },
      {
        Sid    = "AllowCloudWatchLogs"
        Effect = "Allow"

        Principal = {
          Service = "logs.${var.region}.amazonaws.com"
        }

        Action = [
          "kms:Encrypt",
          "kms:Decrypt",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:CreateGrant",
          "kms:DescribeKey"
        ]

        Resource = "*"

        Condition = {
          ArnLike = {
            "kms:EncryptionContext:aws:logs:arn" = format(
              "arn:aws:logs:%s:%s:log-group:/aws/datafirehose/dynatrace/*",
              var.region,
              var.account_id
            )
          }

          StringEquals = {
            "aws:SourceAccount" = var.account_id
          }
        }
      },
      {
        Sid    = "AllowIngestionServices"
        Effect = "Allow"

        Principal = {
          Service = [
            "firehose.amazonaws.com",
            "s3.amazonaws.com",
            "secretsmanager.amazonaws.com"
          ]
        }

        Action = [
          "kms:Decrypt",
          "kms:GenerateDataKey",
          "kms:CreateGrant"
        ]

        Resource = "*"

        Condition = {
          StringEquals = {
            "aws:SourceAccount" = var.account_id
          }

          StringEqualsIfExists = {
            "kms:ViaService" = [
              "firehose.${var.region}.amazonaws.com",
              "s3.${var.region}.amazonaws.com",
              "secretsmanager.${var.region}.amazonaws.com"
            ]
          }
        }
      }
    ]
  })

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-log-ingest"
  })
}

resource "aws_kms_alias" "log_ingest" {
  count = var.use_cmk && local.logs_ingest_enabled ? 1 : 0

  name          = local.log_ingest_kms_alias_name
  target_key_id = aws_kms_key.log_ingest[0].key_id
}