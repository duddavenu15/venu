###############################################################################
# Package the Lambda Python source directly.
# AWS Signer / Lambda code signing is not configured.
###############################################################################

data "archive_file" "dynatrace_api_client" {
  type        = "zip"
  source_file = "${path.module}/lambda/dynatrace_api_client/lambda_function.py"
  output_path = "${path.module}/.terraform/dynatrace_api_client.zip"
}

###############################################################################
# Lambda execution-role trust
###############################################################################

data "aws_iam_policy_document" "api_client_assume_role" {
  statement {
    sid    = "AllowLambdaServiceAssumeRole"
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }

    actions = [
      "sts:AssumeRole"
    ]
  }
}

###############################################################################
# Lambda execution role
###############################################################################

resource "aws_iam_role" "api_client" {
  name               = local.api_lambda_role_name
  assume_role_policy = data.aws_iam_policy_document.api_client_assume_role.json

  tags = merge(
    local.common_tags,
    {
      Name = local.api_lambda_role_name
    }
  )
}

###############################################################################
# Lambda permissions
###############################################################################

data "aws_iam_policy_document" "api_client_permissions" {
  statement {
    sid    = "WriteLambdaLogs"
    effect = "Allow"

    actions = [
      "logs:CreateLogStream",
      "logs:PutLogEvents"
    ]

    resources = [
      "${aws_cloudwatch_log_group.api_client.arn}:*"
    ]
  }

  statement {
    sid    = "SendFailedAsyncInvocationsToDlq"
    effect = "Allow"

    actions = [
      "sqs:SendMessage"
    ]

    resources = [
      aws_sqs_queue.api_client_dlq.arn
    ]
  }

  statement {
    sid    = "ReadSettingsToken"
    effect = "Allow"

    actions = [
      "secretsmanager:GetSecretValue"
    ]

    resources = [
      aws_secretsmanager_secret.settings_token.arn
    ]
  }

  dynamic "statement" {
    for_each = var.use_cmk ? [1] : []

    content {
      sid    = "DecryptSettingsToken"
      effect = "Allow"

      actions = [
        "kms:Decrypt"
      ]

      resources = [
        aws_kms_key.api_client[0].arn
      ]
    }
  }
}

resource "aws_iam_role_policy" "api_client" {
  name   = "DynatraceApiClientLambdaPolicy"
  role   = aws_iam_role.api_client.id
  policy = data.aws_iam_policy_document.api_client_permissions.json
}

###############################################################################
# Lambda log group
###############################################################################

resource "aws_cloudwatch_log_group" "api_client" {
  name              = "/aws/lambda/${local.name_prefix}-api-client"
  retention_in_days = 30
  kms_key_id        = var.use_cmk ? aws_kms_key.api_client[0].arn : null

  tags = merge(
    local.common_tags,
    {
      Name = "/aws/lambda/${local.name_prefix}-api-client"
    }
  )
}

###############################################################################
# Lambda function — original direct ZIP deployment
###############################################################################

resource "aws_lambda_function" "api_client" {
  function_name = "${local.name_prefix}-api-client"
  description   = "Dynatrace AWS configuration API client."

  role    = aws_iam_role.api_client.arn
  handler = "lambda_function.handler"
  runtime = "python3.13"

  timeout     = 120
  memory_size = 256

  filename = data.archive_file.dynatrace_api_client.output_path

  source_code_hash = (
    data.archive_file.dynatrace_api_client.output_base64sha256
  )

  dead_letter_config {
    target_arn = aws_sqs_queue.api_client_dlq.arn
  }

  environment {
    variables = {
      DT_ENVIRONMENT_URL = var.dynatrace_url
      DT_API_SECRET_ARN  = aws_secretsmanager_secret.settings_token.arn
      LOG_LEVEL          = "INFO"
    }
  }

  logging_config {
    log_format = "JSON"
    log_group  = aws_cloudwatch_log_group.api_client.name
  }

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-api-client"
    }
  )

  depends_on = [
    aws_iam_role_policy.api_client,
    aws_cloudwatch_log_group.api_client,
    aws_secretsmanager_secret_version.settings_token
  ]
}