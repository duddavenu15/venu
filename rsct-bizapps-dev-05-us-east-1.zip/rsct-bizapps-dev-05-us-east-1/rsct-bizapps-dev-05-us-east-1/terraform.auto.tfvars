account_id = "160893582671"
region     = "us-east-1"

dynatrace_url        = "https://ugt80968.apps.dynatrace.com"
monitoring_config_id = "159ffcd8-010f-3e1b-a14e-1046ee54d8f8"

use_cmk = true

logs_ingest_enabled = true
logs_ingest_regions = ["us-east-1"]

events_ingest_enabled = true
events_ingest_regions = ["us-east-1"]

event_bridge_bus_name = "default"
event_sources         = ["aws.health"]

# Do not add these values here:
# dynatrace_api_token   = "..."
# dynatrace_ingest_token = "..."