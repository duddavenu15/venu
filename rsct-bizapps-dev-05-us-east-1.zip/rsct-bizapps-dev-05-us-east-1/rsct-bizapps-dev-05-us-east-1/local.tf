locals {

  common_tags = {
    Name                          = local.name_prefix
    environment                   = "shared"
    project                       = "not-applicable"
    "support-group-infra"         = "Infra - Monitoring"
    "support-group-product"       = "Infra - Monitoring"
    "support-group-product-email" = "CHSITMonitoring@chsinc.com"
    "cost-center"                 = "50002687"
    application                   = "Dynatrace"
    "application-number"          = "APM0002429"
    "data-classification"         = "restricted"
    "iac-url"                     = "https://dev.azure.com/chsinc/CHS/_git/terraform-aws-dynatrace"
    "iac-version"                 = "shared-services"
    "compliance-cftc"             = "false"
    "compliance-sox"              = "false"
    "compliance-pci"              = "false"
    "security-tier"               = "1"
  }
  # Remove the protocol and trailing slash before parsing the environment ID.
  environment_host = trimsuffix(
    replace(var.dynatrace_url, "https://", ""),
    "/"
  )

  environment_id = split(".", local.environment_host)[0]

  # Compatibility alias for any existing outputs or resources that use this name.
  dynatrace_environment_id = local.environment_id

  # Stable deterministic suffix.
  name_suffix = substr(
    sha1(join("|", [
      var.account_id,
      var.region,
      var.dynatrace_url
    ])),
    0,
    12
  )

  name_prefix = "dynatrace-${local.environment_id}-${local.name_suffix}"


  production_environment = (
    length(split(".", local.environment_host)) >= 3 &&
    endswith(split(".", local.environment_host)[2], "dynatrace")
  )

  event_ingest_enabled = (
    var.events_ingest_enabled &&
    contains(var.events_ingest_regions, var.region)
  )

  logs_ingest_enabled = (
    var.logs_ingest_enabled &&
    contains(var.logs_ingest_regions, var.region)
  )

  monitoring_role_name = (
    "DynatraceMonitoringRole-${local.environment_id}-${local.name_suffix}"
  )

  # Phase 2 only: the monitoring role (and everything that uses it) is created
  # once the Dynatrace Settings object ID is supplied as a known string.
  create_monitoring_role = var.dynatrace_settings_object_id != null

  # Built from known inputs so it is available at plan time.
  monitoring_role_arn = (
    "arn:aws:iam::${var.account_id}:role/${local.monitoring_role_name}"
  )

  api_lambda_role_name = (
    "DynatraceApiClientRole-${local.environment_id}-${local.name_suffix}"
  )

  ingest_secret_arn = (
    local.logs_ingest_enabled || local.event_ingest_enabled
    ? try(aws_secretsmanager_secret.ingest_token[0].arn, null)
    : null
  )

  firehose_name = "${local.name_prefix}-logs"

  # Known at plan time (the bucket name is fully derived from inputs).
  backup_bucket_arn = "arn:aws:s3:::${local.backup_bucket_name}"

  log_ingest_kms_alias_name = "alias/${local.name_prefix}/keys/aws/ingest"
  log_ingest_kms_alias_arn = (
    "arn:aws:kms:${var.region}:${var.account_id}:${local.log_ingest_kms_alias_name}"
  )

  firehose_log_group_name = (
    "/aws/datafirehose/dynatrace/${local.environment_id}/${var.region}/${local.name_suffix}"
  )

  firehose_log_stream_name = "${local.name_prefix}-firehose"

  backup_bucket_name = (
    "dynatrace-logs-backup-${local.environment_id}-${var.region}-${local.name_suffix}"
  )

  event_connection_name  = "${local.name_prefix}-event-connection"
  event_destination_name = "${local.name_prefix}-event-destination"
  event_rule_name        = "${local.name_prefix}-event-rule"

  firehose_arn = (
    "arn:aws:firehose:${var.region}:${var.account_id}:deliverystream/${local.firehose_name}"
  )

  firehose_log_group_arn = (
    "arn:aws:logs:${var.region}:${var.account_id}:log-group:${local.firehose_log_group_name}"
  )

  firehose_log_stream_arn = (
    "${local.firehose_log_group_arn}:log-stream:${local.firehose_log_stream_name}"
  )

  dynatrace_firehose_endpoint = (
    local.production_environment
    ? "https://${local.environment_id}.da.dynatrace.com/api/aws/firehose/v1/logs"
    : "https://${local.environment_id}.da.dynatracelabs.com/api/aws/firehose/v1/logs"
  )

  dynatrace_eventbridge_endpoint = (
    local.production_environment
    ? "https://${local.environment_id}.da.dynatrace.com/api/aws/eventbridge/v1/events"
    : "https://${local.environment_id}.da.dynatracelabs.com/api/aws/eventbridge/v1/events"
  )

  event_bus_name = (
    var.event_bridge_bus_name == "default"
    ? null
    : var.event_bridge_bus_name
  )
}