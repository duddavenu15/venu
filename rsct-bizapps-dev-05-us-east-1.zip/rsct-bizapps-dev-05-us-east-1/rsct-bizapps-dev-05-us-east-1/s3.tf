resource "aws_s3_bucket" "firehose_backup" {
  count = local.logs_ingest_enabled ? 1 : 0

  bucket        = local.backup_bucket_name
  force_destroy = false

  tags = merge(
    local.common_tags,
    {
      Name               = local.backup_bucket_name
      "commvault-backup" = "shared-us-east-1"
    }
  )
}

resource "aws_s3_bucket_server_side_encryption_configuration" "firehose_backup" {
  count = local.logs_ingest_enabled ? 1 : 0

  # .bucket (not .id) and the alias ARN are built from known inputs, so the
  # s3-encrypted-bucket Sentinel policy can see them at plan time.
  bucket = aws_s3_bucket.firehose_backup[0].bucket

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "aws:kms"

      kms_master_key_id = (
        var.use_cmk
        ? local.log_ingest_kms_alias_arn
        : "alias/aws/s3"
      )
    }
  }

  depends_on = [
    aws_kms_alias.log_ingest
  ]
}

resource "aws_s3_bucket_public_access_block" "firehose_backup" {
  count = local.logs_ingest_enabled ? 1 : 0

  bucket = aws_s3_bucket.firehose_backup[0].id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_versioning" "firehose_backup" {
  count = local.logs_ingest_enabled ? 1 : 0

  bucket = aws_s3_bucket.firehose_backup[0].id

  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "firehose_backup" {
  count = local.logs_ingest_enabled ? 1 : 0

  bucket = aws_s3_bucket.firehose_backup[0].id

  rule {
    id     = "expire-failed-deliveries"
    status = "Enabled"

    filter {
      prefix = ""
    }

    expiration {
      days = 14
    }

    noncurrent_version_expiration {
      noncurrent_days = 14
    }
  }

  depends_on = [
    aws_s3_bucket_versioning.firehose_backup
  ]
}

data "aws_iam_policy_document" "firehose_backup_https_only" {
  count = local.logs_ingest_enabled ? 1 : 0

  statement {
    sid    = "DenyInsecureTransport"
    effect = "Deny"

    principals {
      type        = "*"
      identifiers = ["*"]
    }

    actions = [
      "s3:*"
    ]

    resources = [
      local.backup_bucket_arn,
      "${local.backup_bucket_arn}/*"
    ]

    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"

      values = [
        "false"
      ]
    }
  }
}

resource "aws_s3_bucket_policy" "firehose_backup" {
  count = local.logs_ingest_enabled ? 1 : 0

  bucket = aws_s3_bucket.firehose_backup[0].id
  policy = data.aws_iam_policy_document.firehose_backup_https_only[0].json

  depends_on = [
    aws_s3_bucket_public_access_block.firehose_backup
  ]
}