output "aws_account_id" {
  description = "AWS account used for the deployment."
  value       = var.account_id
}

output "aws_region" {
  description = "AWS region used for the deployment."
  value       = var.region
}

output "dynatrace_environment_url" {
  description = "Dynatrace environment URL."
  value       = var.dynatrace_url
}

output "dynatrace_environment_id" {
  description = "Dynatrace environment identifier."
  value       = local.dynatrace_environment_id
}

output "monitoring_role_arn" {
  description = "IAM role ARN used by Dynatrace AWS monitoring."
  value       = local.create_monitoring_role ? aws_iam_role.monitoring[0].arn : null
}

output "next_step" {
  description = "What to do after this apply."
  value = (
    local.create_monitoring_role
    ? "Complete: monitoring role created and Dynatrace configured."
    : "Phase 1 complete. Set dynatrace_settings_object_id in terraform.auto.tfvars to the settings_object_id output and open a second PR to create the monitoring role."
  )
}

output "settings_token_secret_arn" {
  description = "Secrets Manager ARN containing the Dynatrace Settings API token."
  value       = aws_secretsmanager_secret.settings_token.arn
  sensitive   = true
}

output "ingest_token_secret_arn" {
  description = "Secrets Manager ARN containing the Dynatrace ingest token."
  value       = local.ingest_secret_arn
  sensitive   = true
}

output "api_client_lambda_arn" {
  description = "Dynatrace API-client Lambda ARN."
  value       = aws_lambda_function.api_client.arn
}

output "api_client_log_group_name" {
  description = "CloudWatch log group for the Dynatrace API-client Lambda."
  value       = aws_cloudwatch_log_group.api_client.name
}

output "settings_object_id" {
  description = "Dynatrace AWS authentication Settings object ID."
  value = jsondecode(
    aws_lambda_invocation.create_settings.result
  ).settings_object_id
}

output "monitoring_configuration_id" {
  description = "Dynatrace AWS monitoring configuration ID."
  value       = var.monitoring_config_id
}

output "firehose_delivery_stream_arn" {
  description = "Dynatrace log-ingestion Firehose ARN."
  value = local.logs_ingest_enabled ? (
    aws_kinesis_firehose_delivery_stream.dynatrace_logs[0].arn
  ) : null
}

output "firehose_backup_bucket_name" {
  description = "S3 bucket used for failed Firehose deliveries."
  value = local.logs_ingest_enabled ? (
    aws_s3_bucket.firehose_backup[0].bucket
  ) : null
}

output "log_subscription_role_arn" {
  description = "IAM role for CloudWatch Logs subscription filters."
  value = local.logs_ingest_enabled ? (
    aws_iam_role.log_subscription[0].arn
  ) : null
}

output "eventbridge_connection_arn" {
  description = "Dynatrace EventBridge connection ARN."
  value = local.event_ingest_enabled ? (
    aws_cloudwatch_event_connection.dynatrace[0].arn
  ) : null
}

output "eventbridge_api_destination_arn" {
  description = "Dynatrace EventBridge API destination ARN."
  value = local.event_ingest_enabled ? (
    aws_cloudwatch_event_api_destination.dynatrace[0].arn
  ) : null
}

output "eventbridge_rule_arn" {
  description = "Dynatrace EventBridge forwarding rule ARN."
  value = local.event_ingest_enabled ? (
    aws_cloudwatch_event_rule.dynatrace[0].arn
  ) : null
}

output "api_client_kms_key_arn" {
  description = "Optional KMS key used by the API client and Secrets Manager."
  value       = var.use_cmk ? aws_kms_key.api_client[0].arn : null
}

output "log_ingest_kms_key_arn" {
  description = "Optional KMS key used for log ingestion."
  value = var.use_cmk && local.logs_ingest_enabled ? (
    aws_kms_key.log_ingest[0].arn
  ) : null
}