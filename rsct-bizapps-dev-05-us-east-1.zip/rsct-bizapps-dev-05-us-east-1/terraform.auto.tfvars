account_id = "160893582671"
region     = "us-east-1"

dynatrace_url        = "https://ugt80968.apps.dynatrace.com"
monitoring_config_id = "80724e1c-e09a-3367-89dd-13f5b6783a68"

use_cmk = true

logs_ingest_enabled = true
logs_ingest_regions = ["us-east-1"]

events_ingest_enabled = true
events_ingest_regions = ["us-east-1"]

event_bridge_bus_name = "default"
event_sources         = ["aws.health"]

# Do not add these values here:
# dynatrace_api_token   = "..."
# dynatrace_ingest_token = "..."
