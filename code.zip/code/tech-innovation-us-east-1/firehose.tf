resource "aws_kinesis_firehose_delivery_stream" "dynatrace_logs" {
  count = local.logs_ingest_enabled ? 1 : 0

  name        = local.firehose_name
  destination = "http_endpoint"

  server_side_encryption {
    enabled  = true
    key_type = "AWS_OWNED_CMK"
  }

  http_endpoint_configuration {
    name               = "Dynatrace delivery endpoint"
    url                = local.dynatrace_firehose_endpoint
    access_key         = var.dynatrace_ingest_token
    role_arn           = aws_iam_role.firehose[0].arn
    buffering_interval = 60
    buffering_size     = 1
    retry_duration     = 7200
    s3_backup_mode     = "FailedDataOnly"

    request_configuration {
      content_encoding = "GZIP"
    }

    cloudwatch_logging_options {
      enabled         = true
      log_group_name  = aws_cloudwatch_log_group.firehose[0].name
      log_stream_name = aws_cloudwatch_log_stream.firehose[0].name
    }

    s3_configuration {
      bucket_arn = aws_s3_bucket.firehose_backup[0].arn
      role_arn   = aws_iam_role.firehose[0].arn
    }
  }

  tags = merge(
    local.common_tags,
    {
      Name = local.firehose_name
    }
  )

  depends_on = [
    aws_iam_role_policy.firehose,
    aws_cloudwatch_log_stream.firehose,
    aws_s3_bucket_server_side_encryption_configuration.firehose_backup,
    aws_s3_bucket_policy.firehose_backup
  ]
}