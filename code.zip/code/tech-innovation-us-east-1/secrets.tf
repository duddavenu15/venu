resource "aws_secretsmanager_secret" "settings_token" {
  name                    = "/dynatrace/${local.environment_id}/tokens/aws/integration/${local.name_suffix}"
  description             = "Dynatrace Settings API token"
  recovery_window_in_days = 30

  kms_key_id = var.use_cmk ? aws_kms_key.api_client[0].arn : null

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-settings-token"
    }
  )
}

resource "aws_secretsmanager_secret_version" "settings_token" {
  secret_id = aws_secretsmanager_secret.settings_token.id

  secret_string = jsonencode({
    dynatrace_api_token = var.dynatrace_api_token
  })
}

resource "aws_secretsmanager_secret" "ingest_token" {
  count = local.logs_ingest_enabled || local.event_ingest_enabled ? 1 : 0

  name                    = "/dynatrace/${local.environment_id}/tokens/aws/ingest/${local.name_suffix}"
  description             = "Dynatrace ingest API token"
  recovery_window_in_days = 30

  kms_key_id = var.use_cmk ? aws_kms_key.api_client[0].arn : null

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-ingest-token"
    }
  )
}

resource "aws_secretsmanager_secret_version" "ingest_token" {
  count = local.logs_ingest_enabled || local.event_ingest_enabled ? 1 : 0

  secret_id = aws_secretsmanager_secret.ingest_token[0].id

  secret_string = jsonencode({
    api_key = var.dynatrace_ingest_token
  })
}