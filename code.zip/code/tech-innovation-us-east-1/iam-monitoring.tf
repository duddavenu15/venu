###############################################################################
# Dynatrace trust configuration
#
# Restores the account-level principals from the original configuration.
# No unverified Dynatrace caller-role ARN is introduced.
#
# CKV_AWS_61 remains subject to vendor confirmation/security review.
###############################################################################

locals {
  dynatrace_trusted_account_id = (
    local.production_environment
    ? "314146291599"
    : "476114158034"
  )

  dynatrace_trusted_principal_arn = format(
    "arn:aws:iam::%s:root",
    local.dynatrace_trusted_account_id
  )
}

###############################################################################
# Monitoring policy 1
#
# Existing discovery permissions are preserved.
# KMS key metadata permissions are separated and scoped below.
#
# Other resource-scopable actions still require review for CKV_AWS_355.
###############################################################################

data "aws_iam_policy_document" "monitoring_policy_1" {
  statement {
    sid    = "TopologyInventory"
    effect = "Allow"

    actions = [
      "account:GetAccountInformation",
      "acm-pca:ListCertificateAuthorities",
      "aoss:BatchGetCollection",
      "aoss:ListCollections",
      "apigateway:GET",
      "apprunner:DescribeAutoScalingConfiguration",
      "apprunner:DescribeService",
      "apprunner:DescribeVpcConnector",
      "apprunner:DescribeVpcIngressConnection",
      "apprunner:ListAutoScalingConfigurations",
      "apprunner:ListServices",
      "apprunner:ListTagsForResource",
      "apprunner:ListVpcConnectors",
      "apprunner:ListVpcIngressConnections",
      "athena:GetWorkGroup",
      "athena:ListWorkGroups",
      "autoscaling:DescribeAutoScalingGroups",
      "autoscaling:DescribeWarmPool",
      "bedrock:GetAgent",
      "bedrock:GetAgentAlias",
      "bedrock:GetGuardrail",
      "bedrock:GetKnowledgeBase",
      "bedrock:ListAgentAliases",
      "bedrock:ListAgents",
      "bedrock:ListGuardrails",
      "bedrock:ListKnowledgeBases",
      "cloudfront:GetDistribution",
      "cloudfront:ListDistributions",
      "cloudfront:ListTagsForResource",
      "cloudhsm:DescribeClusters",
      "cloudtrail:GetEventSelectors",
      "cloudtrail:GetTrail",
      "cloudtrail:GetTrailStatus",
      "cloudtrail:ListTrails",
      "cloudtrail:LookupEvents",
      "dax:DescribeClusters",
      "dax:DescribeSubnetGroups",
      "directconnect:DescribeConnections",
      "directconnect:DescribeVirtualInterfaces",
      "dms:DescribeReplicationInstances",
      "dynamodb:DescribeContinuousBackups",
      "dynamodb:DescribeKinesisStreamingDestination",
      "dynamodb:DescribeTable",
      "dynamodb:DescribeTimeToLive",
      "dynamodb:ListTables",
      "ec2:DescribeAddresses",
      "ec2:DescribeAvailabilityZones",
      "ec2:DescribeClientVpnEndpoints",
      "ec2:DescribeCustomerGateways",
      "ec2:DescribeDhcpOptions",
      "ec2:DescribeEgressOnlyInternetGateways",
      "ec2:DescribeIamInstanceProfileAssociations",
      "ec2:DescribeInstances",
      "ec2:DescribeInternetGateways",
      "ec2:DescribeLaunchTemplateVersions",
      "ec2:DescribeLaunchTemplates",
      "ec2:DescribeNatGateways",
      "ec2:DescribeNetworkAcls",
      "ec2:DescribeNetworkInterfaces",
      "ec2:DescribeRegions",
      "ec2:DescribeRouteTables",
      "ec2:DescribeSecurityGroups",
      "ec2:DescribeSnapshots",
      "ec2:DescribeSubnets",
      "ec2:DescribeTransitGatewayAttachments",
      "ec2:DescribeTransitGatewayConnects",
      "ec2:DescribeTransitGatewayMulticastDomains",
      "ec2:DescribeTransitGatewayRouteTables",
      "ec2:DescribeTransitGateways",
      "ec2:DescribeVolumes",
      "ec2:DescribeVpcEndpointServiceConfigurations",
      "ec2:DescribeVpcEndpoints",
      "ec2:DescribeVpcPeeringConnections",
      "ec2:DescribeVpcs",
      "ec2:DescribeVpnConnections",
      "ec2:DescribeVpnGateways",
      "ecr-public:DescribeRepositories",
      "ecr-public:GetRepositoryPolicy",
      "ecr:DescribeRepositories",
      "ecr:GetRepositoryPolicy",
      "ecs:DescribeCapacityProviders",
      "ecs:DescribeClusters",
      "ecs:DescribeContainerInstances",
      "ecs:DescribeServices",
      "ecs:DescribeTaskDefinition",
      "ecs:DescribeTasks",
      "ecs:ListClusters",
      "ecs:ListContainerInstances",
      "ecs:ListServices",
      "ecs:ListTaskDefinitions",
      "ecs:ListTasks",
      "eks:DescribeCluster",
      "eks:DescribeNodegroup",
      "eks:ListClusters",
      "eks:ListNodegroups",
      "elasticache:DescribeCacheClusters",
      "elasticache:DescribeCacheParameterGroups",
      "elasticache:DescribeCacheParameters",
      "elasticache:DescribeCacheSubnetGroups",
      "elasticache:DescribeServerlessCaches",
      "elasticbeanstalk:DescribeApplications",
      "elasticbeanstalk:DescribeEnvironmentResources",
      "elasticbeanstalk:DescribeEnvironments",
      "elasticfilesystem:DescribeAccessPoints",
      "elasticfilesystem:DescribeFileSystems",
      "elasticfilesystem:DescribeMountTargets",
      "elasticloadbalancing:DescribeListeners",
      "elasticloadbalancing:DescribeLoadBalancerAttributes",
      "elasticloadbalancing:DescribeLoadBalancerPolicies",
      "elasticloadbalancing:DescribeLoadBalancers",
      "elasticloadbalancing:DescribeRules",
      "elasticloadbalancing:DescribeTargetGroupAttributes",
      "elasticloadbalancing:DescribeTargetGroups",
      "elasticloadbalancing:DescribeTargetHealth",
      "es:DescribeDomains",
      "es:ListDomainNames",
      "events:DescribeEventBus",
      "events:ListEventBuses",
      "firehose:DescribeDeliveryStream",
      "firehose:ListDeliveryStreams",
      "iam:GenerateCredentialReport",
      "iam:GetAccountAuthorizationDetails",
      "iam:GetAccountPasswordPolicy",
      "iam:GetAccountSummary",
      "iam:GetCredentialReport",
      "iam:ListAccountAliases",
      "iam:ListInstanceProfiles",
      "iam:ListMFADevices",
      "iam:ListServerCertificates",
      "kafka:ListClustersV2",
      "kms:ListAliases",
      "kms:ListKeys",
      "lambda:GetAlias",
      "lambda:GetFunction",
      "lambda:GetPolicy",
      "lambda:ListAliases",
      "lambda:ListEventSourceMappings",
      "lambda:ListFunctions",
      "logs:DescribeLogGroups",
      "logs:DescribeSubscriptionFilters",
      "mediaconvert:DescribeEndpoints",
      "mediaconvert:ListQueues",
      "mq:DescribeBroker",
      "mq:DescribeConfiguration",
      "mq:ListBrokers",
      "mq:ListConfigurations",
      "organizations:DescribeOrganization",
      "rds:DescribeOptionGroups",
      "rds:ListTagsForResource",
      "redshift-serverless:ListNamespaces",
      "redshift-serverless:ListWorkgroups",
      "redshift:DescribeClusterSubnetGroups",
      "redshift:DescribeClusters",
      "redshift:DescribeLoggingStatus",
      "route53:GetHostedZone",
      "route53:ListHealthChecks",
      "route53:ListHostedZones",
      "s3:GetAccelerateConfiguration",
      "s3:GetBucketAcl",
      "s3:GetBucketLogging",
      "s3:GetBucketNotification",
      "s3:GetBucketPolicy",
      "s3:GetBucketPublicAccessBlock",
      "s3:GetBucketRequestPayment",
      "s3:GetBucketVersioning",
      "s3:GetEncryptionConfiguration",
      "s3:ListAllMyBuckets",
      "sns:GetTopicAttributes",
      "sns:ListTopics",
      "sqs:GetQueueAttributes",
      "sqs:ListQueues",
      "states:DescribeStateMachine",
      "states:ListStateMachines",
      "storagegateway:DescribeGatewayInformation",
      "storagegateway:ListGateways",
      "tag:GetResources",
      "tag:GetTagKeys",
      "tag:GetTagValues",
      "wafv2:GetWebACL",
      "wafv2:ListWebACLs"
    ]

    resources = ["*"]
  }

  statement {
    sid    = "CloudWatchMonitoring"
    effect = "Allow"

    actions = [
      "cloudwatch:GetMetricData",
      "cloudwatch:ListMetrics"
    ]

    resources = ["*"]
  }

  statement {
    sid    = "ReadAccountRegionKmsKeyMetadata"
    effect = "Allow"

    actions = [
      "kms:DescribeKey",
      "kms:GetKeyRotationStatus"
    ]

    resources = [
      "arn:aws:kms:${var.region}:${var.account_id}:key/*"
    ]
  }
}

###############################################################################
# Monitoring policy 2
#
# Existing permissions are preserved.
# Additional resource-level scoping is required for CKV_AWS_355.
###############################################################################

data "aws_iam_policy_document" "monitoring_policy_2" {
  statement {
    sid    = "CassandraTopology"
    effect = "Allow"

    actions = [
      "cassandra:Select"
    ]

    resources = [
      "arn:aws:cassandra:*:${var.account_id}:/keyspace/system*"
    ]
  }

  statement {
    sid    = "TopologyInventory"
    effect = "Allow"

    actions = [
      "acm:ListCertificates",
      "airflow:GetEnvironment",
      "airflow:ListEnvironments",
      "appstream:DescribeFleets",
      "appstream:ListTagsForResource",
      "appsync:ListGraphqlApis",
      "backup:GetBackupPlan",
      "backup:GetBackupVaultNotifications",
      "backup:ListBackupPlans",
      "backup:ListBackupVaults",
      "cloudsearch:DescribeDomains",
      "codebuild:BatchGetProjects",
      "codebuild:ListProjects",
      "cognito-idp:DescribeUserPool",
      "cognito-idp:ListUserPools",
      "connect:DescribeInstance",
      "connect:ListInstanceStorageConfigs",
      "connect:ListInstances",
      "datasync:DescribeAgent",
      "datasync:DescribeTask",
      "datasync:ListAgents",
      "datasync:ListLocations",
      "datasync:ListTasks",
      "ec2:DescribeFlowLogs",
      "ec2:DescribeIpamPools",
      "ec2:DescribeIpamScopes",
      "ec2:DescribeIpams",
      "ec2:DescribeSpotFleetRequests",
      "elasticmapreduce:DescribeCluster",
      "elasticmapreduce:ListClusters",
      "emr-containers:DescribeManagedEndpoint",
      "emr-containers:DescribeVirtualCluster",
      "emr-containers:ListVirtualClusters",
      "emr-serverless:GetApplication",
      "emr-serverless:ListApplications",
      "events:ListRules",
      "fsx:DescribeFileSystems",
      "fsx:DescribeStorageVirtualMachines",
      "fsx:DescribeVolumes",
      "globalaccelerator:DescribeListener",
      "globalaccelerator:ListAccelerators",
      "globalaccelerator:ListListeners",
      "globalaccelerator:ListTagsForResource",
      "glue:GetJobs",
      "inspector2:ListFilters",
      "iot:DescribeJob",
      "iot:ListJobs",
      "iot:ListTagsForResource",
      "kafka:DescribeClusterV2",
      "kafka:DescribeConfiguration",
      "kafka:DescribeVpcConnection",
      "kafka:ListConfigurations",
      "kafka:ListVpcConnections",
      "kafkaconnect:DescribeConnector",
      "kafkaconnect:ListConnectors",
      "kinesis:DescribeStreamSummary",
      "kinesis:ListStreams",
      "kinesisanalytics:DescribeApplication",
      "kinesisanalytics:ListApplications",
      "kinesisvideo:DescribeStream",
      "kinesisvideo:DescribeStreamStorageConfiguration",
      "kinesisvideo:ListStreams",
      "logs:DescribeDeliveryDestinations",
      "network-firewall:DescribeFirewall",
      "network-firewall:DescribeFirewallPolicy",
      "network-firewall:ListFirewallPolicies",
      "network-firewall:ListFirewalls",
      "rds:DescribeDBClusterSnapshots",
      "rds:DescribeDBClusters",
      "rds:DescribeDBInstances",
      "rds:DescribeDBSnapshots",
      "rds:DescribeDBSubnetGroups",
      "redshift-serverless:GetNamespace",
      "route53:GetHealthCheck",
      "route53resolver:GetResolverEndpoint",
      "route53resolver:ListResolverEndpointIpAddresses",
      "route53resolver:ListResolverEndpoints",
      "sagemaker:DescribeEndpoint",
      "sagemaker:DescribeFeatureGroup",
      "sagemaker:DescribeInferenceComponent",
      "sagemaker:DescribeLabelingJob",
      "sagemaker:DescribePipeline",
      "sagemaker:DescribeProcessingJob",
      "sagemaker:DescribeTrainingJob",
      "sagemaker:DescribeTransformJob",
      "sagemaker:ListEndpoints",
      "sagemaker:ListFeatureGroups",
      "sagemaker:ListInferenceComponents",
      "sagemaker:ListLabelingJobs",
      "sagemaker:ListPipelines",
      "sagemaker:ListProcessingJobs",
      "sagemaker:ListTags",
      "sagemaker:ListTrainingJobs",
      "sagemaker:ListTransformJobs",
      "secretsmanager:ListSecrets",
      "servicecatalog:DescribeProvisioningArtifact",
      "servicecatalog:ListPortfolios",
      "servicecatalog:ListProvisioningArtifacts",
      "servicecatalog:SearchProductsAsAdmin",
      "ssm:DescribeParameters",
      "swf:DescribeDomain",
      "swf:ListActivityTypes",
      "swf:ListDomains",
      "swf:ListTagsForResource",
      "swf:ListWorkflowTypes",
      "transfer:DescribeServer",
      "transfer:ListServers",
      "waf:GetRule",
      "waf:GetRuleGroup",
      "waf:GetWebACL",
      "waf:ListRuleGroups",
      "waf:ListRules",
      "waf:ListWebACLs",
      "workspaces:DescribeWorkspaceDirectories",
      "workspaces:DescribeWorkspaces"
    ]

    resources = ["*"]
  }
}

###############################################################################
# Monitoring-role trust
###############################################################################

data "aws_iam_policy_document" "monitoring_role_trust" {
  statement {
    sid    = "AllowDynatraceAssumeRole"
    effect = "Allow"

    principals {
      type = "AWS"

      identifiers = [
        local.dynatrace_trusted_principal_arn
      ]
    }

    actions = [
      "sts:AssumeRole"
    ]

    condition {
      test     = "StringEquals"
      variable = "sts:ExternalId"

      values = [
        jsondecode(
          aws_lambda_invocation.create_settings.result
        ).settings_object_id
      ]
    }
  }
}

###############################################################################
# Managed policies
###############################################################################

resource "aws_iam_policy" "monitoring_policy_1" {
  name        = "DynatraceMonitoringPolicy-${local.environment_id}-${local.name_suffix}"
  description = "Dynatrace AWS monitoring permissions."
  policy      = data.aws_iam_policy_document.monitoring_policy_1.json

  tags = merge(
    local.common_tags,
    {
      Name = "DynatraceMonitoringPolicy-${local.environment_id}-${local.name_suffix}"
    }
  )
}

resource "aws_iam_policy" "monitoring_policy_2" {
  name        = "DynatraceMonitoringPolicy-${local.environment_id}-${local.name_suffix}-2"
  description = "Dynatrace AWS monitoring permissions."
  policy      = data.aws_iam_policy_document.monitoring_policy_2.json

  tags = merge(
    local.common_tags,
    {
      Name = "DynatraceMonitoringPolicy-${local.environment_id}-${local.name_suffix}-2"
    }
  )
}

###############################################################################
# Monitoring role and policy attachments
###############################################################################

resource "aws_iam_role" "monitoring" {
  name               = local.monitoring_role_name
  description        = "Dynatrace Data Acquisition Monitoring Role."
  assume_role_policy = data.aws_iam_policy_document.monitoring_role_trust.json

  tags = merge(
    local.common_tags,
    {
      Name = local.monitoring_role_name
    }
  )
}

resource "aws_iam_role_policy_attachment" "monitoring_policy_1" {
  role       = aws_iam_role.monitoring.name
  policy_arn = aws_iam_policy.monitoring_policy_1.arn
}

resource "aws_iam_role_policy_attachment" "monitoring_policy_2" {
  role       = aws_iam_role.monitoring.name
  policy_arn = aws_iam_policy.monitoring_policy_2.arn
}