resource "aws_sqs_queue" "api_client_dlq" {
  name = "${local.name_prefix}-api-client-dlq"

  sqs_managed_sse_enabled = true

  tags = merge(
    local.common_tags,
    {
      Name = "${local.name_prefix}-api-client-dlq"
    }
  )
}