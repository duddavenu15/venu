variable "account_id" {
  description = "AWS account ID where the integration is deployed."
  type        = string

  validation {
    condition     = can(regex("^[0-9]{12}$", var.account_id))
    error_message = "account_id must be a 12-digit AWS account ID."
  }
}

variable "region" {
  description = "AWS deployment region."
  type        = string
  default     = "us-east-1"

  validation {
    condition     = var.region == "us-east-1"
    error_message = "This initial implementation supports us-east-1 only."
  }
}

variable "dynatrace_url" {
  description = "Dynatrace environment URL without a trailing slash."
  type        = string

  validation {
    condition     = can(regex("^https://.+[^/]$", var.dynatrace_url))
    error_message = "dynatrace_url must start with https:// and must not end with '/'."
  }
}

variable "monitoring_config_id" {
  description = "Existing Dynatrace AWS monitoring configuration ID."
  type        = string

  validation {
    condition     = can(regex("^[0-9a-fA-F-]{36}$", var.monitoring_config_id))
    error_message = "monitoring_config_id must be a UUID."
  }
}

variable "dynatrace_api_token" {
  description = "Dynatrace Settings API token. Set as a sensitive Terraform Cloud variable."
  type        = string
  sensitive   = true

  validation {
    condition     = can(regex("^dt0s16\\.[A-Z0-9]{8}\\.[A-Z0-9]{64}$", var.dynatrace_api_token))
    error_message = "dynatrace_api_token does not match the expected Dynatrace token format."
  }
}

variable "dynatrace_ingest_token" {
  description = "Dynatrace ingest token. Set as a sensitive Terraform Cloud variable."
  type        = string
  sensitive   = true

  validation {
    condition     = can(regex("^dt0s16\\.[A-Z0-9]{8}\\.[A-Z0-9]{64}$", var.dynatrace_ingest_token))
    error_message = "dynatrace_ingest_token does not match the expected Dynatrace token format."
  }
}

variable "use_cmk" {
  description = "Create customer-managed KMS keys for Dynatrace resources."
  type        = bool
  default     = false
}

variable "logs_ingest_enabled" {
  description = "Enable Dynatrace log ingestion."
  type        = bool
  default     = true
}

variable "logs_ingest_regions" {
  description = "Regions from which logs are ingested."
  type        = list(string)
  default     = ["us-east-1"]

  validation {
    condition     = alltrue([for region in var.logs_ingest_regions : region == "us-east-1"])
    error_message = "Only us-east-1 is supported by this initial implementation."
  }
}

variable "events_ingest_enabled" {
  description = "Enable Dynatrace EventBridge ingestion."
  type        = bool
  default     = true
}

variable "events_ingest_regions" {
  description = "Regions from which EventBridge events are ingested."
  type        = list(string)
  default     = ["us-east-1"]

  validation {
    condition     = alltrue([for region in var.events_ingest_regions : region == "us-east-1"])
    error_message = "Only us-east-1 is supported by this initial implementation."
  }
}

variable "event_bridge_bus_name" {
  description = "EventBridge bus to monitor."
  type        = string
  default     = "default"

  validation {
    condition     = can(regex("^[A-Za-z0-9._-]{1,256}$", var.event_bridge_bus_name))
    error_message = "event_bridge_bus_name contains invalid characters."
  }
}

variable "event_sources" {
  description = "EventBridge event sources forwarded to Dynatrace."
  type        = list(string)
  default     = ["aws.health"]

  validation {
    condition     = length(var.event_sources) > 0
    error_message = "At least one EventBridge source must be specified."
  }
}

