import json
import logging
import os
import random
import re
import string
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import boto3
from botocore.exceptions import BotoCoreError, ClientError


LOG = logging.getLogger()
LOG.setLevel(os.getenv("LOG_LEVEL", "INFO"))

secretsmanager = boto3.client("secretsmanager")

SETTINGS_OBJECTS_PATH = (
    "/platform/classic/environment-api/v2/settings/objects"
)
SETTINGS_OBJECT_PATH = (
    "/platform/classic/environment-api/v2/settings/objects/{object_id}"
)
MONITORING_CONFIGURATIONS_PATH = (
    "/platform/extensions/v2/extensions/"
    "com.dynatrace.extension.da-aws/monitoring-configurations"
)
MONITORING_CONFIGURATION_PATH = (
    MONITORING_CONFIGURATIONS_PATH + "/{configuration_id}"
)

SETTINGS_SCHEMA_ID = (
    "builtin:hyperscaler-authentication.connections.aws"
)
CONSUMER = "SVC:com.dynatrace.da"
TEMPLATE_VERSION = "v1.0.17"

# Accept Dynatrace SaaS environment URLs only.
DYNATRACE_URL_PATTERN = re.compile(
    r"^https://[A-Za-z0-9.-]+\.(dynatrace|dynatracelabs)\.com$"
)

IAM_ROLE_ARN_PATTERN = re.compile(
    r"^arn:aws:iam::([0-9]{12}):role/[A-Za-z0-9+=,.@_/-]+$"
)


class DynatraceApiError(Exception):
    """Raised when a Dynatrace API request or input validation fails."""


def require_string(value, name):
    if not isinstance(value, str) or not value.strip():
        raise DynatraceApiError(
            f"{name} must be a non-empty string."
        )

    return value


def monitoring_account_id(role_arn):
    require_string(role_arn, "monitoring_role_arn")

    match = IAM_ROLE_ARN_PATTERN.fullmatch(role_arn)
    if not match:
        raise DynatraceApiError(
            "monitoring_role_arn must be a valid AWS IAM role ARN."
        )

    return match.group(1)


def environment_url():
    value = os.getenv("DT_ENVIRONMENT_URL", "").rstrip("/")

    if not DYNATRACE_URL_PATTERN.fullmatch(value):
        raise DynatraceApiError(
            "DT_ENVIRONMENT_URL must be a valid Dynatrace SaaS URL."
        )

    return value


def settings_token():
    secret_arn = os.getenv("DT_API_SECRET_ARN")

    if not secret_arn:
        raise DynatraceApiError(
            "DT_API_SECRET_ARN is not configured."
        )

    try:
        response = secretsmanager.get_secret_value(
            SecretId=secret_arn
        )
    except ClientError as exc:
        error_code = exc.response.get("Error", {}).get(
            "Code", "Unknown"
        )
        raise DynatraceApiError(
            "Unable to read the Dynatrace settings-token secret; "
            f"AWS error code={error_code}."
        ) from exc
    except BotoCoreError as exc:
        raise DynatraceApiError(
            "Unable to access AWS Secrets Manager."
        ) from exc

    secret_string = response.get("SecretString")

    if not secret_string:
        raise DynatraceApiError(
            "The Dynatrace settings-token secret has no SecretString."
        )

    try:
        document = json.loads(secret_string)
        token = document["dynatrace_api_token"]
    except (json.JSONDecodeError, KeyError, TypeError) as exc:
        raise DynatraceApiError(
            "The Dynatrace settings-token secret is not valid JSON "
            "containing 'dynatrace_api_token'."
        ) from exc

    if not isinstance(token, str) or not token.strip():
        raise DynatraceApiError(
            "The Dynatrace settings API token is empty or invalid."
        )

    return token


def format_api_error(path, method, status, document):
    if isinstance(document, dict):
        error = document.get("error", document)
    else:
        error = document

    if isinstance(error, list):
        error = error[0] if error else {}

    if not isinstance(error, dict):
        error = {"message": str(error)}

    message = error.get("message", "no message")
    code = error.get("code", "unknown")

    # Settings API errors can contain violations directly under error.
    violations = error.get("constraintViolations")

    # Preserve support for the alternative nested response format.
    if not violations:
        details = error.get("details", {})
        if isinstance(details, dict):
            violations = details.get("constraintViolations")

    return (
        f"Dynatrace API {method} {path} failed: "
        f"HTTP {status}; code={code}; message={message}; "
        f"violations={json.dumps(violations or [], default=str)}"
    )


def request_dynatrace(path, method="GET", body=None, timeout=90):
    url = environment_url() + path

    headers = {
        "Authorization": f"Bearer {settings_token()}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }

    encoded_body = None
    if body is not None:
        try:
            encoded_body = json.dumps(body).encode("utf-8")
        except (TypeError, ValueError) as exc:
            raise DynatraceApiError(
                f"Unable to serialize the request for {method} {path}."
            ) from exc

    request = Request(
        url=url,
        data=encoded_body,
        headers=headers,
        method=method,
    )

    # Never log the authorization header, token, or request body.
    try:
        with urlopen(request, timeout=timeout) as response:
            response_body = response.read().decode("utf-8")

            if not response_body.strip():
                return {}

            try:
                return json.loads(response_body)
            except json.JSONDecodeError as exc:
                raise DynatraceApiError(
                    "Dynatrace returned a non-JSON success response "
                    f"for {method} {path}."
                ) from exc

    except HTTPError as exc:
        response_body = exc.read().decode(
            "utf-8", errors="replace"
        )

        try:
            error_document = json.loads(response_body)
        except json.JSONDecodeError:
            # Avoid including an arbitrary response body in logs.
            error_document = {
                "message": "Dynatrace returned a non-JSON error response."
            }

        message = format_api_error(
            path, method, exc.code, error_document
        )

        if "Account ID must be unique" in message:
            message = (
                "This AWS account is already monitored by Dynatrace. "
                + message
            )

        raise DynatraceApiError(message) from exc

    except URLError as exc:
        raise DynatraceApiError(
            f"Dynatrace API connection failed for "
            f"{method} {path}: {exc.reason}"
        ) from exc

    except TimeoutError as exc:
        raise DynatraceApiError(
            f"Dynatrace API request timed out for {method} {path}."
        ) from exc


def require_response_dict(response, operation):
    if not isinstance(response, dict):
        raise DynatraceApiError(
            f"Dynatrace returned an unexpected response for {operation}."
        )

    return response


def random_suffix(length=8):
    alphabet = string.ascii_lowercase + string.digits
    return "".join(
        random.choice(alphabet) for _ in range(length)
    )


def connection_payload(connection_name, role_arn):
    # Creation payload. PUT uses only the value from this document.
    return {
        "schemaId": SETTINGS_SCHEMA_ID,
        "value": {
            "name": connection_name,
            "type": "awsRoleBasedAuthentication",
            "awsRoleBasedAuthentication": {
                "roleArn": role_arn,
                "consumers": [CONSUMER],
            },
        },
    }


def create_settings_object():
    connection_name = f"da_aws_connection-{random_suffix()}"

    response = request_dynatrace(
        SETTINGS_OBJECTS_PATH,
        method="POST",
        body=[connection_payload(connection_name, "")],
    )

    if (
        not isinstance(response, list)
        or not response
        or not isinstance(response[0], dict)
    ):
        raise DynatraceApiError(
            "Dynatrace did not return a Settings object after creation."
        )

    object_id = response[0].get("objectId")

    if not isinstance(object_id, str) or not object_id:
        raise DynatraceApiError(
            "Dynatrace Settings creation response did not contain "
            "a valid objectId."
        )

    return {
        "settings_object_id": object_id,
        "connection_name": connection_name,
    }


def configure_settings_object(
    settings_object_id,
    connection_name,
    role_arn,
):
    require_string(settings_object_id, "settings_object_id")
    require_string(connection_name, "connection_name")
    monitoring_account_id(role_arn)

    path = SETTINGS_OBJECT_PATH.format(
        object_id=settings_object_id
    )

    # FIX: PUT requires the Settings update body, not the POST envelope.
    # Do not include schemaId here.
    update_body = {
        "value": connection_payload(
            connection_name,
            role_arn,
        )["value"]
    }

    response = request_dynatrace(
        path,
        method="PUT",
        body=update_body,
    )
    require_response_dict(response, "configure_settings")

    return {
        "settings_object_id": (
            response.get("objectId") or settings_object_id
        ),
        "connection_name": connection_name,
    }


def get_monitoring_configuration(configuration_id):
    require_string(
        configuration_id,
        "monitoring_configuration_id",
    )

    path = MONITORING_CONFIGURATION_PATH.format(
        configuration_id=configuration_id
    )

    response = request_dynatrace(path, method="GET")
    return require_response_dict(
        response,
        "get_monitoring_configuration",
    )


def get_aws_configuration(document):
    try:
        aws_config = document["value"]["aws"]
    except (KeyError, TypeError) as exc:
        raise DynatraceApiError(
            "The Dynatrace monitoring configuration does not "
            "contain value.aws."
        ) from exc

    if not isinstance(aws_config, dict):
        raise DynatraceApiError(
            "The Dynatrace monitoring configuration value.aws "
            "must be an object."
        )

    return aws_config


def update_monitoring_configuration(
    configuration_id,
    status=None,
):
    document = get_monitoring_configuration(configuration_id)
    aws_config = get_aws_configuration(document)

    if status is not None:
        aws_config["automatedDeploymentStatus"] = status

    aws_config["automatedDeploymentTemplateVersion"] = (
        TEMPLATE_VERSION
    )

    path = MONITORING_CONFIGURATION_PATH.format(
        configuration_id=configuration_id
    )

    # This is the Extensions API, not the Settings Objects API.
    # Preserve the existing Extensions update body.
    response = request_dynatrace(
        path,
        method="PUT",
        body=document,
    )
    require_response_dict(
        response,
        "update_monitoring_configuration",
    )

    return {
        "monitoring_configuration_id": (
            response.get("objectId") or configuration_id
        ),
        "status": status,
    }


def configure_monitoring(
    monitoring_configuration_id,
    settings_object_id,
    monitoring_role_arn,
):
    require_string(settings_object_id, "settings_object_id")
    account_id = monitoring_account_id(monitoring_role_arn)

    document = get_monitoring_configuration(
        monitoring_configuration_id
    )
    aws_config = get_aws_configuration(document)

    # Preserves original behavior:
    # replaces the entire AWS credentials list.
    aws_config["credentials"] = [
        {
            "description": "HAS connection",
            "enabled": True,
            "connectionId": settings_object_id,
            "accountId": account_id,
        }
    ]

    document["value"]["enabled"] = True
    aws_config["automatedDeploymentTemplateVersion"] = (
        TEMPLATE_VERSION
    )

    path = MONITORING_CONFIGURATION_PATH.format(
        configuration_id=monitoring_configuration_id
    )

    response = request_dynatrace(
        path,
        method="PUT",
        body=document,
    )
    require_response_dict(response, "configure_monitoring")

    return {
        "monitoring_configuration_id": (
            response.get("objectId")
            or monitoring_configuration_id
        ),
        "settings_object_id": settings_object_id,
        "account_id": account_id,
    }


def delete_settings_object(settings_object_id):
    # DESTRUCTIVE: removes the remote Dynatrace Settings connection.
    if not settings_object_id:
        return {
            "deleted": False,
            "message": "No settings_object_id was provided.",
        }

    require_string(settings_object_id, "settings_object_id")

    path = SETTINGS_OBJECT_PATH.format(
        object_id=settings_object_id
    )

    request_dynatrace(path, method="DELETE")

    return {
        "deleted": True,
        "settings_object_id": settings_object_id,
    }


def handler(event, context):
    """
    Supported operations:

    create_settings
    configure_settings
    configure_monitoring
    report_status
    report_complete
    delete_settings
    """
    if not isinstance(event, dict):
        raise DynatraceApiError(
            "The Lambda event must be a JSON object."
        )

    operation = event.get("operation")
    require_string(operation, "operation")

    LOG.info("Starting Dynatrace operation: %s", operation)

    if operation == "create_settings":
        result = create_settings_object()

    elif operation == "configure_settings":
        result = configure_settings_object(
            settings_object_id=event.get("settings_object_id"),
            connection_name=event.get("connection_name"),
            role_arn=event.get("monitoring_role_arn"),
        )

    elif operation == "configure_monitoring":
        result = configure_monitoring(
            monitoring_configuration_id=event.get(
                "monitoring_configuration_id"
            ),
            settings_object_id=event.get("settings_object_id"),
            monitoring_role_arn=event.get("monitoring_role_arn"),
        )

    elif operation in ("report_status", "report_complete"):
        status = (
            "RUNNING"
            if operation == "report_status"
            else "COMPLETE"
        )

        result = update_monitoring_configuration(
            configuration_id=event.get(
                "monitoring_configuration_id"
            ),
            status=status,
        )

    elif operation == "delete_settings":
        result = delete_settings_object(
            settings_object_id=event.get("settings_object_id")
        )

    else:
        raise DynatraceApiError(
            f"Unsupported operation: {operation}"
        )

    result["operation"] = operation
    LOG.info("Completed Dynatrace operation: %s", operation)

    return result