
resource "aws_lambda_invocation" "create_settings" {
  function_name = aws_lambda_function.api_client.function_name

  input = jsonencode({
    operation = "create_settings"
  })

  depends_on = [
    aws_iam_role_policy.api_client
  ]
}

resource "aws_lambda_invocation" "configure_settings" {
  function_name = aws_lambda_function.api_client.function_name

  input = jsonencode({
    operation          = "configure_settings"
    settings_object_id = jsondecode(
      aws_lambda_invocation.create_settings.result
    ).settings_object_id
    connection_name = jsondecode(
      aws_lambda_invocation.create_settings.result
    ).connection_name
    monitoring_role_arn = aws_iam_role.monitoring.arn
  })

  lifecycle {
    replace_triggered_by = [
      aws_lambda_function.api_client.source_code_hash,
      aws_iam_role.monitoring
    ]
  }

  depends_on = [
  aws_lambda_invocation.create_settings,
  time_sleep.monitoring_iam_ready
]
}

resource "aws_lambda_invocation" "configure_monitoring" {
  function_name = aws_lambda_function.api_client.function_name

  input = jsonencode({
    operation                   = "configure_monitoring"
    monitoring_configuration_id = var.monitoring_config_id
    settings_object_id = jsondecode(
      aws_lambda_invocation.create_settings.result
    ).settings_object_id
    monitoring_role_arn = aws_iam_role.monitoring.arn
  })

  lifecycle {
    replace_triggered_by = [
      aws_lambda_function.api_client.source_code_hash,
      aws_iam_role.monitoring
    ]
  }

  depends_on = [
    aws_lambda_invocation.configure_settings
  ]
}

resource "aws_lambda_invocation" "report_status" {
  function_name = aws_lambda_function.api_client.function_name

  input = jsonencode({
    operation                   = "report_status"
    monitoring_configuration_id = var.monitoring_config_id
  })

  lifecycle {
    replace_triggered_by = [
      aws_lambda_function.api_client.source_code_hash,
      aws_lambda_invocation.configure_monitoring
    ]
  }

  depends_on = [
    aws_lambda_invocation.configure_monitoring
  ]
}
resource "time_sleep" "monitoring_iam_ready" {
  create_duration = "60s"

  triggers = {
    trust_policy_sha = sha256(
      data.aws_iam_policy_document.monitoring_role_trust.json
    )
    monitoring_policy_1_sha = sha256(
      data.aws_iam_policy_document.monitoring_policy_1.json
    )
    monitoring_policy_2_sha = sha256(
      data.aws_iam_policy_document.monitoring_policy_2.json
    )
  }

  depends_on = [
    aws_iam_role.monitoring,
    aws_iam_role_policy_attachment.monitoring_policy_1,
    aws_iam_role_policy_attachment.monitoring_policy_2
  ]
}

resource "aws_lambda_invocation" "report_complete" {
  function_name = aws_lambda_function.api_client.function_name

  input = jsonencode({
    operation                   = "report_complete"
    monitoring_configuration_id = var.monitoring_config_id
  })

  lifecycle {
    replace_triggered_by = [
      aws_lambda_function.api_client.source_code_hash,
      aws_lambda_invocation.report_status,
      aws_lambda_invocation.configure_monitoring
    ]
  }

  depends_on = [
    aws_lambda_invocation.report_status,
    aws_kinesis_firehose_delivery_stream.dynatrace_logs,
    aws_cloudwatch_event_target.dynatrace
  ]
}