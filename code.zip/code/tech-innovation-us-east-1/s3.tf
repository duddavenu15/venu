resource "aws_s3_bucket" "firehose_backup" {
  count = local.logs_ingest_enabled ? 1 : 0

  bucket        = local.backup_bucket_name
  force_destroy = false

  tags = merge(
    local.common_tags,
    {
      Name               = local.backup_bucket_name
      "commvault-backup" = "shared-us-east-1"
    }
  )
}

resource "aws_s3_bucket_server_side_encryption_configuration" "firehose_backup" {
  count = local.logs_ingest_enabled ? 1 : 0

  bucket = aws_s3_bucket.firehose_backup[0].id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "aws:kms"

      kms_master_key_id = (
        var.use_cmk
        ? aws_kms_key.log_ingest[0].arn
        : "alias/aws/s3"
      )
    }
  }
}

resource "aws_s3_bucket_public_access_block" "firehose_backup" {
  count = local.logs_ingest_enabled ? 1 : 0

  bucket = aws_s3_bucket.firehose_backup[0].id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_versioning" "firehose_backup" {
  count = local.logs_ingest_enabled ? 1 : 0

  bucket = aws_s3_bucket.firehose_backup[0].id

  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "firehose_backup" {
  count = local.logs_ingest_enabled ? 1 : 0

  bucket = aws_s3_bucket.firehose_backup[0].id

  rule {
    id     = "expire-failed-deliveries"
    status = "Enabled"

    filter {
      prefix = ""
    }

    expiration {
      days = 14
    }

    noncurrent_version_expiration {
      noncurrent_days = 14
    }
  }

  depends_on = [
    aws_s3_bucket_versioning.firehose_backup
  ]
}

data "aws_iam_policy_document" "firehose_backup_https_only" {
  count = local.logs_ingest_enabled ? 1 : 0

  statement {
    sid    = "DenyInsecureTransport"
    effect = "Deny"

    principals {
      type        = "*"
      identifiers = ["*"]
    }

    actions = [
      "s3:*"
    ]

    resources = [
      aws_s3_bucket.firehose_backup[0].arn,
      "${aws_s3_bucket.firehose_backup[0].arn}/*"
    ]

    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"

      values = [
        "false"
      ]
    }
  }
}

resource "aws_s3_bucket_policy" "firehose_backup" {
  count = local.logs_ingest_enabled ? 1 : 0

  bucket = aws_s3_bucket.firehose_backup[0].id
  policy = data.aws_iam_policy_document.firehose_backup_https_only[0].json

  depends_on = [
    aws_s3_bucket_public_access_block.firehose_backup
  ]
}