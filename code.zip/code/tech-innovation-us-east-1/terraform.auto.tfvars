account_id           = "563493997896"
region               = "us-east-1"

dynatrace_url        = "https://ugt80968.apps.dynatrace.com"
monitoring_config_id = "94d03fd9-238b-35f0-b1f0-fdec7fb8f38f"

use_cmk = true

logs_ingest_enabled = true
logs_ingest_regions = ["us-east-1"]

events_ingest_enabled = true
events_ingest_regions = ["us-east-1"]

event_bridge_bus_name = "default"
event_sources         = ["aws.health"]

# Do not add these values here:
# dynatrace_api_token   = "..."
# dynatrace_ingest_token = "..."