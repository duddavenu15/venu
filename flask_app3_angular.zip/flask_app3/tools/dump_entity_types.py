#!/usr/bin/env python3
"""
Dump every entity type in the Dynatrace tenant into entity_types.json, which
drives the "Entity Type" dropdown on the Create page.

    export DYNATRACE_BASE_URL=https://xxxx.live.dynatrace.com
    export DYNATRACE_API_TOKEN=dt0c01....          # needs entities.read
    python tools/dump_entity_types.py               # all types
    python tools/dump_entity_types.py --in-use      # only types with >=1 entity (recommended)
    python tools/dump_entity_types.py -o other.json

Hand-edit the "label" values afterwards if you want friendlier names, and
delete any types the team shouldn't be putting into maintenance.
"""
import argparse
import json
import os
import sys
import urllib.parse
import urllib.request

BASE = os.environ.get("DYNATRACE_BASE_URL", "").rstrip("/")
TOKEN = os.environ.get("DYNATRACE_API_TOKEN", "")
DEFAULT_OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "entity_types.json")


def get(path, params):
    url = f"{BASE}{path}?{urllib.parse.urlencode(params)}"
    req = urllib.request.Request(url, headers={"Authorization": f"Api-Token {TOKEN}", "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read().decode("utf-8"))


def all_types():
    types, params = [], {"pageSize": "500"}
    while True:
        body = get("/api/v2/entityTypes", params)
        types.extend(body.get("types", []))
        nxt = body.get("nextPageKey")
        if not nxt:
            return types
        params = {"nextPageKey": nxt}  # Dynatrace rejects other params alongside nextPageKey


def entity_count(type_id):
    body = get("/api/v2/entities", {"entitySelector": f'type("{type_id}")', "pageSize": "1", "from": "now-3y"})
    return body.get("totalCount", 0)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--in-use", action="store_true", help="only keep types that have at least one entity")
    ap.add_argument("-o", "--out", default=DEFAULT_OUT)
    args = ap.parse_args()
    if not BASE or not TOKEN:
        sys.exit("Set DYNATRACE_BASE_URL and DYNATRACE_API_TOKEN first.")

    rows = []
    for t in sorted(all_types(), key=lambda t: t.get("type", "")):
        tid = t.get("type")
        if not tid:
            continue
        row = {"type": tid, "label": t.get("displayName") or tid}
        if args.in_use:
            try:
                n = entity_count(tid)
            except Exception as e:
                print(f"  ! {tid}: {e}", file=sys.stderr)
                continue
            if n == 0:
                continue
            row["count"] = n
        rows.append(row)
        print(f"{tid:45} {row['label']}" + (f"  ({row['count']})" if "count" in row else ""))

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2)
    print(f"\nWrote {len(rows)} entity types to {args.out}")


if __name__ == "__main__":
    main()
