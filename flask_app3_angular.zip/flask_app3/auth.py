"""
Active Directory access control.

Only members of AD_REQUIRED_GROUP (default: Dynatrace_Users) can use the site.
Nested membership is honoured (a user in a group that is itself a member of
Dynatrace_Users is allowed), using AD's LDAP_MATCHING_RULE_IN_CHAIN.

The user's own credentials are used to bind, so no service account is needed.

Environment variables
---------------------
AUTH_MODE            "ldap" (default) or "disabled" (local dev only!)
LDAP_SERVER          e.g. ldaps://dc01.chs.local   (ldaps strongly recommended)
LDAP_BASE_DN         e.g. DC=chs,DC=local
LDAP_UPN_SUFFIX      e.g. chs.local   -> users log in as "jdoe", bind as jdoe@chs.local
AD_REQUIRED_GROUP    sAMAccountName / CN of the group (default Dynatrace_Users)
AD_GROUP_DN          optional: full DN of the group, skips the group lookup
LDAP_USE_STARTTLS    "1" to upgrade an ldap:// connection with StartTLS
LDAP_CA_CERT_FILE    optional CA bundle used to validate the DC's certificate
"""
import functools
import logging
import os
import ssl

from flask import jsonify, session

log = logging.getLogger("mw.auth")

AUTH_MODE = os.environ.get("AUTH_MODE", "ldap").strip().lower()
LDAP_SERVER = os.environ.get("LDAP_SERVER", "").strip()
LDAP_BASE_DN = os.environ.get("LDAP_BASE_DN", "").strip()
LDAP_UPN_SUFFIX = os.environ.get("LDAP_UPN_SUFFIX", "").strip().lstrip("@")
AD_REQUIRED_GROUP = os.environ.get("AD_REQUIRED_GROUP", "Dynatrace_Users").strip()
AD_GROUP_DN = os.environ.get("AD_GROUP_DN", "").strip()
LDAP_USE_STARTTLS = os.environ.get("LDAP_USE_STARTTLS", "0") == "1"
LDAP_CA_CERT_FILE = os.environ.get("LDAP_CA_CERT_FILE", "").strip() or None

IN_CHAIN = "1.2.840.113556.1.4.1941"  # LDAP_MATCHING_RULE_IN_CHAIN (nested groups)


class AuthError(Exception):
    """Raised with a user-safe message when login fails."""


def _normalise_username(raw):
    """Accept 'jdoe', 'CHS\\jdoe' or 'jdoe@chs.local'; return (sAMAccountName, bind_name)."""
    raw = (raw or "").strip()
    if "\\" in raw:
        sam = raw.split("\\", 1)[1]
        return sam, raw  # DOMAIN\user bind works against AD
    if "@" in raw:
        return raw.split("@", 1)[0], raw
    bind = f"{raw}@{LDAP_UPN_SUFFIX}" if LDAP_UPN_SUFFIX else raw
    return raw, bind


def ldap_authenticate(username, password):
    """
    Bind to AD as the user and confirm membership of AD_REQUIRED_GROUP.
    Returns {"username", "display_name"} or raises AuthError.
    """
    from ldap3 import ALL, SUBTREE, Connection, Server, Tls
    from ldap3.core.exceptions import LDAPBindError, LDAPException
    from ldap3.utils.conv import escape_filter_chars

    sam, bind_name = _normalise_username(username)
    # AD treats an empty password as an *unauthenticated* bind that succeeds.
    if not sam or not password:
        raise AuthError("Enter your username and password.")
    if not LDAP_SERVER or not LDAP_BASE_DN:
        log.error("LDAP_SERVER / LDAP_BASE_DN are not configured")
        raise AuthError("Sign-in is not configured on this server. Contact the Monitoring team.")

    tls = Tls(validate=ssl.CERT_REQUIRED, ca_certs_file=LDAP_CA_CERT_FILE)
    server = Server(LDAP_SERVER, get_info=ALL, tls=tls, connect_timeout=10)

    conn = None
    try:
        conn = Connection(server, user=bind_name, password=password,
                          auto_bind=False, receive_timeout=15, raise_exceptions=False)
        conn.open()
        if LDAP_USE_STARTTLS and not LDAP_SERVER.lower().startswith("ldaps://"):
            conn.start_tls()
        if not conn.bind():
            raise AuthError("Invalid username or password.")

        group_dn = AD_GROUP_DN
        if not group_dn:
            conn.search(LDAP_BASE_DN,
                        f"(&(objectClass=group)(|(sAMAccountName={escape_filter_chars(AD_REQUIRED_GROUP)})"
                        f"(cn={escape_filter_chars(AD_REQUIRED_GROUP)})))",
                        SUBTREE, attributes=["distinguishedName"], size_limit=1)
            if not conn.entries:
                log.error("AD group %s not found under %s", AD_REQUIRED_GROUP, LDAP_BASE_DN)
                raise AuthError("Access group is not configured correctly. Contact the Monitoring team.")
            group_dn = conn.entries[0].entry_dn

        user_filter = (
            f"(&(objectCategory=person)(objectClass=user)"
            f"(sAMAccountName={escape_filter_chars(sam)})"
            f"(memberOf:{IN_CHAIN}:={escape_filter_chars(group_dn)}))"
        )
        conn.search(LDAP_BASE_DN, user_filter, SUBTREE,
                    attributes=["displayName", "sAMAccountName"], size_limit=1)
        if not conn.entries:
            log.warning("Login denied for %s: not a member of %s", sam, AD_REQUIRED_GROUP)
            raise AuthError(f"Your account is not in the {AD_REQUIRED_GROUP} group. "
                            f"Request access to use this site.")

        entry = conn.entries[0]
        display = str(entry.displayName) if "displayName" in entry and entry.displayName.value else sam
        return {"username": str(entry.sAMAccountName.value or sam), "display_name": display}

    except AuthError:
        raise
    except LDAPBindError:
        raise AuthError("Invalid username or password.")
    except LDAPException as e:
        log.exception("LDAP error during login for %s", sam)
        raise AuthError(f"Could not reach the directory server ({type(e).__name__}). Try again shortly.")
    finally:
        if conn is not None:
            try:
                conn.unbind()
            except Exception:
                pass


def authenticate(username, password):
    if AUTH_MODE == "disabled":
        return {"username": username or "dev", "display_name": (username or "dev") + " (auth disabled)"}
    return ldap_authenticate(username, password)


def current_user():
    if AUTH_MODE == "disabled":
        return session.get("user") or {"username": "dev", "display_name": "dev (auth disabled)"}
    return session.get("user")


def login_required(view):
    """Decorator for API routes: 401 JSON when not signed in (the Angular app then shows the sign-in page)."""
    @functools.wraps(view)
    def wrapper(*args, **kwargs):
        if current_user() is None:
            return jsonify({"error": "Not signed in or session expired."}), 401
        return view(*args, **kwargs)
    return wrapper
