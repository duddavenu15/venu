"""
Submission audit log.

Every create / delete records who did it, the client IP, and the reverse-DNS
(nslookup) name of that IP, along with the Dynatrace objectId of the window.
Records are written as JSON lines so they're easy to grep, ship to Splunk /
Dynatrace log ingest, or read back into the web UI.

Environment variables
---------------------
AUDIT_LOG_PATH       default: <app dir>/logs/mw_audit.jsonl
AUDIT_LOG_MAX_BYTES  rotate after this size (default 10 MB)
AUDIT_LOG_BACKUPS    rotated files to keep (default 10)
DNS_TIMEOUT_SECONDS  reverse lookup timeout (default 3)
"""
import concurrent.futures
import datetime as dt
import json
import logging
import logging.handlers
import os
import socket

_APP_DIR = os.path.dirname(os.path.abspath(__file__))
AUDIT_LOG_PATH = os.environ.get("AUDIT_LOG_PATH", os.path.join(_APP_DIR, "logs", "mw_audit.jsonl"))
AUDIT_LOG_MAX_BYTES = int(os.environ.get("AUDIT_LOG_MAX_BYTES", str(10 * 1024 * 1024)))
AUDIT_LOG_BACKUPS = int(os.environ.get("AUDIT_LOG_BACKUPS", "10"))
DNS_TIMEOUT_SECONDS = float(os.environ.get("DNS_TIMEOUT_SECONDS", "3"))

os.makedirs(os.path.dirname(AUDIT_LOG_PATH), exist_ok=True)

_audit_logger = logging.getLogger("mw.audit")
_audit_logger.setLevel(logging.INFO)
_audit_logger.propagate = False
if not _audit_logger.handlers:
    _h = logging.handlers.RotatingFileHandler(
        AUDIT_LOG_PATH, maxBytes=AUDIT_LOG_MAX_BYTES, backupCount=AUDIT_LOG_BACKUPS, encoding="utf-8"
    )
    _h.setFormatter(logging.Formatter("%(message)s"))
    _audit_logger.addHandler(_h)

_dns_pool = concurrent.futures.ThreadPoolExecutor(max_workers=4, thread_name_prefix="rdns")


def reverse_lookup(ip):
    """
    nslookup-style reverse DNS (PTR) for the submitting IP.
    Returns (hostname or None, note). Never raises, never blocks longer than DNS_TIMEOUT_SECONDS.
    """
    if not ip:
        return None, "no client IP"
    future = _dns_pool.submit(socket.gethostbyaddr, ip)
    try:
        hostname, _aliases, _addrs = future.result(timeout=DNS_TIMEOUT_SECONDS)
        return hostname, "ok"
    except concurrent.futures.TimeoutError:
        return None, f"timeout after {DNS_TIMEOUT_SECONDS:g}s"
    except (socket.herror, socket.gaierror):
        return None, "no PTR record"
    except Exception as e:  # pragma: no cover - defensive
        return None, f"lookup error: {e}"


def write(event, **fields):
    record = {"timestamp": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"), "event": event}
    record.update(fields)
    _audit_logger.info(json.dumps(record, default=str))
    return record


def read_records(limit=1000):
    """Newest-first records across the current and rotated log files."""
    paths = [AUDIT_LOG_PATH] + [f"{AUDIT_LOG_PATH}.{i}" for i in range(1, AUDIT_LOG_BACKUPS + 1)]
    out = []
    for path in paths:
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8") as f:
            lines = f.readlines()
        for line in reversed(lines):
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
            if len(out) >= limit:
                return out
    return out


def index_by_object_id(limit=20000):
    """{objectId: most recent 'create' record} – used to show the submitter on the list page."""
    index = {}
    for rec in read_records(limit=limit):
        if rec.get("event") != "create":
            continue
        for oid in rec.get("object_ids") or []:
            index.setdefault(oid, rec)  # newest first, so first one wins
    return index
