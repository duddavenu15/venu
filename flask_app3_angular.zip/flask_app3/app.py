import json
import logging
import os
import re
import secrets
import urllib.error
import urllib.parse
import urllib.request
from datetime import timedelta

try:  # optional: load a local .env file during development
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))
except ImportError:
    pass

from flask import Flask, abort, jsonify, request, send_from_directory, session
from werkzeug.middleware.proxy_fix import ProxyFix

import audit
import auth
from auth import AuthError, current_user, login_required

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("mw.app")

app = Flask(__name__)
app.json.sort_keys = False  # keep payload keys in the order Dynatrace documents them

# -----------------------------------------------------------------------------
# App / session configuration
# -----------------------------------------------------------------------------
_secret = os.environ.get("SECRET_KEY")
if not _secret:
    _secret = secrets.token_hex(32)
    log.warning("SECRET_KEY not set - using a random key; users will be signed out on every restart "
                "and sessions won't work across multiple worker processes.")
app.config.update(
    SECRET_KEY=_secret,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("SESSION_COOKIE_SECURE", "0") == "1",  # set 1 when served over HTTPS
    PERMANENT_SESSION_LIFETIME=timedelta(hours=int(os.environ.get("SESSION_HOURS", "8"))),
)

# If the app sits behind IIS / nginx / a load balancer, set TRUST_PROXY_HOPS=1 so
# request.remote_addr is the real client IP (from X-Forwarded-For) rather than the proxy's.
_proxy_hops = int(os.environ.get("TRUST_PROXY_HOPS", "0"))
if _proxy_hops > 0:
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=_proxy_hops, x_proto=_proxy_hops, x_host=_proxy_hops)

if auth.AUTH_MODE == "disabled":
    log.warning("AUTH_MODE=disabled - the AD group check is OFF. Never run like this in production.")

# -----------------------------------------------------------------------------
# Dynatrace configuration
# -----------------------------------------------------------------------------
DYNATRACE_BASE_URL = os.environ.get("DYNATRACE_BASE_URL", "https://vwh15794.live.dynatrace.com").rstrip("/")
DYNATRACE_API_TOKEN = os.environ.get("DYNATRACE_API_TOKEN", "")

SETTINGS_OBJECTS_URL = f"{DYNATRACE_BASE_URL}/api/v2/settings/objects"
ENTITIES_URL = f"{DYNATRACE_BASE_URL}/api/v2/entities"
SCHEMA_ID = "builtin:alerting.maintenance-window"

LIST_PAGE_SIZE = int(os.environ.get("LIST_PAGE_SIZE", "500"))
LIST_MAX_PAGES = int(os.environ.get("LIST_MAX_PAGES", "200"))  # safety stop for the pagination loop

ENTITY_TYPES_FILE = os.environ.get(
    "ENTITY_TYPES_FILE", os.path.join(os.path.dirname(os.path.abspath(__file__)), "entity_types.json")
)
ENTITY_ID_RE = re.compile(r"^[A-Z][A-Z0-9_]*-[0-9A-F]{16}$")

# Pseudo entity type for the "Custom entity selector (advanced)" scope option
SELECTOR_SCOPE = "ENTITY_SELECTOR"
SELECTOR_MAX_ENTITIES = int(os.environ.get("SELECTOR_MAX_ENTITIES", "500"))

# The Dynatrace team's layout is CST-only. Set FIXED_TIME_ZONE="" to get the time zone dropdown back.
FIXED_TIME_ZONE = os.environ.get("FIXED_TIME_ZONE", "America/Chicago").strip()
TENANT_LABEL = urllib.parse.urlparse(DYNATRACE_BASE_URL).netloc or DYNATRACE_BASE_URL


def load_entity_types():
    """Read entity_types.json fresh each time so an updated dump takes effect without a restart."""
    try:
        with open(ENTITY_TYPES_FILE, encoding="utf-8") as f:
            rows = json.load(f)
        rows = [r for r in rows if isinstance(r, dict) and r.get("type")]
        if rows:
            return rows
    except (OSError, json.JSONDecodeError) as e:
        log.error("Could not read %s: %s", ENTITY_TYPES_FILE, e)
    return [{"type": "HOST", "label": "Host / Node"}]


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------
def parse_checkbox(value):
    return str(value).lower() in ("true", "on", "1", "yes")


def parse_entity_names(raw):
    """Turn the names textarea content into a clean, case-insensitively deduplicated list."""
    if not raw:
        return []
    seen, unique = set(), []
    for line in raw.replace(",", "\n").splitlines():
        name = line.strip()
        if name and name.lower() not in seen:
            seen.add(name.lower())
            unique.append(name)
    return unique


def client_ip():
    return request.remote_addr or ""


def dt_request(url, method="GET", body=None):
    """Wrapper around urllib for Dynatrace API calls. Returns (status, parsed_json)."""
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Authorization": f"Api-Token {DYNATRACE_API_TOKEN}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        raw = resp.read().decode("utf-8", errors="replace").strip()
        return resp.status, (json.loads(raw) if raw else {})


def _selector_quote(value):
    # entitySelector string values: escape backslash and double quote with "~"
    return value.replace("~", "~~").replace('"', '~"')


def resolve_entities(entity_type, names):
    """
    Resolve display names (or raw entity IDs) of the chosen type to Dynatrace entity IDs.
    Returns (resolved, unresolved):
      resolved   = [{"name", "entityId", "displayName"}, ...]   (a name can match >1 entity)
      unresolved = names that matched nothing
    """
    resolved, unresolved = [], []
    for name in names:
        if ENTITY_ID_RE.match(name):
            selector = f'type("{entity_type}"),entityId("{name}")'
        else:
            selector = f'type("{entity_type}"),entityName.equals("{_selector_quote(name)}")'
        params = {"entitySelector": selector, "pageSize": "50", "fields": "+properties.detectedName"}
        url = f"{ENTITIES_URL}?{urllib.parse.urlencode(params)}"
        try:
            _, body = dt_request(url)
            entities = body.get("entities", []) if isinstance(body, dict) else []
        except (urllib.error.HTTPError, urllib.error.URLError, json.JSONDecodeError) as e:
            log.warning("Entity lookup failed for %s %r: %s", entity_type, name, e)
            entities = []
        if not entities:
            unresolved.append(name)
        for ent in entities:
            resolved.append({
                "name": name,
                "entityId": ent.get("entityId"),
                "displayName": ent.get("displayName", name),
            })
    return resolved, unresolved


def _type_from_id(entity_id):
    """HOST_GROUP-0123456789ABCDEF -> HOST_GROUP"""
    return entity_id.rsplit("-", 1)[0] if entity_id and "-" in entity_id else None


def resolve_selector(selector):
    """
    Resolve a free-form entitySelector (e.g. type(HOST),hostGroupName("PROD-WEB") or
    type(HOST),mzName("PROD")) to concrete entities, following nextPageKey.
    The window is created with one filter per entity found *now* - entities that
    appear later are not added automatically.
    Returns (resolved, truncated).
    """
    resolved = []
    params = {"entitySelector": selector, "pageSize": "500"}
    while True:
        _, body = dt_request(f"{ENTITIES_URL}?{urllib.parse.urlencode(params)}")
        body = body if isinstance(body, dict) else {}
        for ent in body.get("entities", []):
            eid = ent.get("entityId")
            resolved.append({"name": ent.get("displayName", eid), "entityId": eid,
                             "displayName": ent.get("displayName", eid),
                             "type": ent.get("type") or _type_from_id(eid)})
            if len(resolved) >= SELECTOR_MAX_ENTITIES:
                return resolved, True
        nxt = body.get("nextPageKey")
        if not nxt:
            return resolved, False
        params = {"nextPageKey": nxt}


def _hms(value):
    """'14:00' -> '14:00:00' (Dynatrace expects seconds)."""
    value = (value or "").strip()
    return f"{value}:00" if re.fullmatch(r"\d{2}:\d{2}", value) else value


def _local_datetime(value):
    """'2026-10-27T14:00' (datetime-local) -> '2026-10-27T14:00:00'."""
    value = (value or "").strip()
    return f"{value}:00" if re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}", value) else value


def build_schedule(form):
    schedule_type = form.get("schedule_type", "ONCE").upper()
    time_zone = FIXED_TIME_ZONE or form.get("time_zone", "America/Chicago")

    if schedule_type == "ONCE":
        return {
            "scheduleType": "ONCE",
            "onceRecurrence": {
                "startTime": _local_datetime(form.get("start_time")),
                "endTime": _local_datetime(form.get("end_time")),
                "timeZone": time_zone,
            },
        }

    time_window = {
        "startTime": _hms(form.get("time_window_start")),
        "endTime": _hms(form.get("time_window_end")),
        "timeZone": time_zone,
    }
    recurrence_range = {
        "scheduleStartDate": form.get("range_start_date", "").strip(),
        "scheduleEndDate": form.get("range_end_date", "").strip(),
    }

    if schedule_type == "DAILY":
        return {"scheduleType": "DAILY",
                "dailyRecurrence": {"timeWindow": time_window, "recurrenceRange": recurrence_range}}
    if schedule_type == "WEEKLY":
        return {"scheduleType": "WEEKLY",
                "weeklyRecurrence": {"dayOfWeek": form.get("day_of_week", "MONDAY").upper(),
                                     "timeWindow": time_window, "recurrenceRange": recurrence_range}}
    if schedule_type == "MONTHLY":
        return {"scheduleType": "MONTHLY",
                "monthlyRecurrence": {"dayOfMonth": int(form.get("day_of_month", "1")),
                                      "timeWindow": time_window, "recurrenceRange": recurrence_range}}
    raise ValueError(f"Unsupported schedule type: {schedule_type}")


def http_error_json(e):
    body = e.read().decode("utf-8", errors="replace").strip()
    try:
        parsed = json.loads(body) if body else {}
    except json.JSONDecodeError:
        parsed = {"raw_response": body}
    return {"error": "Dynatrace API returned an error", "status_code": e.code, "response_body": parsed}


# -----------------------------------------------------------------------------
# CSRF protection for the Angular front end
# Angular's HttpClient reads the XSRF-TOKEN cookie and sends it back in the
# X-XSRF-TOKEN header on POST/PUT/DELETE. We reject state-changing calls without it.
# -----------------------------------------------------------------------------
CSRF_COOKIE = "XSRF-TOKEN"
CSRF_HEADER = "X-XSRF-TOKEN"


def _csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(32)
    return session["csrf"]


@app.before_request
def csrf_protect():
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        sent = request.headers.get(CSRF_HEADER, "")
        expected = session.get("csrf")
        if not expected or not secrets.compare_digest(sent, expected):
            return jsonify({"error": "Security token missing or expired. Reload the page and try again."}), 403


@app.after_request
def set_csrf_cookie(response):
    response.set_cookie(CSRF_COOKIE, _csrf_token(), samesite="Lax",
                        secure=app.config["SESSION_COOKIE_SECURE"], httponly=False)
    return response


def request_data():
    """Accept JSON (Angular) or form posts; normalise values to the strings the builders expect."""
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return request.form
    out = {}
    for k, v in data.items():
        if isinstance(v, bool):
            out[k] = "true" if v else "false"
        elif v is None:
            out[k] = ""
        elif isinstance(v, list):
            out[k] = "\n".join(str(x) for x in v)
        else:
            out[k] = str(v)
    return out


# -----------------------------------------------------------------------------
# API: session / sign in / config
# -----------------------------------------------------------------------------
def _user_json(user):
    return None if not user else {"username": user["username"], "display_name": user["display_name"]}


@app.route("/api/me", methods=["GET"])
def api_me():
    """Called by the Angular app on load: who is signed in (if anyone) + site settings."""
    _csrf_token()
    return jsonify({
        "user": _user_json(current_user()),
        "auth_mode": auth.AUTH_MODE,
        "required_group": auth.AD_REQUIRED_GROUP,
    })


@app.route("/api/login", methods=["POST"])
def api_login():
    data = request_data()
    username = data.get("username", "")
    try:
        user = auth.authenticate(username, data.get("password", ""))
    except AuthError as e:
        audit.write("login_denied", user=username.strip(), client_ip=client_ip(), reason=str(e))
        return jsonify({"error": str(e)}), 401

    session.clear()                 # new session id on sign-in
    session.permanent = True
    session["user"] = user
    _csrf_token()                   # fresh CSRF token for the new session
    audit.write("login", user=user["username"], client_ip=client_ip())
    return jsonify({"user": _user_json(user)})


@app.route("/api/logout", methods=["POST"])
def api_logout():
    session.clear()
    return jsonify({"ok": True})


@app.route("/api/config", methods=["GET"])
@login_required
def api_config():
    return jsonify({
        "tenant_label": TENANT_LABEL,
        "tenant_url": DYNATRACE_BASE_URL,
        "fixed_time_zone": FIXED_TIME_ZONE,
        "selector_scope": SELECTOR_SCOPE,
        "selector_max": SELECTOR_MAX_ENTITIES,
        "entity_types": load_entity_types(),
    })


@app.route("/api/audit", methods=["GET"])
@login_required
def api_audit():
    limit = min(int(request.args.get("limit", "1000")), 5000)
    return jsonify({"records": audit.read_records(limit=limit)})


@app.route("/tutorial-video", methods=["GET"])
@login_required
def tutorial_video():
    """Serve the tutorial video as a download."""
    return send_from_directory(
        os.path.join(app.root_path, "static", "video"),
        "dynatrace_maintenance_windows_tutorial.mp4",
        as_attachment=True,
        download_name="Dynatrace_Maintenance_Windows_Tutorial.mp4",
    )


# -----------------------------------------------------------------------------
# API: preview / create maintenance window
# -----------------------------------------------------------------------------
class RequestRejected(Exception):
    def __init__(self, message, reason, **extra):
        super().__init__(message)
        self.reason, self.extra = reason, extra


def prepare_window(form):
    """
    Validate the form, resolve the scope to entity IDs and build the Settings API payload.
    Shared by Preview JSON and Create so both produce exactly the same thing.
    Returns (payload, meta); raises RequestRejected for user errors.
    """
    entity_type = form.get("entity_type", "HOST").strip().upper()
    name = form.get("name", "").strip()
    names = parse_entity_names(form.get("entity_names", form.get("host_names", "")))
    selector = form.get("entity_selector", "").strip()
    meta = {"window_name": name, "entity_type": entity_type, "entity_names": names,
            "entity_selector": selector or None, "resolved": [], "unresolved": [], "truncated": False}

    if not name:
        raise RequestRejected("Name is required.", "missing name", meta=meta)

    if entity_type == SELECTOR_SCOPE:
        if not selector:
            raise RequestRejected("Enter an entity selector, or pick an entity type instead.", "empty selector", meta=meta)
        meta["resolved"], meta["truncated"] = resolve_selector(selector)
        if not meta["resolved"]:
            raise RequestRejected("The entity selector matched no entities in Dynatrace.", "selector matched nothing", meta=meta)
    else:
        if entity_type not in {t["type"] for t in load_entity_types()}:
            raise RequestRejected(f"Entity type {entity_type} is not in the allowed list.", "entity type not allowed", meta=meta)
        if names:
            meta["resolved"], meta["unresolved"] = resolve_entities(entity_type, names)
            if not meta["resolved"]:
                raise RequestRejected(f"None of the supplied names were found in Dynatrace as {entity_type}.",
                                      "no entities resolved", meta=meta)

    seen, filters = set(), []
    for r in meta["resolved"]:
        eid = r.get("entityId")
        if eid and eid not in seen:
            seen.add(eid)
            filters.append({"entityType": r.get("type") or entity_type, "entityId": eid,
                            "entityTags": [], "managementZones": []})
    meta["entity_ids"] = list(seen)

    general = {
        "name": name,
        "maintenanceType": form.get("maintenance_type", "PLANNED").upper(),
        "suppression": form.get("suppression", "DETECT_PROBLEMS_DONT_ALERT").upper(),
        "disableSyntheticMonitorExecution": parse_checkbox(form.get("disable_synthetic_monitor_execution", "false")),
    }
    description = form.get("description", "").strip()
    if description:
        general["description"] = description

    payload = [{
        "schemaId": SCHEMA_ID,
        "schemaVersion": "2.15",
        "scope": "environment",
        "value": {"enabled": True, "generalProperties": general,
                  "schedule": build_schedule(form), "filters": filters},
    }]
    return payload, meta


def _submitter():
    user = current_user()
    ip = client_ip()
    hostname, dns_note = audit.reverse_lookup(ip)   # the "nslookup" of the submitter
    return {"user": user["username"], "client_ip": ip, "client_hostname": hostname, "dns_lookup": dns_note}


def _meta_for_audit(meta):
    return {k: meta.get(k) for k in ("window_name", "entity_type", "entity_names", "entity_selector")}


@app.route("/api/preview-maintenance-window", methods=["POST"])
@login_required
def preview_maintenance_window():
    """'Generate JSON': build the exact payload Create would send, without sending it."""
    if not DYNATRACE_API_TOKEN:
        return jsonify({"error": "Missing DYNATRACE_API_TOKEN environment variable"}), 500
    try:
        payload, meta = prepare_window(request_data())
        return jsonify({"request_payload": payload, "resolved": meta["resolved"], "unresolved": meta["unresolved"],
                        "truncated": meta["truncated"], "entity_type": meta["entity_type"]}), 200
    except RequestRejected as e:
        m = e.extra.get("meta", {})
        return jsonify({"error": str(e), "unresolved": m.get("unresolved", [])}), 400
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except urllib.error.HTTPError as e:
        return jsonify(http_error_json(e)), e.code
    except urllib.error.URLError as e:
        return jsonify({"error": "Failed to reach Dynatrace API", "details": str(e)}), 502


@app.route("/api/maintenance-windows", methods=["POST"])
@app.route("/create-maintenance-window", methods=["POST"])
@login_required
def create_maintenance_window():
    if not DYNATRACE_API_TOKEN:
        return jsonify({"error": "Missing DYNATRACE_API_TOKEN environment variable"}), 500

    submitter = _submitter()
    form = request_data()
    audit_base = dict(submitter, window_name=form.get("name", "").strip(),
                      entity_type=form.get("entity_type", "").strip().upper())
    try:
        payload, meta = prepare_window(request_data())
        audit_base.update(_meta_for_audit(meta))

        status, parsed = dt_request(SETTINGS_OBJECTS_URL, method="POST", body=payload)
        object_ids = [i.get("objectId") for i in parsed if isinstance(i, dict) and i.get("objectId")] \
            if isinstance(parsed, list) else []

        audit.write("create", **audit_base, object_ids=object_ids, entity_ids=meta["entity_ids"],
                    unresolved=meta["unresolved"], schedule=payload[0]["value"]["schedule"],
                    dynatrace_status=status, tenant=DYNATRACE_BASE_URL)

        return jsonify({
            "status_code": status,
            "object_ids": object_ids,
            "entity_type": meta["entity_type"],
            "resolved": meta["resolved"],
            "unresolved": meta["unresolved"],
            "truncated": meta["truncated"],
            "submitter": submitter,
            "request_payload": payload,
            "dynatrace_response": parsed,
        }), status

    except RequestRejected as e:
        m = e.extra.get("meta", {})
        audit_base.update(_meta_for_audit(m))
        audit.write("create_rejected", **audit_base, unresolved=m.get("unresolved"), reason=e.reason)
        return jsonify({"error": str(e), "unresolved": m.get("unresolved", []), "submitter": submitter}), 400
    except ValueError as e:
        audit.write("create_rejected", **audit_base, reason=str(e))
        return jsonify({"error": str(e)}), 400
    except urllib.error.HTTPError as e:
        err = http_error_json(e)
        audit.write("create_failed", **audit_base, dynatrace_status=e.code, error=err["response_body"])
        return jsonify(dict(err, submitter=submitter)), e.code
    except urllib.error.URLError as e:
        audit.write("create_failed", **audit_base, error=str(e))
        return jsonify({"error": "Failed to reach Dynatrace API", "details": str(e)}), 502
    except Exception as e:
        log.exception("Unexpected error creating maintenance window")
        audit.write("create_failed", **audit_base, error=str(e))
        return jsonify({"error": "Unexpected error", "details": str(e)}), 500


# -----------------------------------------------------------------------------
# API: list / delete maintenance windows
# -----------------------------------------------------------------------------
def fetch_all_maintenance_windows():
    """
    Page through the Settings API until there is no nextPageKey.
    Dynatrace caps each response, so a single call only returns the first page.
    Returns (items, pages_fetched, total_count_reported).
    """
    params = {
        "schemaIds": SCHEMA_ID,
        "scopes": "environment",
        "fields": "objectId,value,summary,created,modified",
        "pageSize": str(LIST_PAGE_SIZE),
    }
    items, pages, total = [], 0, None
    while True:
        _, body = dt_request(f"{SETTINGS_OBJECTS_URL}?{urllib.parse.urlencode(params)}")
        pages += 1
        body = body if isinstance(body, dict) else {}
        items.extend(body.get("items", []))
        total = body.get("totalCount", total)
        next_key = body.get("nextPageKey")
        if not next_key:
            break
        if pages >= LIST_MAX_PAGES:
            log.warning("Stopped paging maintenance windows after %d pages", pages)
            break
        # When nextPageKey is used Dynatrace rejects every other query parameter.
        params = {"nextPageKey": next_key}
    return items, pages, total


@app.route("/api/maintenance-windows", methods=["GET"])
@login_required
def list_maintenance_windows():
    if not DYNATRACE_API_TOKEN:
        return jsonify({"error": "Missing DYNATRACE_API_TOKEN environment variable"}), 500

    try:
        raw_items, pages, total = fetch_all_maintenance_windows()
        submitted = audit.index_by_object_id()

        items = []
        for item in raw_items:
            value = item.get("value", {}) or {}
            general = value.get("generalProperties", {}) or {}
            schedule = value.get("schedule", {}) or {}
            filters = value.get("filters", []) or []
            rec = submitted.get(item.get("objectId"))
            items.append({
                "objectId": item.get("objectId"),
                "name": general.get("name", ""),
                "description": general.get("description", ""),
                "maintenanceType": general.get("maintenanceType", ""),
                "suppression": general.get("suppression", ""),
                "enabled": value.get("enabled", False),
                "scheduleType": schedule.get("scheduleType", ""),
                "schedule": schedule,
                "filters": [{"entityType": f.get("entityType"), "entityId": f.get("entityId")} for f in filters],
                "summary": item.get("summary", ""),
                "created": item.get("created"),
                "modified": item.get("modified"),
                "submittedBy": None if not rec else {
                    "user": rec.get("user"),
                    "client_ip": rec.get("client_ip"),
                    "client_hostname": rec.get("client_hostname"),
                    "timestamp": rec.get("timestamp"),
                    "entity_names": rec.get("entity_names"),
                    "entity_selector": rec.get("entity_selector"),
                },
            })

        items.sort(key=lambda i: (i["name"] or "").lower())
        return jsonify({"status_code": 200, "items": items, "pages_fetched": pages,
                        "total_count": total if total is not None else len(items)}), 200

    except urllib.error.HTTPError as e:
        return jsonify(http_error_json(e)), e.code
    except urllib.error.URLError as e:
        return jsonify({"error": "Failed to reach Dynatrace API", "details": str(e)}), 502
    except Exception as e:
        log.exception("Unexpected error listing maintenance windows")
        return jsonify({"error": "Unexpected error", "details": str(e)}), 500


@app.route("/api/maintenance-windows/<path:object_id>", methods=["DELETE"])
@login_required
def delete_maintenance_window(object_id):
    if not DYNATRACE_API_TOKEN:
        return jsonify({"error": "Missing DYNATRACE_API_TOKEN environment variable"}), 500

    ip = client_ip()
    hostname, dns_note = audit.reverse_lookup(ip)
    audit_base = {"user": current_user()["username"], "client_ip": ip, "client_hostname": hostname,
                  "dns_lookup": dns_note, "object_ids": [object_id],
                  "window_name": request.args.get("name", "")}
    try:
        url = f"{SETTINGS_OBJECTS_URL}/{urllib.parse.quote(object_id, safe='')}"
        status, _ = dt_request(url, method="DELETE")
        audit.write("delete", **audit_base, dynatrace_status=status)
        return jsonify({"status_code": status, "objectId": object_id}), status
    except urllib.error.HTTPError as e:
        err = http_error_json(e)
        audit.write("delete_failed", **audit_base, dynatrace_status=e.code)
        return jsonify(err), e.code
    except urllib.error.URLError as e:
        return jsonify({"error": "Failed to reach Dynatrace API", "details": str(e)}), 502
    except Exception as e:
        return jsonify({"error": "Unexpected error", "details": str(e)}), 500


# -----------------------------------------------------------------------------
# Angular front end
# The built app (frontend/dist/mw-ui/browser) is served from "/". Any path that
# isn't an API route or a real file gets index.html so Angular's router handles it.
# -----------------------------------------------------------------------------
FRONTEND_DIST = os.environ.get(
    "FRONTEND_DIST",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "frontend", "dist", "mw-ui", "browser"),
)


@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def angular_app(path):
    if path.startswith("api/"):
        return jsonify({"error": "Not found"}), 404
    index = os.path.join(FRONTEND_DIST, "index.html")
    if not os.path.exists(index):
        return ("Front end not built. Run: cd frontend && npm install && npm run build", 503)
    if path and os.path.isfile(os.path.join(FRONTEND_DIST, path)):
        return send_from_directory(FRONTEND_DIST, path)
    if "." in path.rsplit("/", 1)[-1]:
        abort(404)  # a missing asset, not an app route
    response = send_from_directory(FRONTEND_DIST, "index.html")
    response.headers["Cache-Control"] = "no-cache"
    return response


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=os.environ.get("FLASK_DEBUG", "0") == "1")
