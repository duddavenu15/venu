# mw-ui (Angular front end)

See the main `README.md` one folder up for how to run, build and deploy.

- `npm start` – dev server on http://localhost:4200 (proxies API calls to Flask on :5000)
- `npm run build` – production build to `dist/mw-ui/browser`, served by Flask
