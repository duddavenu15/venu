import { Component, computed, inject, signal } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ApiService } from '../../core/api.service';
import { errorText } from '../../core/clipboard';
import { AuditRecord } from '../../core/models';

@Component({
  selector: 'app-audit',
  template: `
    <h2 class="page-title">Submission Log</h2>
    <p class="intro-text">
      Every push, delete and sign-in through this site, with the submitting IP address and its
      reverse-DNS (nslookup) name. Newest first.
    </p>

    <div class="list-toolbar">
      <button type="button" class="btn-secondary" (click)="load()" [disabled]="loading()">Refresh</button>
      <input type="search" class="filter-input" placeholder="Filter by window, user, IP, host…"
             [value]="filter()" (input)="filter.set($any($event.target).value)">
      <span class="count-label">{{ countText() }}</span>
    </div>

    @if (loading()) {
      <p>Loading…</p>
    } @else if (error()) {
      <p class="result-panel result-error">{{ error() }}</p>
    } @else if (!records().length) {
      <p class="intro-text">Nothing logged yet.</p>
    } @else {
      <table class="mw-table">
        <thead>
          <tr>
            <th>When (UTC)</th>
            <th>Event</th>
            <th>User</th>
            <th>Client IP</th>
            <th>Resolved host name</th>
            <th>Window</th>
            <th>Targets</th>
            <th>Object ID</th>
          </tr>
        </thead>
        <tbody>
          @for (r of filtered(); track $index) {
            <tr>
              <td class="nowrap">{{ (r.timestamp || '').slice(0, 19).replace('T', ' ') }}</td>
              <td><span class="event-tag" [class]="'event-tag event-tag-' + r.event">{{ r.event.replaceAll('_', ' ') }}</span></td>
              <td>{{ r.user }}</td>
              <td>{{ r.client_ip }}</td>
              <td>
                @if (r.client_hostname) { {{ r.client_hostname }} }
                @else if (r.dns_lookup) { <span class="muted">{{ r.dns_lookup }}</span> }
              </td>
              <td>
                {{ r.window_name }}
                @if (r.reason) { <br><span class="muted">{{ r.reason }}</span> }
              </td>
              <td>
                {{ r.entity_type }}
                @if (r.entity_selector) { <br><span class="mono">{{ r.entity_selector }}</span> }
                @if (r.entity_names?.length) { <br><span class="muted">{{ r.entity_names!.join(', ') }}</span> }
                @if (r.unresolved?.length) { <br><span class="muted">unresolved: {{ r.unresolved!.join(', ') }}</span> }
              </td>
              <td class="mono">{{ (r.object_ids || []).join(', ') }}</td>
            </tr>
          }
        </tbody>
      </table>
    }
  `,
})
export class AuditPage {
  private api = inject(ApiService);

  protected records = signal<AuditRecord[]>([]);
  protected loading = signal(false);
  protected error = signal<string | null>(null);
  protected filter = signal('');

  protected filtered = computed(() => {
    const q = this.filter().trim().toLowerCase();
    if (!q) return this.records();
    return this.records().filter((r) => JSON.stringify(r).toLowerCase().includes(q));
  });

  protected countText = computed(() => {
    const all = this.records().length;
    return this.filter().trim() ? `${this.filtered().length} of ${all} entries` : `${all} entries`;
  });

  constructor() {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.error.set(null);
    this.api.audit().subscribe({
      next: (d) => {
        this.records.set(d.records || []);
        this.loading.set(false);
      },
      error: (e: HttpErrorResponse) => {
        if (e.status !== 401) this.error.set(errorText(e.status, e.error));
        this.loading.set(false);
      },
    });
  }
}
