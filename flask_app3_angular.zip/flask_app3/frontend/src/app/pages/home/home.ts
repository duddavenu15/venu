import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-home',
  imports: [RouterLink],
  template: `
    <section class="home-hero">
      <div>
        <p class="home-eyebrow">CHS Monitoring</p>
        <h2 class="home-title">Welcome{{ firstName() ? ', ' + firstName() : '' }}</h2>
        <p class="home-lede">Create and manage Dynatrace maintenance windows so planned work doesn't trigger alerts.</p>
      </div>
    </section>

    <div class="home-grid">
      <a routerLink="/create" class="home-card">
        <span class="home-icon hi-green">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M8 2v4M16 2v4M3 9h18"/><path d="M12 12v6M9 15h6"/></svg>
        </span>
        <b>Create a maintenance window</b>
        <span>Pick the servers, set the schedule, push to Dynatrace.</span>
      </a>
      <a routerLink="/list" class="home-card">
        <span class="home-icon hi-teal">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6h12M9 12h12M9 18h12"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/></svg>
        </span>
        <b>See all windows</b>
        <span>Every window in Dynatrace, who created it, and delete.</span>
      </a>
      <a routerLink="/audit" class="home-card">
        <span class="home-icon hi-amber">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/><path d="M8 13h8M8 17h5"/></svg>
        </span>
        <b>Submission Log</b>
        <span>Who did what, from which IP and PC.</span>
      </a>
    </div>

    <section class="home-guide">
      <span class="home-icon hi-purple">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5V5a2 2 0 0 1 2-2h13v16H6.5A2.5 2.5 0 0 0 4 21.5v-2z"/><path d="M8 7h7M8 11h5"/></svg>
      </span>
      <div class="home-guide-text">
        <b>New to the site? Start with the User Guide.</b>
        <span>Step-by-step pictures of every page, what each field and button does, and quick fixes for common problems.</span>
      </div>
      <div class="home-guide-actions">
        <a routerLink="/guide" class="btn-primary">Open User Guide</a>
        <a href="guide/CHS-Maintenance-Window-User-Guide.pdf" download class="btn-secondary">Download PDF</a>
      </div>
    </section>

    <p class="intro-text home-video">
      Prefer video? <a href="/tutorial-video">Download the tutorial</a> on creating host-based maintenance windows.
    </p>
  `,
})
export class HomePage {
  private auth = inject(AuthService);
  protected firstName = () => (this.auth.user()?.display_name || '').split(' ')[0].replace(/[()]/g, '');
}
