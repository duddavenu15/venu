import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
    <h2 class="page-title">Welcome to the CHS Monitoring Team's Home Page</h2>
    <p class="intro-text">
      Please <a href="/tutorial-video">click here</a>
      for a tutorial on how to create host based maintenance windows in Dynatrace.
    </p>
  `,
})
export class HomePage {}
