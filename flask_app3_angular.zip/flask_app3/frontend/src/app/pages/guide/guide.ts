import { Component, HostListener, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';

/**
 * User guide for the site. Static content with annotated screenshots
 * (public/guide/*.png) and a PDF copy (public/guide/CHS-Maintenance-Window-User-Guide.pdf).
 * Open to everyone, including people who can't sign in yet.
 */
@Component({
  selector: 'app-guide',
  imports: [RouterLink],
  templateUrl: './guide.html',
  styleUrl: './guide.css',
})
export class GuidePage {
  protected auth = inject(AuthService);
  protected readonly pdf = 'guide/CHS-Maintenance-Window-User-Guide.pdf';

  protected readonly sections = [
    { id: 'overview', label: 'How it works' },
    { id: 'signin', label: 'Signing in' },
    { id: 'layout', label: 'Finding your way' },
    { id: 'create', label: 'Create a window' },
    { id: 'buttons', label: 'The four buttons' },
    { id: 'list', label: 'List all windows' },
    { id: 'log', label: 'Submission Log' },
    { id: 'faq', label: 'Questions & fixes' },
  ];

  scrollTo(id: string, event: Event): void {
    event.preventDefault();
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  print(): void {
    window.print();
  }

  /** Expand all collapsible sections so they appear on paper / in the PDF. */
  @HostListener('window:beforeprint')
  expandAll(): void {
    document.querySelectorAll('.guide details').forEach((d) => d.setAttribute('open', ''));
  }
}
