import { Component, computed, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { HttpErrorResponse } from '@angular/common/http';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';
import { ApiService } from '../../core/api.service';
import { copyText, errorText } from '../../core/clipboard';
import { PreviewResponse, ScheduleType, SiteConfig, WindowForm } from '../../core/models';

type ResultKind = 'pending' | 'success' | 'error';

const DAYS = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];
const TIME_ZONES = ['America/Chicago', 'America/New_York', 'America/Denver', 'America/Los_Angeles', 'US/Central', 'UTC'];

function isoDate(d: Date): string {
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}

@Component({
  selector: 'app-create',
  imports: [ReactiveFormsModule],
  templateUrl: './create.html',
})
export class CreatePage {
  private api = inject(ApiService);
  private fb = inject(FormBuilder).nonNullable;

  protected readonly days = DAYS;
  protected readonly timeZones = TIME_ZONES;

  protected config = signal<SiteConfig | null>(null);
  protected configError = signal<string | null>(null);

  protected form = this.fb.group({
    name: '',
    description: '',
    maintenance_type: 'PLANNED',
    suppression: 'DETECT_PROBLEMS_DONT_ALERT',
    disable_synthetic_monitor_execution: false,
    schedule_type: 'MONTHLY' as ScheduleType,
    time_zone: 'America/Chicago',
    start_time: '',
    end_time: '',
    time_window_start: '02:00',
    time_window_end: '04:00',
    day_of_week: 'WEDNESDAY',
    day_of_month: 1,
    range_start_date: isoDate(new Date()),
    range_end_date: '2030-12-31',
    entity_type: 'HOST',
    entity_names: '',
    entity_selector: '',
  });

  private value = toSignal(this.form.valueChanges, { initialValue: this.form.getRawValue() });
  protected scheduleType = computed(() => this.value().schedule_type);
  protected isCustomSelector = computed(
    () => !!this.config() && this.value().entity_type === this.config()!.selector_scope,
  );
  protected namesLabel = computed(() => {
    const t = this.config()?.entity_types.find((e) => e.type === this.value().entity_type);
    return (t?.label ?? 'Entity') + ' names:';
  });
  protected tzShort = computed(() => (this.config()?.fixed_time_zone === 'America/Chicago' ? 'CST' : ''));

  protected result = signal<{ kind: ResultKind; text: string } | null>(null);
  protected json = signal<{ title: string; text: string } | null>(null);
  protected busy = signal(false);
  protected copyLabel = signal('Copy JSON');
  /** True only after Generate JSON (or a push) produced JSON for the form as it is now. */
  protected jsonReady = signal(false);
  /** Required fields that were empty when a button was clicked (outlined in red). */
  protected missing = signal<string[]>([]);

  protected reloadingTypes = signal(false);
  protected typesStatus = computed(() => {
    const c = this.config();
    if (!c) return '';
    const n = c.entity_types.length;
    if (c.entity_types_source === 'dynatrace') {
      return `${n} entity types loaded from Dynatrace` + (c.entity_types_loaded_at ? ` at ${c.entity_types_loaded_at.slice(11, 16)} UTC` : '');
    }
    return c.entity_types_error
      ? `Couldn't load entity types from Dynatrace (${c.entity_types_error}). Showing the saved list.`
      : 'Showing the saved entity type list.';
  });

  constructor() {
    this.loadConfig(false);
    this.form.valueChanges.subscribe(() => {
      this.jsonReady.set(false);                       // form changed: JSON is out of date
      this.copyLabel.set('Copy JSON');
      if (this.missing().length) this.missing.set(this.missingFields());
    });
  }

  private loadConfig(reload: boolean): void {
    if (reload) this.reloadingTypes.set(true);
    this.api.config(reload).subscribe({
      next: (c) => {
        this.config.set(c);
        this.configError.set(null);
        if (c.fixed_time_zone) this.form.controls.time_zone.setValue(c.fixed_time_zone);
        // keep the current choice if it still exists, otherwise fall back to the first type
        const current = this.form.controls.entity_type.value;
        const ok = current === c.selector_scope || c.entity_types.some((t) => t.type === current);
        if (!ok && c.entity_types.length) this.form.controls.entity_type.setValue(c.entity_types[0].type);
        this.reloadingTypes.set(false);
      },
      error: (e: HttpErrorResponse) => {
        this.configError.set(errorText(e.status, e.error));
        this.reloadingTypes.set(false);
      },
    });
  }

  reloadEntityTypes(): void {
    this.loadConfig(true);
  }

  // ---- validation --------------------------------------------------------
  private static readonly LABELS: Record<string, string> = {
    name: 'Name',
    start_time: 'Start Time',
    end_time: 'End Time',
    time_window_start: 'Start Time',
    time_window_end: 'End Time',
    range_start_date: 'Range Start Date',
    range_end_date: 'Range End Date',
    day_of_month: 'Day of Month',
    entity_selector: 'Entity Selector',
  };

  /** Required fields that are currently empty. */
  private missingFields(): string[] {
    const v = this.form.getRawValue();
    const need = ['name'].concat(
      v.schedule_type === 'ONCE'
        ? ['start_time', 'end_time']
        : ['time_window_start', 'time_window_end', 'range_start_date', 'range_end_date'],
    );
    if (v.schedule_type === 'MONTHLY') need.push('day_of_month');
    if (this.isCustomSelector()) need.push('entity_selector');
    return need.filter((k) => {
      const val = (v as any)[k];
      return val === null || val === undefined || !String(val).trim();
    });
  }

  protected isMissing(field: string): boolean {
    return this.missing().includes(field);
  }

  /**
   * Check the form before a button does anything.
   * Empty required fields -> "Please fill in the form before clicking ..." + red outlines.
   */
  private checkForm(buttonName: string): boolean {
    const missing = this.missingFields();
    this.missing.set(missing);
    if (missing.length) {
      const labels = missing.map((k) => CreatePage.LABELS[k] ?? k);
      this.result.set({
        kind: 'error',
        text: `Please fill in the form before clicking "${buttonName}".\n\nRequired: ${labels.join(', ')}`,
      });
      setTimeout(() => document.getElementById(missing[0])?.focus());
      return false;
    }
    const v = this.form.getRawValue();
    let problem: string | null = null;
    if (v.schedule_type !== 'ONCE' && v.range_end_date < v.range_start_date) {
      problem = 'Range End Date must be on or after Range Start Date.';
    } else if (v.schedule_type === 'ONCE' && v.end_time <= v.start_time) {
      problem = 'End Time must be after Start Time.';
    } else if (v.schedule_type === 'MONTHLY' && !(v.day_of_month >= 1 && v.day_of_month <= 31)) {
      problem = 'Day of Month must be between 1 and 31.';
    }
    if (problem) {
      this.result.set({ kind: 'error', text: problem });
      return false;
    }
    return true;
  }

  private payload(): WindowForm {
    return this.form.getRawValue() as WindowForm;
  }

  private resolvedText(data: PreviewResponse): string {
    let t = '';
    if (data.unresolved?.length) {
      t += `\n\nUnresolved names (not found as ${data.entity_type}):\n - ` + data.unresolved.join('\n - ');
    }
    if (data.resolved?.length) {
      const list = data.resolved.slice(0, 25).map((h) => `${h.displayName} (${h.entityId})`);
      t += `\n\nMatched ${data.resolved.length} entit${data.resolved.length === 1 ? 'y' : 'ies'}:\n - ` + list.join('\n - ');
      if (data.resolved.length > 25) t += `\n - ... and ${data.resolved.length - 25} more`;
    } else {
      t += '\n\nNo entities selected: this window applies to the ENTIRE environment.';
    }
    if (data.truncated) {
      t += '\n\nWARNING: the selector matched more entities than the limit; only the first ones were included.';
    }
    return t;
  }

  private showJson(title: string, obj: unknown): void {
    this.json.set({ title, text: JSON.stringify(obj, null, 2) });
    this.jsonReady.set(true);
  }

  // ---- Generate JSON ------------------------------------------------------
  async generate(): Promise<boolean> {
    if (!this.checkForm('Generate JSON')) return false;
    this.result.set({ kind: 'pending', text: 'Resolving entities and building payload...' });
    try {
      const data = await firstValueFrom(this.api.preview(this.payload()));
      this.result.set({
        kind: 'pending',
        text: 'Preview only - nothing has been sent to Dynatrace yet.' + this.resolvedText(data),
      });
      this.showJson('Request payload (preview)', data.request_payload);
      return true;
    } catch (e) {
      const err = e as HttpErrorResponse;
      if (err.status !== 401) this.result.set({ kind: 'error', text: errorText(err.status, err.error) });
      return false;
    }
  }

  // ---- Copy JSON ----------------------------------------------------------
  async copyJson(): Promise<void> {
    // The button is greyed out until Generate JSON has run for the current form.
    if (!this.jsonReady() || !this.json()) {
      this.result.set({ kind: 'error', text: 'Please fill in the form and click "Generate JSON" before copying.' });
      return;
    }
    const ok = await copyText(this.json()!.text);
    this.flashCopy(ok ? 'Copied!' : 'Select the JSON and press Ctrl+C');
  }

  private copyTimer?: ReturnType<typeof setTimeout>;
  private flashCopy(text: string): void {
    this.copyLabel.set(text);
    clearTimeout(this.copyTimer);
    this.copyTimer = setTimeout(() => this.copyLabel.set('Copy JSON'), 2000);
  }

  // ---- Clear --------------------------------------------------------------
  clear(): void {
    const c = this.config();
    this.form.reset();
    this.form.patchValue({
      range_start_date: isoDate(new Date()),
      time_zone: c?.fixed_time_zone || 'America/Chicago',
    });
    this.result.set(null);
    this.json.set(null);
    this.jsonReady.set(false);
    this.missing.set([]);
  }

  // ---- Push to Dynatrace ---------------------------------------------------
  async push(): Promise<void> {
    if (!this.checkForm('Push to Dynatrace')) return;
    if (
      !this.isCustomSelector() &&
      !this.form.controls.entity_names.value.trim() &&
      !confirm('No entity names entered - this window will apply to the ENTIRE environment. Continue?')
    ) {
      return;
    }
    this.busy.set(true);
    this.result.set({ kind: 'pending', text: 'Pushing to tenant...' });
    try {
      const data = await firstValueFrom(this.api.create(this.payload()));
      let message = 'Success! Maintenance window pushed to Dynatrace.';
      if (data.object_ids?.length) message += '\nObject ID: ' + data.object_ids.join(', ');
      if (data.submitter) {
        const s = data.submitter;
        message +=
          `\n\nLogged as submitted by ${s.user} from ${s.client_ip}` +
          (s.client_hostname ? ` (${s.client_hostname})` : ` (reverse DNS: ${s.dns_lookup})`);
      }
      this.result.set({ kind: 'success', text: message + this.resolvedText(data) });
      this.showJson('Payload sent to Dynatrace', data.request_payload);
    } catch (e) {
      const err = e as HttpErrorResponse;
      if (err.status !== 401) {
        this.result.set({ kind: 'error', text: errorText(err.status, err.error) });
        if (err.error?.response_body) this.showJson('Dynatrace error response', err.error.response_body);
      }
    } finally {
      this.busy.set(false);
    }
  }
}
