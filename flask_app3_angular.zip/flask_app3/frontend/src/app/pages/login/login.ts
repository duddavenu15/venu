import { Component, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  template: `
    <h2 class="page-title">Sign in</h2>
    <p class="intro-text">
      Use your CHS network account. Access is limited to members of the
      <strong>{{ auth.requiredGroup() }}</strong> AD group.
    </p>

    @if (expired() && !error()) {
      <div class="result-panel result-pending login-error">Your session expired. Please sign in again.</div>
    }
    @if (error()) {
      <div class="result-panel result-error login-error">{{ error() }}</div>
    }

    <form class="login-form" (ngSubmit)="submit()">
      <fieldset class="card">
        <div class="field login-field">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" [(ngModel)]="username"
                 autocomplete="username" placeholder="jdoe or CHS\\jdoe" required autofocus>
        </div>
        <div class="field login-field">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" [(ngModel)]="password"
                 autocomplete="current-password" required>
        </div>
        <div class="actions">
          <button type="submit" class="btn-primary" [disabled]="busy()">
            {{ busy() ? 'Signing in…' : 'Sign in' }}
          </button>
        </div>
      </fieldset>
    </form>
  `,
})
export class LoginPage {
  protected auth = inject(AuthService);
  private router = inject(Router);

  /** Bound from the ?next= and ?expired= query params. */
  next = input<string>('');
  expired = input<string>('');

  username = '';
  password = '';
  busy = signal(false);
  error = signal<string | null>(null);

  async submit(): Promise<void> {
    if (!this.username.trim() || !this.password) {
      this.error.set('Enter your username and password.');
      return;
    }
    this.busy.set(true);
    this.error.set(null);
    try {
      await this.auth.login(this.username.trim(), this.password);
      const next = this.next();
      const safe = next && next.startsWith('/') && !next.startsWith('//') && !next.startsWith('/login') ? next : '/';
      this.router.navigateByUrl(safe);
    } catch (e) {
      const err = e as HttpErrorResponse;
      this.error.set(err.error?.error || (err.status === 0 ? 'Could not reach the server.' : 'Sign-in failed.'));
      this.password = '';
    } finally {
      this.busy.set(false);
    }
  }
}
