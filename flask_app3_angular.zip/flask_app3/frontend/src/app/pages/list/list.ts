import { Component, computed, inject, signal } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { ApiService } from '../../core/api.service';
import { errorText } from '../../core/clipboard';
import { MaintenanceWindow } from '../../core/models';

interface Row extends MaintenanceWindow {
  scheduleText: string;
  rangeText: string;
  targetsMain: string;
  targetsSub: string;
  targetsMono: boolean;
}

/** Handles the current Dynatrace shape (timeWindow + recurrenceRange) and the older flat one. */
function windowText(r: any): { time: string; range: string } {
  const tw = r?.timeWindow || r || {};
  const range = r?.recurrenceRange
    ? `${r.recurrenceRange.scheduleStartDate} → ${r.recurrenceRange.scheduleEndDate}`
    : '';
  return { time: `${tw.startTime ?? ''}–${tw.endTime ?? ''} (${tw.timeZone ?? ''})`, range };
}

function describeSchedule(type: string, s: any): { text: string; range: string } {
  if (!s) return { text: type || '', range: '' };
  switch (type) {
    case 'ONCE': {
      const o = s.onceRecurrence || {};
      return { text: `Once: ${o.startTime ?? ''} → ${o.endTime ?? ''} (${o.timeZone ?? ''})`, range: '' };
    }
    case 'DAILY': {
      const w = windowText(s.dailyRecurrence);
      return { text: `Daily ${w.time}`, range: w.range };
    }
    case 'WEEKLY': {
      const r = s.weeklyRecurrence || {};
      const w = windowText(r);
      return { text: `Weekly on ${r.dayOfWeek ?? ''} ${w.time}`, range: w.range };
    }
    case 'MONTHLY': {
      const r = s.monthlyRecurrence || {};
      const w = windowText(r);
      return { text: `Monthly on day ${r.dayOfMonth ?? ''} ${w.time}`, range: w.range };
    }
    default:
      return { text: type || '', range: '' };
  }
}

function describeTargets(item: MaintenanceWindow): { main: string; sub: string; mono: boolean } {
  const f = item.filters || [];
  if (!f.length) return { main: 'Entire environment', sub: '', mono: false };
  const sb = item.submittedBy;
  if (sb?.entity_selector) {
    return { main: sb.entity_selector, sub: `${f.length} entit${f.length === 1 ? 'y' : 'ies'}`, mono: true };
  }
  if (sb?.entity_names?.length) {
    const shown = sb.entity_names.slice(0, 5).join(', ');
    const more = sb.entity_names.length > 5 ? ` +${sb.entity_names.length - 5} more` : '';
    return { main: f[0].entityType || '', sub: shown + more, mono: false };
  }
  const types = [...new Set(f.map((x) => x.entityType || 'tag/MZ filter'))].join(', ');
  return { main: types, sub: `${f.length} filter${f.length === 1 ? '' : 's'}`, mono: false };
}

@Component({
  selector: 'app-list',
  templateUrl: './list.html',
})
export class ListPage {
  private api = inject(ApiService);

  protected rows = signal<Row[]>([]);
  protected pagesFetched = signal(0);
  protected loading = signal(false);
  protected error = signal<string | null>(null);
  protected filter = signal('');
  protected deleting = signal<string | null>(null);

  protected filtered = computed(() => {
    const q = this.filter().trim().toLowerCase();
    if (!q) return this.rows();
    return this.rows().filter((i) => {
      const sb = i.submittedBy;
      return [i.name, i.description, i.scheduleType, i.maintenanceType, sb?.user, sb?.client_ip,
        sb?.client_hostname, sb?.entity_selector, (sb?.entity_names || []).join(' ')]
        .some((v) => v && String(v).toLowerCase().includes(q));
    });
  });

  protected countText = computed(() => {
    const all = this.rows().length;
    const p = this.pagesFetched();
    const pages = `loaded in ${p} request${p === 1 ? '' : 's'}`;
    return this.filter().trim()
      ? `${this.filtered().length} of ${all} windows (${pages})`
      : `${all} window${all === 1 ? '' : 's'} (${pages})`;
  });

  constructor() {
    this.load();
  }

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    try {
      const data = await firstValueFrom(this.api.list());
      this.rows.set(
        (data.items || []).map((i) => {
          const s = describeSchedule(i.scheduleType, i.schedule);
          const t = describeTargets(i);
          return { ...i, scheduleText: s.text, rangeText: s.range, targetsMain: t.main, targetsSub: t.sub, targetsMono: t.mono };
        }),
      );
      this.pagesFetched.set(data.pages_fetched || 1);
    } catch (e) {
      const err = e as HttpErrorResponse;
      if (err.status !== 401) this.error.set('Failed to load: ' + errorText(err.status, err.error));
    } finally {
      this.loading.set(false);
    }
  }

  async remove(item: Row): Promise<void> {
    const name = item.name || '(unnamed)';
    if (!confirm(`Delete maintenance window "${name}"?`)) return;
    this.deleting.set(item.objectId);
    try {
      await firstValueFrom(this.api.delete(item.objectId, name));
      await this.load();
    } catch (e) {
      const err = e as HttpErrorResponse;
      if (err.status !== 401) alert('Delete failed: ' + errorText(err.status, err.error));
    } finally {
      this.deleting.set(null);
    }
  }

  protected when(ts: string | undefined): string {
    return (ts || '').replace('T', ' ').replace('+00:00', ' UTC');
  }
}
