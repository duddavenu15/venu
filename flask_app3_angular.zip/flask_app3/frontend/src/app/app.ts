import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from './core/auth.service';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './app.html',
})
export class App {
  protected auth = inject(AuthService);
  private router = inject(Router);
  protected readonly year = new Date().getFullYear();

  constructor() {
    this.auth.load();
  }

  async signOut(): Promise<void> {
    await this.auth.logout();
    this.router.navigate(['/login']);
  }
}
