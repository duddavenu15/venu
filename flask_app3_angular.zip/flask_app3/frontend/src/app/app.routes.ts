import { Routes } from '@angular/router';
import { authGuard, loginPageGuard } from './core/auth.guard';

export const routes: Routes = [
  {
    path: 'login',
    title: 'Sign in – CHS Monitoring',
    canActivate: [loginPageGuard],
    loadComponent: () => import('./pages/login/login').then((m) => m.LoginPage),
  },
  {
    path: '',
    canActivate: [authGuard],
    children: [
      {
        path: '',
        pathMatch: 'full',
        title: 'CHS Monitoring – Home',
        loadComponent: () => import('./pages/home/home').then((m) => m.HomePage),
      },
      {
        path: 'create',
        title: 'Create Maintenance Window',
        loadComponent: () => import('./pages/create/create').then((m) => m.CreatePage),
      },
      {
        path: 'list',
        title: 'List All Maintenance Windows',
        loadComponent: () => import('./pages/list/list').then((m) => m.ListPage),
      },
      {
        path: 'audit',
        title: 'Submission Log',
        loadComponent: () => import('./pages/audit/audit').then((m) => m.AuditPage),
      },
    ],
  },
  { path: '**', redirectTo: '' },
];
