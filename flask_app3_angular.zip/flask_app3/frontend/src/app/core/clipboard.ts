/**
 * Copy text to the clipboard.
 * navigator.clipboard only exists on HTTPS or localhost. On http://servername we
 * fall back to execCommand('copy'), which still works over plain HTTP.
 */
export async function copyText(text: string): Promise<boolean> {
  if (navigator.clipboard && window.isSecureContext) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      /* fall through */
    }
  }
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.setAttribute('readonly', '');
  ta.style.position = 'fixed';
  ta.style.top = '-1000px';
  document.body.appendChild(ta);
  ta.select();
  let ok = false;
  try {
    ok = document.execCommand('copy');
  } catch {
    ok = false;
  }
  document.body.removeChild(ta);
  return ok;
}

/** Turn an HttpErrorResponse body from Flask into readable text. */
export function errorText(status: number, body: any): string {
  if (status === 0) return 'Could not reach the server.';
  const msg = body && typeof body.error === 'string' ? body.error : 'Request failed';
  const dt = body?.response_body?.error?.message;
  let text = `Error ${status}: ${msg}` + (dt ? `\n${dt}` : '');
  if (body?.details) text += `\n${body.details}`;
  if (body?.unresolved?.length) {
    text += '\n\nNot found in Dynatrace:\n - ' + body.unresolved.join('\n - ');
  }
  return text;
}
