import { HttpClient } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { MeResponse, User } from './models';

/**
 * Holds who is signed in. Sign-in itself happens on the Flask side, which binds
 * to AD and checks the Dynatrace_Users group; this service just calls it.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);

  readonly user = signal<User | null>(null);
  readonly authMode = signal<string>('ldap');
  readonly requiredGroup = signal<string>('Dynatrace_Users');
  readonly loaded = signal(false);
  readonly authDisabled = computed(() => this.authMode() === 'disabled');

  private loading: Promise<void> | null = null;

  /** Ask Flask who we are. Also makes Flask set the XSRF-TOKEN cookie. */
  load(force = false): Promise<void> {
    if (this.loaded() && !force) return Promise.resolve();
    if (!this.loading || force) {
      this.loading = firstValueFrom(this.http.get<MeResponse>('/api/me'))
        .then((me) => {
          this.user.set(me.user);
          this.authMode.set(me.auth_mode);
          this.requiredGroup.set(me.required_group);
        })
        .catch(() => this.user.set(null))
        .finally(() => {
          this.loaded.set(true);
          this.loading = null;
        });
    }
    return this.loading;
  }

  async login(username: string, password: string): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{ user: User }>('/api/login', { username, password }),
    );
    this.user.set(res.user);
  }

  async logout(): Promise<void> {
    try {
      await firstValueFrom(this.http.post('/api/logout', {}));
    } finally {
      this.user.set(null);
    }
  }

  /** Called by the interceptor when any API call returns 401. */
  sessionExpired(): void {
    this.user.set(null);
  }
}
