import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, shareReplay } from 'rxjs';
import {
  AuditRecord,
  CreateResponse,
  ListResponse,
  PreviewResponse,
  SiteConfig,
  WindowForm,
} from './models';

/** Thin wrapper over the Flask JSON API. Flask holds the Dynatrace token, never the browser. */
@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);
  private config$?: Observable<SiteConfig>;

  /** Tenant, CST lock, entity types. Cached; call refreshConfig() to reload. */
  config(): Observable<SiteConfig> {
    if (!this.config$) {
      this.config$ = this.http.get<SiteConfig>('/api/config').pipe(shareReplay(1));
    }
    return this.config$;
  }

  refreshConfig(): void {
    this.config$ = undefined;
  }

  /** "Generate JSON": builds the payload (with entity lookups) without sending it to Dynatrace. */
  preview(form: WindowForm): Observable<PreviewResponse> {
    return this.http.post<PreviewResponse>('/api/preview-maintenance-window', form);
  }

  /** "Push to Dynatrace". Flask also does the NSLookup on the caller's IP and logs it. */
  create(form: WindowForm): Observable<CreateResponse> {
    return this.http.post<CreateResponse>('/api/maintenance-windows', form);
  }

  /** Every window in the tenant; Flask follows nextPageKey until all pages are loaded. */
  list(): Observable<ListResponse> {
    return this.http.get<ListResponse>('/api/maintenance-windows');
  }

  delete(objectId: string, name: string): Observable<unknown> {
    const params = new HttpParams().set('name', name);
    return this.http.delete(`/api/maintenance-windows/${encodeURIComponent(objectId)}`, { params });
  }

  audit(limit = 1000): Observable<{ records: AuditRecord[] }> {
    return this.http.get<{ records: AuditRecord[] }>('/api/audit', {
      params: new HttpParams().set('limit', limit),
    });
  }
}
