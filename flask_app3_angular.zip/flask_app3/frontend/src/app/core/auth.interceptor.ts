import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AuthService } from './auth.service';

/** Any 401 from the API (session expired) sends the user back to the sign-in page. */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  return next(req).pipe(
    catchError((err: HttpErrorResponse) => {
      const isAuthCall = req.url.startsWith('/api/login') || req.url.startsWith('/api/me');
      if (err.status === 401 && !isAuthCall) {
        auth.sessionExpired();
        router.navigate(['/login'], { queryParams: { next: router.url, expired: 1 } });
      }
      return throwError(() => err);
    }),
  );
};
