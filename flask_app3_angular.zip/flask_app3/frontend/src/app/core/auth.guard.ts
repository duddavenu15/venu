import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './auth.service';

/** Pages require a signed-in member of the AD group; otherwise go to /login. */
export const authGuard: CanActivateFn = async (_route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  await auth.load();
  if (auth.user()) return true;
  return router.createUrlTree(['/login'], { queryParams: { next: state.url } });
};

/** Keep signed-in users off the login page. */
export const loginPageGuard: CanActivateFn = async () => {
  const auth = inject(AuthService);
  const router = inject(Router);
  await auth.load();
  return auth.user() ? router.createUrlTree(['/']) : true;
};
