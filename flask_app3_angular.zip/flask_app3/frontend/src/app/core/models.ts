export interface User {
  username: string;
  display_name: string;
}

export interface MeResponse {
  user: User | null;
  auth_mode: string;
  required_group: string;
}

export interface EntityType {
  type: string;
  label: string;
  count?: number;
}

export interface SiteConfig {
  tenant_label: string;
  tenant_url: string;
  fixed_time_zone: string;
  selector_scope: string;
  selector_max: number;
  entity_types: EntityType[];
  entity_type_groups: { common: EntityType[]; all: EntityType[] };
  /** "dynatrace" when the list came live from the tenant, "file" when it's the saved fallback. */
  entity_types_source: string;
  entity_types_error: string | null;
  entity_types_loaded_at: string | null;
}

export type ScheduleType = 'ONCE' | 'DAILY' | 'WEEKLY' | 'MONTHLY';

/** What the Create form sends to Flask (same field names the server already uses). */
export interface WindowForm {
  name: string;
  description: string;
  maintenance_type: string;
  suppression: string;
  disable_synthetic_monitor_execution: boolean;
  schedule_type: ScheduleType;
  time_zone: string;
  start_time: string;
  end_time: string;
  time_window_start: string;
  time_window_end: string;
  day_of_week: string;
  day_of_month: number;
  range_start_date: string;
  range_end_date: string;
  entity_type: string;
  entity_names: string;
  entity_selector: string;
}

export interface ResolvedEntity {
  name: string;
  entityId: string;
  displayName: string;
  type?: string;
}

export interface Submitter {
  user: string;
  client_ip: string;
  client_hostname: string | null;
  dns_lookup: string;
}

export interface PreviewResponse {
  request_payload: unknown;
  resolved: ResolvedEntity[];
  unresolved: string[];
  truncated: boolean;
  entity_type: string;
}

export interface CreateResponse extends PreviewResponse {
  status_code: number;
  object_ids: string[];
  submitter: Submitter;
  dynatrace_response: unknown;
}

export interface SubmittedBy {
  user: string;
  client_ip: string;
  client_hostname: string | null;
  timestamp: string;
  entity_names: string[] | null;
  entity_selector: string | null;
}

export interface MaintenanceWindow {
  objectId: string;
  name: string;
  description: string;
  maintenanceType: string;
  suppression: string;
  enabled: boolean;
  scheduleType: string;
  schedule: any;
  filters: { entityType: string | null; entityId: string | null }[];
  summary: string;
  submittedBy: SubmittedBy | null;
}

export interface ListResponse {
  items: MaintenanceWindow[];
  pages_fetched: number;
  /** How many windows Dynatrace says exist. */
  total_count: number;
  /** True when every page was read. */
  complete: boolean;
  warning: string | null;
}

export interface AuditRecord {
  timestamp: string;
  event: string;
  user?: string;
  client_ip?: string;
  client_hostname?: string | null;
  dns_lookup?: string;
  /** "direct", "forwarded by local proxy" or "browser on the app server" */
  ip_source?: string;
  peer_ip?: string;
  window_name?: string;
  reason?: string;
  entity_type?: string;
  entity_names?: string[];
  entity_selector?: string | null;
  unresolved?: string[];
  object_ids?: string[];
}

/** Error body shape returned by Flask. */
export interface ApiError {
  error?: string;
  status_code?: number;
  unresolved?: string[];
  response_body?: any;
  details?: string;
}
