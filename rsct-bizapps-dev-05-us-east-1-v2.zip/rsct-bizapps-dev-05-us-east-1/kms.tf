resource "aws_kms_key" "api_client" {
  count = var.use_cmk ? 1 : 0

  description             = "Dynatrace API client encryption key"
  deletion_window_in_days = 30
  enable_key_rotation     = true

  policy = jsonencode({
    Version = "2012-10-17"

    Statement = [
      {
        Sid    = "EnableAccountRootPermissions"
        Effect = "Allow"

        Principal = {
          AWS = "arn:aws:iam::${var.account_id}:root"
        }

        Action   = "kms:*"
        Resource = "*"
      },
      {
        Sid    = "AllowCloudWatchLogs"
        Effect = "Allow"

        Principal = {
          Service = "logs.${var.region}.amazonaws.com"
        }

        Action = [
          "kms:Encrypt",
          "kms:Decrypt",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:CreateGrant",
          "kms:DescribeKey"
        ]

        Resource = "*"

        Condition = {
          ArnLike = {
            "kms:EncryptionContext:aws:logs:arn" = format(
              "arn:aws:logs:%s:%s:log-group:/aws/lambda/%s*",
              var.region,
              var.account_id,
              local.name_prefix
            )
          }

          StringEquals = {
            "aws:SourceAccount" = var.account_id
          }
        }
      },
      {
        Sid    = "AllowSecretsManager"
        Effect = "Allow"

        Principal = {
          Service = "secretsmanager.amazonaws.com"
        }

        Action = [
          "kms:Encrypt",
          "kms:Decrypt",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:CreateGrant",
          "kms:DescribeKey"
        ]

        Resource = "*"

        Condition = {
          StringEquals = {
            "kms:CallerAccount" = var.account_id
            "kms:ViaService"    = "secretsmanager.${var.region}.amazonaws.com"
          }
        }
      },
      {
        # EventBridge connection secrets (events!connection/...) are encrypted
        # through Secrets Manager with this key. Scoped per the AWS EventBridge
        # docs: this account only, via Secrets Manager only, only this
        # connection's secret, only while the key carries the
        # EventBridgeApiDestinations=true tag.
        Sid    = "AllowEventBridgeConnectionSecret"
        Effect = "Allow"

        Principal = {
          AWS = "*"
        }

        Action = [
          "kms:DescribeKey",
          "kms:GenerateDataKey",
          "kms:Decrypt"
        ]

        Resource = "*"

        Condition = {
          StringEquals = {
            "kms:CallerAccount"                          = var.account_id
            "kms:ViaService"                             = "secretsmanager.${var.region}.amazonaws.com"
            "aws:ResourceTag/EventBridgeApiDestinations" = "true"
          }

          StringLike = {
            "kms:EncryptionContext:SecretARN" = format(
              "arn:aws:secretsmanager:%s:%s:secret:events!connection/%s/*",
              var.region,
              var.account_id,
              local.event_connection_name
            )
          }
        }
      }
    ]
  })

  tags = merge(
    local.common_tags,
    {
      Name                       = "${local.name_prefix}-api"
      EventBridgeApiDestinations = "true"
    }
  )
}
