
# lifecycle_scope = "CRUD": on destroy/replacement Terraform invokes the Lambda
# again with tf.action = "delete", and the Lambda deletes the Dynatrace
# Settings object (found by its deterministic connection_name).
resource "aws_lambda_invocation" "create_settings" {
  function_name   = aws_lambda_function.api_client.function_name
  lifecycle_scope = "CRUD"

  input = jsonencode({
    operation       = "create_settings"
    connection_name = local.dynatrace_connection_name
  })

  # The Lambda needs its policy and token on destroy too, so keep them
  # until this invocation's delete has run.
  depends_on = [
    aws_iam_role_policy.api_client,
    aws_secretsmanager_secret_version.settings_token
  ]
}

resource "aws_lambda_invocation" "configure_settings" {
  count = local.create_monitoring_role ? 1 : 0

  function_name = aws_lambda_function.api_client.function_name

  input = jsonencode({
    operation = "configure_settings"
    settings_object_id = jsondecode(
      aws_lambda_invocation.create_settings.result
    ).settings_object_id
    connection_name = jsondecode(
      aws_lambda_invocation.create_settings.result
    ).connection_name
    monitoring_role_arn = local.monitoring_role_arn
  })

  lifecycle {
    replace_triggered_by = [
      aws_lambda_function.api_client.source_code_hash,
      aws_iam_role.monitoring[0]
    ]

    precondition {
      condition = (
        var.dynatrace_settings_object_id ==
        jsondecode(aws_lambda_invocation.create_settings.result).settings_object_id
      )
      error_message = "dynatrace_settings_object_id does not match the settings_object_id output from the first apply. Copy the value from that output."
    }
  }

  depends_on = [
    aws_lambda_invocation.create_settings,
    time_sleep.monitoring_iam_ready
  ]
}

# Dynatrace allows one credential per monitoring configuration. The Lambda
# replaces it, but refuses if it belongs to another AWS account unless
# dynatrace_replace_existing_credential = true. On destroy it removes this
# account's credential (best effort).
resource "aws_lambda_invocation" "configure_monitoring" {
  count = local.create_monitoring_role ? 1 : 0

  function_name   = aws_lambda_function.api_client.function_name
  lifecycle_scope = "CRUD"

  input = jsonencode({
    operation                   = "configure_monitoring"
    monitoring_configuration_id = var.monitoring_config_id
    settings_object_id = jsondecode(
      aws_lambda_invocation.create_settings.result
    ).settings_object_id
    monitoring_role_arn         = local.monitoring_role_arn
    replace_existing_credential = var.dynatrace_replace_existing_credential
  })

  lifecycle {
    replace_triggered_by = [
      aws_lambda_function.api_client.source_code_hash,
      aws_iam_role.monitoring[0]
    ]
  }

  depends_on = [
    aws_lambda_invocation.configure_settings
  ]
}

resource "aws_lambda_invocation" "report_status" {
  count = local.create_monitoring_role ? 1 : 0

  function_name = aws_lambda_function.api_client.function_name

  input = jsonencode({
    operation                   = "report_status"
    monitoring_configuration_id = var.monitoring_config_id
  })

  lifecycle {
    replace_triggered_by = [
      aws_lambda_function.api_client.source_code_hash,
      aws_lambda_invocation.configure_monitoring[0]
    ]
  }

  depends_on = [
    aws_lambda_invocation.configure_monitoring
  ]
}

resource "time_sleep" "monitoring_iam_ready" {
  count = local.create_monitoring_role ? 1 : 0

  create_duration = "60s"

  triggers = {
    trust_policy_sha = sha256(local.monitoring_role_trust_policy)
    monitoring_policy_1_sha = sha256(
      data.aws_iam_policy_document.monitoring_policy_1.json
    )
    monitoring_policy_2_sha = sha256(
      data.aws_iam_policy_document.monitoring_policy_2.json
    )
  }

  depends_on = [
    aws_iam_role.monitoring,
    aws_iam_role_policy_attachment.monitoring_policy_1,
    aws_iam_role_policy_attachment.monitoring_policy_2
  ]
}

resource "aws_lambda_invocation" "report_complete" {
  count = local.create_monitoring_role ? 1 : 0

  function_name = aws_lambda_function.api_client.function_name

  input = jsonencode({
    operation                   = "report_complete"
    monitoring_configuration_id = var.monitoring_config_id
  })

  lifecycle {
    replace_triggered_by = [
      aws_lambda_function.api_client.source_code_hash,
      aws_lambda_invocation.report_status[0],
      aws_lambda_invocation.configure_monitoring[0]
    ]
  }

  depends_on = [
    aws_lambda_invocation.report_status,
    aws_kinesis_firehose_delivery_stream.dynatrace_logs,
    aws_cloudwatch_event_target.dynatrace
  ]
}
