import json
import logging
import os
import random
import re
import string
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import boto3
from botocore.exceptions import BotoCoreError, ClientError


LOG = logging.getLogger()
LOG.setLevel(os.getenv("LOG_LEVEL", "INFO"))

secretsmanager = boto3.client("secretsmanager")

SETTINGS_OBJECTS_PATH = (
    "/platform/classic/environment-api/v2/settings/objects"
)
SETTINGS_OBJECT_PATH = (
    "/platform/classic/environment-api/v2/settings/objects/{object_id}"
)
MONITORING_CONFIGURATIONS_PATH = (
    "/platform/extensions/v2/extensions/"
    "com.dynatrace.extension.da-aws/monitoring-configurations"
)
MONITORING_CONFIGURATION_PATH = (
    MONITORING_CONFIGURATIONS_PATH + "/{configuration_id}"
)

SETTINGS_SCHEMA_ID = (
    "builtin:hyperscaler-authentication.connections.aws"
)
CONSUMER = "SVC:com.dynatrace.da"
TEMPLATE_VERSION = "v1.0.17"

# Accept Dynatrace SaaS environment URLs only.
DYNATRACE_URL_PATTERN = re.compile(
    r"^https://[A-Za-z0-9.-]+\.(dynatrace|dynatracelabs)\.com$"
)

IAM_ROLE_ARN_PATTERN = re.compile(
    r"^arn:aws:iam::([0-9]{12}):role/[A-Za-z0-9+=,.@_/-]+$"
)


class DynatraceApiError(Exception):
    """Raised when a Dynatrace API request or input validation fails."""


def require_string(value, name):
    if not isinstance(value, str) or not value.strip():
        raise DynatraceApiError(
            f"{name} must be a non-empty string."
        )

    return value


def monitoring_account_id(role_arn):
    require_string(role_arn, "monitoring_role_arn")

    match = IAM_ROLE_ARN_PATTERN.fullmatch(role_arn)
    if not match:
        raise DynatraceApiError(
            "monitoring_role_arn must be a valid AWS IAM role ARN."
        )

    return match.group(1)


def environment_url():
    value = os.getenv("DT_ENVIRONMENT_URL", "").rstrip("/")

    if not DYNATRACE_URL_PATTERN.fullmatch(value):
        raise DynatraceApiError(
            "DT_ENVIRONMENT_URL must be a valid Dynatrace SaaS URL."
        )

    return value


def settings_token():
    secret_arn = os.getenv("DT_API_SECRET_ARN")

    if not secret_arn:
        raise DynatraceApiError(
            "DT_API_SECRET_ARN is not configured."
        )

    try:
        response = secretsmanager.get_secret_value(
            SecretId=secret_arn
        )
    except ClientError as exc:
        error_code = exc.response.get("Error", {}).get(
            "Code", "Unknown"
        )
        raise DynatraceApiError(
            "Unable to read the Dynatrace settings-token secret; "
            f"AWS error code={error_code}."
        ) from exc
    except BotoCoreError as exc:
        raise DynatraceApiError(
            "Unable to access AWS Secrets Manager."
        ) from exc

    secret_string = response.get("SecretString")

    if not secret_string:
        raise DynatraceApiError(
            "The Dynatrace settings-token secret has no SecretString."
        )

    try:
        document = json.loads(secret_string)
        token = document["dynatrace_api_token"]
    except (json.JSONDecodeError, KeyError, TypeError) as exc:
        raise DynatraceApiError(
            "The Dynatrace settings-token secret is not valid JSON "
            "containing 'dynatrace_api_token'."
        ) from exc

    if not isinstance(token, str) or not token.strip():
        raise DynatraceApiError(
            "The Dynatrace settings API token is empty or invalid."
        )

    return token


def format_api_error(path, method, status, document):
    if isinstance(document, dict):
        error = document.get("error", document)
    else:
        error = document

    if isinstance(error, list):
        error = error[0] if error else {}

    if not isinstance(error, dict):
        error = {"message": str(error)}

    message = error.get("message", "no message")
    code = error.get("code", "unknown")

    # Settings API errors can contain violations directly under error.
    violations = error.get("constraintViolations")

    # Preserve support for the alternative nested response format.
    if not violations:
        details = error.get("details", {})
        if isinstance(details, dict):
            violations = details.get("constraintViolations")

    return (
        f"Dynatrace API {method} {path} failed: "
        f"HTTP {status}; code={code}; message={message}; "
        f"violations={json.dumps(violations or [], default=str)}"
    )


def request_dynatrace(path, method="GET", body=None, timeout=90):
    url = environment_url() + path

    headers = {
        "Authorization": f"Bearer {settings_token()}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }

    encoded_body = None
    if body is not None:
        try:
            encoded_body = json.dumps(body).encode("utf-8")
        except (TypeError, ValueError) as exc:
            raise DynatraceApiError(
                f"Unable to serialize the request for {method} {path}."
            ) from exc

    request = Request(
        url=url,
        data=encoded_body,
        headers=headers,
        method=method,
    )

    # Never log the authorization header, token, or request body.
    try:
        with urlopen(request, timeout=timeout) as response:
            response_body = response.read().decode("utf-8")

            if not response_body.strip():
                return {}

            try:
                return json.loads(response_body)
            except json.JSONDecodeError as exc:
                raise DynatraceApiError(
                    "Dynatrace returned a non-JSON success response "
                    f"for {method} {path}."
                ) from exc

    except HTTPError as exc:
        response_body = exc.read().decode(
            "utf-8", errors="replace"
        )

        try:
            error_document = json.loads(response_body)
        except json.JSONDecodeError:
            # Avoid including an arbitrary response body in logs.
            error_document = {
                "message": "Dynatrace returned a non-JSON error response."
            }

        message = format_api_error(
            path, method, exc.code, error_document
        )

        if "Account ID must be unique" in message:
            message = (
                "This AWS account is already monitored by Dynatrace. "
                + message
            )

        raise DynatraceApiError(message) from exc

    except URLError as exc:
        raise DynatraceApiError(
            f"Dynatrace API connection failed for "
            f"{method} {path}: {exc.reason}"
        ) from exc

    except TimeoutError as exc:
        raise DynatraceApiError(
            f"Dynatrace API request timed out for {method} {path}."
        ) from exc


def require_response_dict(response, operation):
    if not isinstance(response, dict):
        raise DynatraceApiError(
            f"Dynatrace returned an unexpected response for {operation}."
        )

    return response


def random_suffix(length=8):
    alphabet = string.ascii_lowercase + string.digits
    return "".join(
        random.choice(alphabet) for _ in range(length)
    )


def connection_payload(connection_name, role_arn):
    # Creation payload. PUT uses only the value from this document.
    return {
        "schemaId": SETTINGS_SCHEMA_ID,
        "value": {
            "name": connection_name,
            "type": "awsRoleBasedAuthentication",
            "awsRoleBasedAuthentication": {
                "roleArn": role_arn,
                "consumers": [CONSUMER],
            },
        },
    }


def find_settings_object_id(connection_name):
    """Return the objectId of the AWS connection with this name, or None."""
    require_string(connection_name, "connection_name")

    query = urlencode({
        "schemaIds": SETTINGS_SCHEMA_ID,
        "fields": "objectId,value",
        "pageSize": 500,
    })

    while True:
        response = require_response_dict(
            request_dynatrace(f"{SETTINGS_OBJECTS_PATH}?{query}"),
            "list_settings",
        )

        for item in response.get("items") or []:
            if not isinstance(item, dict):
                continue
            value = item.get("value")
            if isinstance(value, dict) and value.get("name") == connection_name:
                return item.get("objectId")

        next_page_key = response.get("nextPageKey")
        if not next_page_key:
            return None

        # Follow-up pages accept only nextPageKey.
        query = urlencode({"nextPageKey": next_page_key})


def create_settings_object(connection_name=None):
    # A deterministic name (passed from Terraform) makes creation idempotent
    # and lets the destroy-time invocation find the object to delete.
    if not connection_name:
        connection_name = f"da_aws_connection-{random_suffix()}"

    existing_id = find_settings_object_id(connection_name)
    if existing_id:
        LOG.info("Settings object already exists; reusing it.")
        return {
            "settings_object_id": existing_id,
            "connection_name": connection_name,
        }

    response = request_dynatrace(
        SETTINGS_OBJECTS_PATH,
        method="POST",
        body=[connection_payload(connection_name, "")],
    )

    if (
        not isinstance(response, list)
        or not response
        or not isinstance(response[0], dict)
    ):
        raise DynatraceApiError(
            "Dynatrace did not return a Settings object after creation."
        )

    object_id = response[0].get("objectId")

    if not isinstance(object_id, str) or not object_id:
        raise DynatraceApiError(
            "Dynatrace Settings creation response did not contain "
            "a valid objectId."
        )

    return {
        "settings_object_id": object_id,
        "connection_name": connection_name,
    }


def configure_settings_object(
    settings_object_id,
    connection_name,
    role_arn,
):
    require_string(settings_object_id, "settings_object_id")
    require_string(connection_name, "connection_name")
    monitoring_account_id(role_arn)

    path = SETTINGS_OBJECT_PATH.format(
        object_id=settings_object_id
    )

    # FIX: PUT requires the Settings update body, not the POST envelope.
    # Do not include schemaId here.
    update_body = {
        "value": connection_payload(
            connection_name,
            role_arn,
        )["value"]
    }

    response = request_dynatrace(
        path,
        method="PUT",
        body=update_body,
    )
    require_response_dict(response, "configure_settings")

    return {
        "settings_object_id": (
            response.get("objectId") or settings_object_id
        ),
        "connection_name": connection_name,
    }


def get_monitoring_configuration(configuration_id):
    require_string(
        configuration_id,
        "monitoring_configuration_id",
    )

    path = MONITORING_CONFIGURATION_PATH.format(
        configuration_id=configuration_id
    )

    response = request_dynatrace(path, method="GET")
    return require_response_dict(
        response,
        "get_monitoring_configuration",
    )


def get_aws_configuration(document):
    try:
        aws_config = document["value"]["aws"]
    except (KeyError, TypeError) as exc:
        raise DynatraceApiError(
            "The Dynatrace monitoring configuration does not "
            "contain value.aws."
        ) from exc

    if not isinstance(aws_config, dict):
        raise DynatraceApiError(
            "The Dynatrace monitoring configuration value.aws "
            "must be an object."
        )

    return aws_config


def update_monitoring_configuration(
    configuration_id,
    status=None,
):
    document = get_monitoring_configuration(configuration_id)
    aws_config = get_aws_configuration(document)

    if status is not None:
        aws_config["automatedDeploymentStatus"] = status

    aws_config["automatedDeploymentTemplateVersion"] = (
        TEMPLATE_VERSION
    )

    path = MONITORING_CONFIGURATION_PATH.format(
        configuration_id=configuration_id
    )

    # This is the Extensions API, not the Settings Objects API.
    # Preserve the existing Extensions update body.
    response = request_dynatrace(
        path,
        method="PUT",
        body=document,
    )
    require_response_dict(
        response,
        "update_monitoring_configuration",
    )

    return {
        "monitoring_configuration_id": (
            response.get("objectId") or configuration_id
        ),
        "status": status,
    }


def configure_monitoring(
    monitoring_configuration_id,
    settings_object_id,
    monitoring_role_arn,
    replace_existing_credential=False,
):
    require_string(settings_object_id, "settings_object_id")
    account_id = monitoring_account_id(monitoring_role_arn)

    document = get_monitoring_configuration(
        monitoring_configuration_id
    )
    aws_config = get_aws_configuration(document)

    # Dynatrace allows exactly ONE credential per da-aws monitoring
    # configuration (collection upper size limit = 1), so the list must be
    # replaced, not appended to. To avoid silently taking over a
    # configuration that already monitors a different AWS account, refuse
    # unless replace_existing_credential is explicitly true.
    current_credentials = aws_config.get("credentials", [])
    if not isinstance(current_credentials, list):
        raise DynatraceApiError(
            "The Dynatrace monitoring configuration value.aws.credentials "
            "must be an array."
        )

    other_accounts = sorted({
        str(credential.get("accountId"))
        for credential in current_credentials
        if isinstance(credential, dict)
        and credential.get("accountId")
        and str(credential.get("accountId")) != account_id
    })

    if other_accounts and not replace_existing_credential:
        raise DynatraceApiError(
            f"Monitoring configuration {monitoring_configuration_id} already "
            f"has a credential for AWS account(s) {', '.join(other_accounts)}. "
            "A Dynatrace AWS monitoring configuration holds exactly one "
            f"credential, so configuring account {account_id} here would stop "
            "monitoring that account. Use a monitoring configuration created "
            f"for account {account_id}, or set "
            "dynatrace_replace_existing_credential = true to take this one over."
        )

    if other_accounts:
        LOG.warning(
            "Replacing credential for AWS account(s) %s in monitoring "
            "configuration %s (replace_existing_credential=true).",
            ", ".join(other_accounts),
            monitoring_configuration_id,
        )

    aws_config["credentials"] = [
        {
            "description": "HAS connection",
            "enabled": True,
            "connectionId": settings_object_id,
            "accountId": account_id,
        }
    ]

    document["value"]["enabled"] = True
    aws_config["automatedDeploymentTemplateVersion"] = (
        TEMPLATE_VERSION
    )

    path = MONITORING_CONFIGURATION_PATH.format(
        configuration_id=monitoring_configuration_id
    )

    response = request_dynatrace(
        path,
        method="PUT",
        body=document,
    )
    require_response_dict(response, "configure_monitoring")

    return {
        "monitoring_configuration_id": (
            response.get("objectId")
            or monitoring_configuration_id
        ),
        "settings_object_id": settings_object_id,
        "account_id": account_id,
    }


def remove_account_credential(
    monitoring_configuration_id,
    monitoring_role_arn,
):
    """Destroy-time counterpart of configure_monitoring."""
    account_id = monitoring_account_id(monitoring_role_arn)

    document = get_monitoring_configuration(monitoring_configuration_id)
    aws_config = get_aws_configuration(document)

    current_credentials = aws_config.get("credentials", [])
    if not isinstance(current_credentials, list):
        raise DynatraceApiError(
            "The Dynatrace monitoring configuration value.aws.credentials "
            "must be an array."
        )

    remaining = [
        credential
        for credential in current_credentials
        if not isinstance(credential, dict)
        or credential.get("accountId") != account_id
    ]

    if len(remaining) == len(current_credentials):
        return {"removed": False, "account_id": account_id}

    aws_config["credentials"] = remaining

    path = MONITORING_CONFIGURATION_PATH.format(
        configuration_id=monitoring_configuration_id
    )
    response = request_dynatrace(path, method="PUT", body=document)
    require_response_dict(response, "remove_account_credential")

    return {"removed": True, "account_id": account_id}


def delete_settings_by_name(connection_name):
    """Destroy-time counterpart of create_settings."""
    object_id = find_settings_object_id(connection_name)

    if not object_id:
        return {
            "deleted": False,
            "message": "No Settings object with this connection name.",
        }

    return delete_settings_object(object_id)


def handle_destroy(operation, event):
    """
    Terraform calls the Lambda with tf.action == "delete" on destroy or
    replacement for invocations that use lifecycle_scope = "CRUD".
    """
    # Best effort: a Dynatrace-side refusal (for example a minimum of one
    # credential, or a connection still in use) is logged as a warning in
    # CloudWatch instead of blocking terraform destroy / replacement.
    try:
        if operation == "create_settings":
            return delete_settings_by_name(event.get("connection_name"))

        if operation == "configure_monitoring":
            return remove_account_credential(
                monitoring_configuration_id=event.get(
                    "monitoring_configuration_id"
                ),
                monitoring_role_arn=event.get("monitoring_role_arn"),
            )
    except DynatraceApiError as exc:
        LOG.warning(
            "Destroy-time cleanup for %s did not complete; clean up in "
            "Dynatrace manually if needed: %s",
            operation,
            exc,
        )
        return {"cleaned_up": False, "warning": str(exc)}

    return {"deleted": False, "message": "Nothing to clean up."}


def delete_settings_object(settings_object_id):
    # DESTRUCTIVE: removes the remote Dynatrace Settings connection.
    if not settings_object_id:
        return {
            "deleted": False,
            "message": "No settings_object_id was provided.",
        }

    require_string(settings_object_id, "settings_object_id")

    path = SETTINGS_OBJECT_PATH.format(
        object_id=settings_object_id
    )

    request_dynatrace(path, method="DELETE")

    return {
        "deleted": True,
        "settings_object_id": settings_object_id,
    }


def handler(event, context):
    """
    Supported operations:

    create_settings
    configure_settings
    configure_monitoring
    report_status
    report_complete
    delete_settings
    """
    if not isinstance(event, dict):
        raise DynatraceApiError(
            "The Lambda event must be a JSON object."
        )

    operation = event.get("operation")
    require_string(operation, "operation")

    tf_meta = event.get("tf")
    tf_action = (
        tf_meta.get("action") if isinstance(tf_meta, dict) else None
    )

    LOG.info(
        "Starting Dynatrace operation: %s (terraform action: %s)",
        operation,
        tf_action or "none",
    )

    if tf_action == "delete":
        result = handle_destroy(operation, event)

    elif operation == "create_settings":
        result = create_settings_object(
            connection_name=event.get("connection_name")
        )

    elif operation == "configure_settings":
        result = configure_settings_object(
            settings_object_id=event.get("settings_object_id"),
            connection_name=event.get("connection_name"),
            role_arn=event.get("monitoring_role_arn"),
        )

    elif operation == "configure_monitoring":
        result = configure_monitoring(
            monitoring_configuration_id=event.get(
                "monitoring_configuration_id"
            ),
            settings_object_id=event.get("settings_object_id"),
            monitoring_role_arn=event.get("monitoring_role_arn"),
            replace_existing_credential=(
                event.get("replace_existing_credential") is True
            ),
        )

    elif operation in ("report_status", "report_complete"):
        status = (
            "RUNNING"
            if operation == "report_status"
            else "COMPLETE"
        )

        result = update_monitoring_configuration(
            configuration_id=event.get(
                "monitoring_configuration_id"
            ),
            status=status,
        )

    elif operation == "delete_settings":
        result = delete_settings_object(
            settings_object_id=event.get("settings_object_id")
        )

    else:
        raise DynatraceApiError(
            f"Unsupported operation: {operation}"
        )

    result["operation"] = operation
    LOG.info("Completed Dynatrace operation: %s", operation)

    return result
