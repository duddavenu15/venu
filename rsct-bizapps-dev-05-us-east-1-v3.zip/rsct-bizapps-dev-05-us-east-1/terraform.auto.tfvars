account_id = "160893582671"
region     = "us-east-1"

dynatrace_url        = "https://ugt80968.apps.dynatrace.com"
monitoring_config_id = "80724e1c-e09a-3367-89dd-13f5b6783a68"

# Phase 2: the Dynatrace AWS connection objectId (the "settings_object_id"
# output of this workspace). This is NOT monitoring_config_id. It becomes the
# sts:ExternalId in the monitoring role trust policy.
dynatrace_settings_object_id = "vu9U3hXa3q0AAAABADJidWlsdGluOmh5cGVyc2NhbGVyLWF1dGhlbnRpY2F0aW9uLmNvbm5lY3Rpb25zLmF3cwAGdGVuYW50AAZ0ZW5hbnQAJGQ2NjcyYzJkLThhNTctMzI5OC04ZWVlLWFjNDk3NzdiZjNlOL7vVN4V2t6t"

use_cmk = true

logs_ingest_enabled = true
logs_ingest_regions = ["us-east-1"]

events_ingest_enabled = true
events_ingest_regions = ["us-east-1"]

event_bridge_bus_name = "default"
event_sources         = ["aws.health"]

# Do not add these values here:
# dynatrace_api_token   = "..."
# dynatrace_ingest_token = "..."
