variable "account_id" {
  description = "AWS account ID where the integration is deployed."
  type        = string

  validation {
    condition     = can(regex("^[0-9]{12}$", var.account_id))
    error_message = "account_id must be a 12-digit AWS account ID."
  }
}

variable "region" {
  description = "AWS deployment region."
  type        = string
  default     = "us-east-1"

  validation {
    condition     = var.region == "us-east-1"
    error_message = "This initial implementation supports us-east-1 only."
  }
}

variable "dynatrace_url" {
  description = "Dynatrace environment URL without a trailing slash."
  type        = string

  validation {
    # Same pattern the API-client Lambda enforces, so bad input fails at plan.
    condition     = can(regex("^https://[A-Za-z0-9.-]+\\.(dynatrace|dynatracelabs)\\.com$", var.dynatrace_url))
    error_message = "dynatrace_url must be a host-only Dynatrace SaaS URL without a path or trailing slash, for example https://abc12345.apps.dynatrace.com."
  }
}

variable "monitoring_config_id" {
  description = "Existing Dynatrace AWS monitoring configuration ID."
  type        = string

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.monitoring_config_id))
    error_message = "monitoring_config_id must be a UUID."
  }
}

variable "dynatrace_api_token" {
  description = "Dynatrace Settings API token. Set as a sensitive Terraform Cloud variable."
  type        = string
  sensitive   = true

  validation {
    condition     = can(regex("^dt0s16\\.[A-Z0-9]{8}\\.[A-Z0-9]{64}$", var.dynatrace_api_token))
    error_message = "dynatrace_api_token does not match the expected Dynatrace token format."
  }
}

variable "dynatrace_ingest_token" {
  description = "Dynatrace ingest token. Set as a sensitive Terraform Cloud variable."
  type        = string
  sensitive   = true

  validation {
    condition     = can(regex("^dt0s16\\.[A-Z0-9]{8}\\.[A-Z0-9]{64}$", var.dynatrace_ingest_token))
    error_message = "dynatrace_ingest_token does not match the expected Dynatrace token format."
  }
}

variable "use_cmk" {
  description = "Create customer-managed KMS keys for Dynatrace resources."
  type        = bool
  default     = false
}

variable "logs_ingest_enabled" {
  description = "Enable Dynatrace log ingestion."
  type        = bool
  default     = true
}

variable "logs_ingest_regions" {
  description = "Regions from which logs are ingested."
  type        = list(string)
  default     = ["us-east-1"]

  validation {
    condition     = alltrue([for region in var.logs_ingest_regions : region == "us-east-1"])
    error_message = "Only us-east-1 is supported by this initial implementation."
  }
}

variable "events_ingest_enabled" {
  description = "Enable Dynatrace EventBridge ingestion."
  type        = bool
  default     = true
}

variable "events_ingest_regions" {
  description = "Regions from which EventBridge events are ingested."
  type        = list(string)
  default     = ["us-east-1"]

  validation {
    condition     = alltrue([for region in var.events_ingest_regions : region == "us-east-1"])
    error_message = "Only us-east-1 is supported by this initial implementation."
  }
}

variable "event_bridge_bus_name" {
  description = "EventBridge bus to monitor."
  type        = string
  default     = "default"

  validation {
    condition     = can(regex("^[A-Za-z0-9._-]{1,256}$", var.event_bridge_bus_name))
    error_message = "event_bridge_bus_name contains invalid characters."
  }
}

variable "event_sources" {
  description = "EventBridge event sources forwarded to Dynatrace."
  type        = list(string)
  default     = ["aws.health"]

  validation {
    condition     = length(var.event_sources) > 0
    error_message = "At least one EventBridge source must be specified."
  }
}


variable "dynatrace_settings_object_id" {
  description = <<-EOT
    Dynatrace AWS connection Settings object ID, used as the sts:ExternalId in
    the monitoring role trust policy. Leave null on the first apply: that apply
    creates the Settings object and prints it as the "settings_object_id"
    output. Then set it here in a second PR so the trust policy is known at
    plan time (required by the iam-restrict-trust-relationship Sentinel policy).
  EOT
  type        = string
  default     = null

  validation {
    condition = (
      var.dynatrace_settings_object_id == null ||
      can(regex("^[A-Za-z0-9_+=-]+$", coalesce(var.dynatrace_settings_object_id, "x")))
    )
    error_message = "dynatrace_settings_object_id must be the objectId string from the settings_object_id output."
  }
}


variable "dynatrace_replace_existing_credential" {
  description = <<-EOT
    A Dynatrace AWS monitoring configuration holds exactly one AWS credential.
    If monitoring_config_id already has a credential for a DIFFERENT AWS
    account, the apply fails unless this is true. Setting it to true moves
    that configuration to this account and stops monitoring the other one.
  EOT
  type        = bool
  default     = false
}
